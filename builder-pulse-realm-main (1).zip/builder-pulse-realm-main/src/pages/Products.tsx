import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, Droplets, Gem, Apple, Mountain } from "lucide-react";

const Products = () => {
  const petroleumProducts = [
    "SN500 Base Oil",
    "Paraffin Wax",
    "Petroleum Jelly",
    "Rubber Process Oil",
    "Carbon Black",
    "Phthalic Anhydride",
  ];

  const minerals = [
    "Silica Sand",
    "Dolomite",
    "Emerald",
    "Quartz Crystal",
    "Aluminium Ore",
    "Copper",
  ];

  const foodItems = {
    meat: ["Beef", "Mutton", "Chicken", "Fish"],
    fruits: [
      "Mangoes (Langra, Chaunsa, Sindhri)",
      "Oranges/Kinnow",
      "Pine Nuts",
    ],
    other: [
      "Dry Chili",
      "Mango Pulp",
      "Dried Mango",
      "Orange Concentrate",
      "Apple Concentrate",
    ],
  };

  const salts = ["Pink Himalayan Salt", "White Edible Salt"];

  return (
    <div className="min-h-screen bg-white">
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Product Catalog
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive range of high-quality products for global markets
            </p>
          </div>

          {/* Product Categories */}
          <div className="space-y-16">
            {/* Petroleum Products */}
            <div>
              <div className="flex items-center mb-8">
                <div className="bg-blue-100 rounded-lg p-3 mr-4">
                  <Droplets className="h-8 w-8 text-blue-500" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900">
                  Petroleum Products
                </h2>
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {petroleumProducts.map((product, index) => (
                  <Card
                    key={index}
                    className="hover:shadow-md transition-shadow"
                  >
                    <CardContent className="p-4">
                      <h4 className="font-semibold text-gray-900">{product}</h4>
                      <p className="text-sm text-gray-600 mt-1">
                        High-quality petroleum derivative
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Minerals & Gemstones */}
            <div>
              <div className="flex items-center mb-8">
                <div className="bg-purple-100 rounded-lg p-3 mr-4">
                  <Gem className="h-8 w-8 text-purple-500" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900">
                  Minerals & Gemstones
                </h2>
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {minerals.map((mineral, index) => (
                  <Card
                    key={index}
                    className="hover:shadow-md transition-shadow"
                  >
                    <CardContent className="p-4">
                      <h4 className="font-semibold text-gray-900">{mineral}</h4>
                      <p className="text-sm text-gray-600 mt-1">
                        Premium quality mineral/gemstone
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Food Items */}
            <div>
              <div className="flex items-center mb-8">
                <div className="bg-green-100 rounded-lg p-3 mr-4">
                  <Apple className="h-8 w-8 text-green-500" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900">Food Items</h2>
              </div>
              <div className="grid lg:grid-cols-3 gap-8">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Meat Products</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {foodItems.meat.map((item, index) => (
                        <li
                          key={index}
                          className="text-sm text-gray-600 flex items-center"
                        >
                          <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Fruits & Nuts</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {foodItems.fruits.map((item, index) => (
                        <li
                          key={index}
                          className="text-sm text-gray-600 flex items-center"
                        >
                          <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Other Products</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {foodItems.other.map((item, index) => (
                        <li
                          key={index}
                          className="text-sm text-gray-600 flex items-center"
                        >
                          <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                          {item}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Salts */}
            <div>
              <div className="flex items-center mb-8">
                <div className="bg-gray-100 rounded-lg p-3 mr-4">
                  <Mountain className="h-8 w-8 text-gray-500" />
                </div>
                <h2 className="text-2xl font-bold text-gray-900">
                  Salt Products
                </h2>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                {salts.map((salt, index) => (
                  <Card
                    key={index}
                    className="hover:shadow-md transition-shadow"
                  >
                    <CardContent className="p-6">
                      <h4 className="font-semibold text-gray-900 text-lg">
                        {salt}
                      </h4>
                      <p className="text-gray-600 mt-2">
                        {salt.includes("Pink")
                          ? "Natural Himalayan salt with minerals"
                          : "Pure white edible salt"}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Products;
