import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { api } from "@/services/api";
import { toast } from "sonner";
import {
  Users,
  Mail,
  MessageSquare,
  Package,
  BarChart3,
  Shield,
  LogOut,
  Loader2,
  TrendingUp,
  Calendar,
  Eye,
} from "lucide-react";

interface DashboardStats {
  contacts: {
    total: number;
    new_contacts: number;
    today: number;
  };
  quotes: {
    total: number;
    pending: number;
    today: number;
  };
  newsletter: {
    total: number;
    active: number;
    today: number;
  };
  product_inquiries: {
    total: number;
    new_inquiries: number;
    today: number;
  };
}

const Admin = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [loginForm, setLoginForm] = useState({
    username: "",
    password: "",
  });
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentActivities, setRecentActivities] = useState([]);
  const [token, setToken] = useState(localStorage.getItem("adminToken") || "");

  // Check if already logged in
  useEffect(() => {
    if (token) {
      verifyToken();
    }
  }, [token]);

  // Check if we're in demo mode
  const isDemoMode =
    typeof window !== "undefined" &&
    window.location.hostname !== "localhost" &&
    window.location.hostname !== "127.0.0.1";

  const verifyToken = async () => {
    try {
      const response = await api.admin.verify(token);
      if (response.success) {
        setIsLoggedIn(true);
        loadDashboard();
      } else {
        localStorage.removeItem("adminToken");
        setToken("");
      }
    } catch (error) {
      localStorage.removeItem("adminToken");
      setToken("");
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      // In demo mode, simulate login
      if (
        isDemoMode &&
        loginForm.username === "admin" &&
        loginForm.password === "admin123"
      ) {
        setIsLoggedIn(true);
        setStats({
          contacts: { total: 25, new_contacts: 3, today: 2 },
          quotes: { total: 18, pending: 5, today: 1 },
          newsletter: { total: 142, active: 138, today: 4 },
          product_inquiries: { total: 32, new_inquiries: 7, today: 2 },
        });
        setRecentActivities([
          {
            type: "contact",
            name: "John Doe",
            email: "john@example.com",
            created_at: new Date().toISOString(),
          },
          {
            type: "quote",
            name: "Jane Smith",
            email: "jane@company.com",
            company: "ABC Corp",
            product_category: "Petroleum",
            created_at: new Date().toISOString(),
          },
        ]);
        toast.success("Admin login successful! 🎯");
        setIsLoading(false);
        return;
      }

      const response = await api.admin.login(
        loginForm.username,
        loginForm.password,
      );

      if (response.success && response.data?.token) {
        setToken(response.data.token);
        localStorage.setItem("adminToken", response.data.token);
        setIsLoggedIn(true);
        toast.success("Login successful!");
        loadDashboard();
      } else {
        toast.error(response.error || "Login failed");
      }
    } catch (error) {
      if (isDemoMode) {
        toast.error("Demo: Use admin/admin123 to access demo dashboard");
      } else {
        toast.error("Login failed. Please try again.");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const loadDashboard = async () => {
    try {
      const response = await api.admin.getDashboard(token);
      if (response.success && response.data) {
        setStats(response.data.overview);
        setRecentActivities(response.data.recentActivities);
      }
    } catch (error) {
      toast.error("Failed to load dashboard data");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("adminToken");
    setToken("");
    setIsLoggedIn(false);
    setStats(null);
    setRecentActivities([]);
    toast.success("Logged out successfully");
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full space-y-8">
          <div>
            <div className="mx-auto h-12 w-12 bg-orange-500 rounded-lg flex items-center justify-center">
              <Shield className="h-8 w-8 text-white" />
            </div>
            <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
              AISAAUS International
            </h2>
            <p className="mt-2 text-center text-sm text-gray-600">
              Admin Dashboard Login
            </p>
          </div>
          <form className="mt-8 space-y-6" onSubmit={handleLogin}>
            <div className="space-y-4">
              <div>
                <Label htmlFor="username">Username</Label>
                <Input
                  id="username"
                  type="text"
                  required
                  value={loginForm.username}
                  onChange={(e) =>
                    setLoginForm({ ...loginForm, username: e.target.value })
                  }
                  placeholder="Enter username"
                />
              </div>
              <div>
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  required
                  value={loginForm.password}
                  onChange={(e) =>
                    setLoginForm({ ...loginForm, password: e.target.value })
                  }
                  placeholder="Enter password"
                />
              </div>
            </div>

            <Button
              type="submit"
              className="w-full bg-orange-500 hover:bg-orange-600"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Signing in...
                </>
              ) : (
                "Sign in"
              )}
            </Button>

            <div className="text-center text-sm text-gray-500">
              <p>Default login: admin / admin123</p>
              <p className="text-xs text-orange-600">
                Please change password after first login
              </p>
            </div>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <Shield className="h-8 w-8 text-orange-500 mr-3" />
              <h1 className="text-2xl font-bold text-gray-900">
                AISAAUS Admin Dashboard
              </h1>
            </div>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="border-orange-500 text-orange-500 hover:bg-orange-500 hover:text-white"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Overview */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Contact Forms
                </CardTitle>
                <MessageSquare className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {stats.contacts?.total}
                </div>
                <p className="text-xs text-muted-foreground">
                  {stats.contacts?.new_contacts} new today
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Quote Requests
                </CardTitle>
                <Package className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stats.quotes?.total}</div>
                <p className="text-xs text-muted-foreground">
                  {stats.quotes?.pending} pending
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Newsletter Subscribers
                </CardTitle>
                <Mail className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {stats.newsletter?.active}
                </div>
                <p className="text-xs text-muted-foreground">
                  {stats.newsletter?.today} new today
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  Product Inquiries
                </CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {stats.product_inquiries?.total}
                </div>
                <p className="text-xs text-muted-foreground">
                  {stats.product_inquiries?.new_inquiries} new
                </p>
              </CardContent>
            </Card>
          </div>
        )}

        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="contacts">Contacts</TabsTrigger>
            <TabsTrigger value="quotes">Quotes</TabsTrigger>
            <TabsTrigger value="newsletter">Newsletter</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Recent Activities</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivities.length > 0 ? (
                    recentActivities.map((activity: any, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-4 border rounded-lg"
                      >
                        <div className="flex items-center space-x-4">
                          <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                          <div>
                            <p className="font-medium">
                              {activity.type === "contact"
                                ? "New contact form"
                                : "New quote request"}
                            </p>
                            <p className="text-sm text-gray-500">
                              From: {activity.name} ({activity.email})
                            </p>
                          </div>
                        </div>
                        <div className="text-sm text-gray-400">
                          <Calendar className="w-4 h-4 inline mr-1" />
                          {new Date(activity.created_at).toLocaleDateString()}
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-gray-500 text-center py-8">
                      No recent activities
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="contacts">
            <Card>
              <CardHeader>
                <CardTitle>Contact Form Submissions</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500">
                  Contact management interface coming soon...
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="quotes">
            <Card>
              <CardHeader>
                <CardTitle>Quote Requests</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500">
                  Quote management interface coming soon...
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="newsletter">
            <Card>
              <CardHeader>
                <CardTitle>Newsletter Management</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500">
                  Newsletter management interface coming soon...
                </p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle>Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-500">
                  Settings interface coming soon...
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Admin;
