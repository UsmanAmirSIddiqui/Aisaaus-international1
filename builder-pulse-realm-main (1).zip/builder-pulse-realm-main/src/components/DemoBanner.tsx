import React, { useState, useEffect } from "react";
import { AlertTriangle, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const DemoBanner = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [isDemoMode, setIsDemoMode] = useState(false);

  useEffect(() => {
    // Check if we're in demo mode (not localhost)
    const isDemo =
      typeof window !== "undefined" &&
      window.location.hostname !== "localhost" &&
      window.location.hostname !== "127.0.0.1";

    setIsDemoMode(isDemo);

    // Only show banner in demo mode and if not previously dismissed
    if (isDemo && !localStorage.getItem("demo-banner-dismissed")) {
      setIsVisible(true);
    }
  }, []);

  const dismissBanner = () => {
    setIsVisible(false);
    localStorage.setItem("demo-banner-dismissed", "true");
  };

  if (!isVisible || !isDemoMode) {
    return null;
  }

  return (
    <div className="bg-orange-500 text-white py-2 px-4 relative">
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <AlertTriangle className="h-4 w-4" />
          <span className="text-sm font-medium">
            🚀 Demo Mode: Forms will show success messages but won't send actual
            emails. Backend functionality is available when deployed.
          </span>
        </div>
        <Button
          onClick={dismissBanner}
          variant="ghost"
          size="sm"
          className="text-white hover:bg-orange-600 h-6 w-6 p-0"
        >
          <X className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
};

export default DemoBanner;
