import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle, Factory, Apple, Gem, TrendingUp } from "lucide-react";

const History = () => {
  const timeline = [
    {
      year: "1999",
      event: "Company established - Petroleum import begins",
      icon: <Factory className="h-5 w-5" />,
    },
    {
      year: "2000",
      event: "Export of food products initiated",
      icon: <Apple className="h-5 w-5" />,
    },
    {
      year: "2005+",
      event: "Added minerals & gemstones to product range",
      icon: <Gem className="h-5 w-5" />,
    },
    {
      year: "Present",
      event: "1000+ employees, $200,000+ export record",
      icon: <TrendingUp className="h-5 w-5" />,
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              History & Goals
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our journey from a small trading company to a global enterprise
            </p>
          </div>

          {/* Journey Timeline */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">
              Journey Timeline
            </h2>
            <div className="space-y-6">
              {timeline.map((item, index) => (
                <div
                  key={index}
                  className="flex items-center bg-white p-6 rounded-lg shadow-sm"
                >
                  <div className="bg-orange-100 rounded-full p-3 mr-6 text-orange-500">
                    {item.icon}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-4">
                      <span className="text-2xl font-bold text-orange-500">
                        {item.year}
                      </span>
                      <span className="text-gray-600">{item.event}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Objectives */}
          <div className="bg-white rounded-xl p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">
              Our Objectives
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[
                "Fulfill customer needs with excellence",
                "Promote trade culture globally",
                "Maintain ethical dealings in all transactions",
                "Constant product range expansion",
                "Global opportunity exploration",
                "Build lasting international partnerships",
              ].map((objective, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <CheckCircle className="h-5 w-5 text-orange-500 mt-1 flex-shrink-0" />
                  <span className="text-gray-700">{objective}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default History;
