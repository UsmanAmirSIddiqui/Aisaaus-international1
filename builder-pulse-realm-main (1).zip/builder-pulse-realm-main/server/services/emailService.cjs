const nodemailer = require("nodemailer");
const { getDb } = require("../database/init.cjs");

// Email templates
const templates = {
  contact_notification: (data) => ({
    subject: `New Contact Form Submission - ${data.name}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #ea580c; color: white; padding: 20px; text-align: center;">
          <h1>New Contact Form Submission</h1>
          <p>AISAAUS International</p>
        </div>

        <div style="padding: 20px; background-color: #f9f9f9;">
          <h2>Contact Details</h2>
          <table style="width: 100%; border-collapse: collapse;">
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Name:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.name}</td>
            </tr>
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Email:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.email}</td>
            </tr>
            ${
              data.phone
                ? `
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Phone:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.phone}</td>
            </tr>
            `
                : ""
            }
            ${
              data.company
                ? `
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Company:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.company}</td>
            </tr>
            `
                : ""
            }
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Submission ID:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">#${data.submissionId}</td>
            </tr>
          </table>

          <h3>Message:</h3>
          <div style="background-color: white; padding: 15px; border-left: 4px solid #ea580c; margin: 10px 0;">
            ${data.message.replace(/\n/g, "<br>")}
          </div>

          <p style="color: #666; font-size: 14px; margin-top: 20px;">
            This email was automatically generated from the AISAAUS International website contact form.
          </p>
        </div>
      </div>
    `,
  }),

  contact_confirmation: (data) => ({
    subject: "Thank you for contacting AISAAUS International",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #ea580c; color: white; padding: 20px; text-align: center;">
          <h1>Thank You for Contacting Us</h1>
          <p>AISAAUS International</p>
        </div>

        <div style="padding: 20px;">
          <h2>Dear ${data.name},</h2>

          <p>Thank you for reaching out to AISAAUS International. We have received your message and will respond to your inquiry as soon as possible.</p>

          <div style="background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <p><strong>Your submission reference:</strong> #${data.submissionId}</p>
            <p><strong>Submitted on:</strong> ${new Date().toLocaleDateString()}</p>
          </div>

          <p>Our team typically responds within 24-48 hours during business days. If you have an urgent inquiry, please call us directly at:</p>

          <ul>
            <li>📞 +92 323 8088081</li>
            <li>📞 +92 321 4387645</li>
          </ul>

          <p>Thank you for your interest in AISAAUS International.</p>

          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd;">
            <p style="color: #666; font-size: 14px;">
              Best regards,<br>
              AISAAUS International Team<br>
              Global Trade: Connecting Worlds, Delivering Growth since 1999
            </p>
          </div>
        </div>
      </div>
    `,
  }),

  quote_notification: (data) => ({
    subject: `New Quote Request - ${data.company} (${data.productCategory})`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #ea580c; color: white; padding: 20px; text-align: center;">
          <h1>New Quote Request</h1>
          <p>AISAAUS International</p>
        </div>

        <div style="padding: 20px; background-color: #f9f9f9;">
          <h2>Quote Request Details</h2>
          <table style="width: 100%; border-collapse: collapse;">
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Quote ID:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">#${data.quoteId}</td>
            </tr>
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Company:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.company}</td>
            </tr>
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Contact Person:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.name}</td>
            </tr>
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Email:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.email}</td>
            </tr>
            ${
              data.phone
                ? `
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Phone:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.phone}</td>
            </tr>
            `
                : ""
            }
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Product Category:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.productCategory}</td>
            </tr>
            ${
              data.specificProducts
                ? `
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Specific Products:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.specificProducts}</td>
            </tr>
            `
                : ""
            }
            ${
              data.quantity
                ? `
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Quantity:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.quantity}</td>
            </tr>
            `
                : ""
            }
            ${
              data.budgetRange
                ? `
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Budget Range:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.budgetRange}</td>
            </tr>
            `
                : ""
            }
            ${
              data.deliveryLocation
                ? `
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Delivery Location:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.deliveryLocation}</td>
            </tr>
            `
                : ""
            }
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Urgency:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.urgency}</td>
            </tr>
          </table>

          ${
            data.message
              ? `
          <h3>Additional Message:</h3>
          <div style="background-color: white; padding: 15px; border-left: 4px solid #ea580c; margin: 10px 0;">
            ${data.message.replace(/\n/g, "<br>")}
          </div>
          `
              : ""
          }
        </div>
      </div>
    `,
  }),

  quote_confirmation: (data) => ({
    subject: "Quote Request Received - AISAAUS International",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #ea580c; color: white; padding: 20px; text-align: center;">
          <h1>Quote Request Received</h1>
          <p>AISAAUS International</p>
        </div>

        <div style="padding: 20px;">
          <h2>Dear ${data.name},</h2>

          <p>Thank you for your quote request for <strong>${data.productCategory}</strong> products. We have received your inquiry and our team is preparing a customized quote for ${data.company}.</p>

          <div style="background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <p><strong>Quote Reference:</strong> #${data.quoteId}</p>
            <p><strong>Product Category:</strong> ${data.productCategory}</p>
            <p><strong>Submitted on:</strong> ${new Date().toLocaleDateString()}</p>
          </div>

          <h3>What happens next?</h3>
          <ul>
            <li>Our product specialists will review your requirements</li>
            <li>We'll prepare a detailed quote with pricing and specifications</li>
            <li>You'll receive your quote within 24-48 hours</li>
            <li>Our team will follow up to discuss any questions</li>
          </ul>

          <p>If you have any urgent questions, please contact us directly:</p>
          <ul>
            <li>📞 +92 323 8088081</li>
            <li>📞 +92 321 4387645</li>
            <li>📧 aisaausinternational@yahoo.com</li>
          </ul>

          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd;">
            <p style="color: #666; font-size: 14px;">
              Best regards,<br>
              AISAAUS International Sales Team<br>
              Global Trade: Connecting Worlds, Delivering Growth since 1999
            </p>
          </div>
        </div>
      </div>
    `,
  }),

  newsletter_welcome: (data) => ({
    subject: "Welcome to AISAAUS International Newsletter",
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #ea580c; color: white; padding: 20px; text-align: center;">
          <h1>Welcome to Our Newsletter</h1>
          <p>AISAAUS International</p>
        </div>

        <div style="padding: 20px;">
          <h2>Dear ${data.name},</h2>

          <p>Welcome to the AISAAUS International newsletter! We're excited to have you join our community of global trade professionals.</p>

          <h3>What you can expect:</h3>
          <ul>
            <li>📈 Market insights and trade opportunities</li>
            <li>🌍 Global industry news and updates</li>
            <li>🚀 New product announcements</li>
            <li>💼 Business partnerships and collaborations</li>
            <li>📊 Quarterly performance reports</li>
          </ul>

          <p>Stay connected with AISAAUS International and never miss important updates from the world of international trade.</p>

          <div style="background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 20px 0; text-align: center;">
            <p><strong>Follow us on social media:</strong></p>
            <p>
              <a href="https://www.linkedin.com/in/aisaaus-international-085356315" style="color: #ea580c; text-decoration: none;">LinkedIn</a> |
              <a href="https://www.instagram.com/aisaausinternational1" style="color: #ea580c; text-decoration: none;">Instagram</a> |
              <a href="https://www.facebook.com/share/1C6a1udtCJ/" style="color: #ea580c; text-decoration: none;">Facebook</a> |
              <a href="https://x.com/Aisaaus1" style="color: #ea580c; text-decoration: none;">Twitter</a>
            </p>
          </div>

          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd;">
            <p style="color: #666; font-size: 14px;">
              Best regards,<br>
              AISAAUS International Team<br>
              Global Trade: Connecting Worlds, Delivering Growth since 1999
            </p>
          </div>
        </div>
      </div>
    `,
  }),

  product_inquiry_notification: (data) => ({
    subject: `New Product Inquiry - ${data.productName} (${data.inquiryType})`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #ea580c; color: white; padding: 20px; text-align: center;">
          <h1>New Product Inquiry</h1>
          <p>AISAAUS International</p>
        </div>

        <div style="padding: 20px; background-color: #f9f9f9;">
          <h2>Product Inquiry Details</h2>
          <table style="width: 100%; border-collapse: collapse;">
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Inquiry ID:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">#${data.inquiryId}</td>
            </tr>
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Product:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.productName}</td>
            </tr>
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Category:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.productCategory}</td>
            </tr>
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Inquiry Type:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.inquiryType}</td>
            </tr>
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Contact:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.name}</td>
            </tr>
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Email:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.email}</td>
            </tr>
            ${
              data.phone
                ? `
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Phone:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.phone}</td>
            </tr>
            `
                : ""
            }
            ${
              data.company
                ? `
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Company:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.company}</td>
            </tr>
            `
                : ""
            }
            ${
              data.quantity
                ? `
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Quantity:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.quantity}</td>
            </tr>
            `
                : ""
            }
            ${
              data.specifications
                ? `
            <tr>
              <td style="padding: 8px; border-bottom: 1px solid #ddd; font-weight: bold;">Specifications:</td>
              <td style="padding: 8px; border-bottom: 1px solid #ddd;">${data.specifications}</td>
            </tr>
            `
                : ""
            }
          </table>

          ${
            data.message
              ? `
          <h3>Additional Message:</h3>
          <div style="background-color: white; padding: 15px; border-left: 4px solid #ea580c; margin: 10px 0;">
            ${data.message.replace(/\n/g, "<br>")}
          </div>
          `
              : ""
          }
        </div>
      </div>
    `,
  }),

  product_inquiry_confirmation: (data) => ({
    subject: `Product Inquiry Received - ${data.productName}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background-color: #ea580c; color: white; padding: 20px; text-align: center;">
          <h1>Product Inquiry Received</h1>
          <p>AISAAUS International</p>
        </div>

        <div style="padding: 20px;">
          <h2>Dear ${data.name},</h2>

          <p>Thank you for your inquiry about <strong>${data.productName}</strong>. We have received your ${data.inquiryType.toLowerCase()} inquiry and our product specialists are reviewing your requirements.</p>

          <div style="background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <p><strong>Inquiry Reference:</strong> #${data.inquiryId}</p>
            <p><strong>Product:</strong> ${data.productName}</p>
            <p><strong>Inquiry Type:</strong> ${data.inquiryType}</p>
            <p><strong>Submitted on:</strong> ${new Date().toLocaleDateString()}</p>
          </div>

          <p>Our team will respond to your inquiry within 24-48 hours with detailed information. If you have any urgent questions, please contact us directly at:</p>

          <ul>
            <li>📞 +92 323 8088081</li>
            <li>���� +92 321 4387645</li>
            <li>📧 aisaausinternational@yahoo.com</li>
          </ul>

          <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #ddd;">
            <p style="color: #666; font-size: 14px;">
              Best regards,<br>
              AISAAUS International Product Team<br>
              Global Trade: Connecting Worlds, Delivering Growth since 1999
            </p>
          </div>
        </div>
      </div>
    `,
  }),
};

// Create email transporter
const createTransporter = () => {
  return nodemailer.createTransporter({
    service: "gmail",
    auth: {
      user: process.env.EMAIL_USER || "aisaausinternational@gmail.com",
      pass: process.env.EMAIL_PASS || "your-app-password",
    },
  });
};

// Send email function
const sendEmail = async ({ to, subject, template, data }) => {
  const db = getDb();

  try {
    const transporter = createTransporter();

    let emailContent;
    if (template && templates[template]) {
      emailContent = templates[template](data);
      subject = emailContent.subject;
    } else {
      emailContent = {
        subject,
        html: data.content || data.message || "No content provided",
      };
    }

    const mailOptions = {
      from: `"AISAAUS International" <${process.env.EMAIL_USER || "aisaausinternational@gmail.com"}>`,
      to,
      subject,
      html: emailContent.html,
    };

    const result = await transporter.sendMail(mailOptions);

    // Log email
    db.run(
      `INSERT INTO email_logs (to_email, subject, template_name, status)
       VALUES (?, ?, ?, ?)`,
      [to, subject, template || "custom", "sent"],
      (err) => {
        if (err) console.error("Error logging email:", err);
      },
    );

    return result;
  } catch (error) {
    // Log failed email
    db.run(
      `INSERT INTO email_logs (to_email, subject, template_name, status, error_message)
       VALUES (?, ?, ?, ?, ?)`,
      [to, subject, template || "custom", "failed", error.message],
      (err) => {
        if (err) console.error("Error logging email failure:", err);
      },
    );

    throw error;
  }
};

module.exports = {
  sendEmail,
  templates,
};
