import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Menu,
  X,
  Instagram,
  Twitter,
  Linkedin,
  Facebook,
  Mail,
} from "lucide-react";
import {
  LanguageSelector,
  MobileLanguageSelector,
} from "@/components/LanguageSelector";
import { useLanguage } from "@/contexts/LanguageContext";
import { api } from "@/services/api";
import { toast } from "sonner";

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [isSubscribing, setIsSubscribing] = useState(false);
  const location = useLocation();
  const { t } = useLanguage();

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail) return;

    setIsSubscribing(true);
    try {
      const response = await api.newsletter.subscribe({
        email: newsletterEmail,
      });

      if (response.success) {
        toast.success("Successfully subscribed to newsletter! 🎉");
        setNewsletterEmail("");
      } else {
        toast.error(response.error || "Failed to subscribe");
      }
    } catch (error) {
      toast.error("Failed to subscribe. Please try again.");
    } finally {
      setIsSubscribing(false);
    }
  };

  const isActive = (path: string) => location.pathname === path;

  const companyPages = [
    { name: "About Us", path: "/about" },
    { name: "History & Goals", path: "/history" },
    { name: "Mission & Vision", path: "/mission" },
    { name: "Team", path: "/team" },
    { name: "Leadership", path: "/team" },
  ];

  const businessPages = [
    { name: "Products", path: "/products" },
    { name: "Services", path: "/services" },
    { name: "Partners", path: "/partners" },
    { name: "Case Studies", path: "/case-studies" },
    { name: "Global Reach", path: "/global-reach" },
  ];

  const resourcesPages = [
    { name: "News & Updates", path: "/news" },
    { name: "Gallery", path: "/gallery" },
    { name: "FAQ", path: "/faq" },
    { name: "Careers", path: "/careers" },
    { name: "Testimonials", path: "/testimonials" },
  ];

  const corporatePages = [
    { name: "Quality Standards", path: "/quality-standards" },
    { name: "Certifications", path: "/certifications" },
    { name: "Sustainability", path: "/sustainability" },
    { name: "Investor Relations", path: "/investor-relations" },
  ];

  const allMobilePages = [
    ...companyPages,
    ...businessPages,
    ...resourcesPages,
    ...corporatePages,
    { name: "Contact", path: "/contact" },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link to="/" className="flex items-center">
              <img
                src="https://cdn.builder.io/api/v1/assets/6972a23af08b4c8da669c410b76f80e9/whatsapp-image-2025-06-13-at-01.32.31_1d695da1-4d564d?format=webp&width=800"
                alt="AISAAUS International"
                className="h-12 w-auto"
              />
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex space-x-8">
              <a
                href="#home"
                className="text-gray-700 hover:text-orange-500 transition-colors scroll-smooth"
              >
                {t("nav.home")}
              </a>
              <a
                href="#company"
                className="text-gray-700 hover:text-orange-500 transition-colors scroll-smooth"
              >
                {t("nav.company")}
              </a>
              <a
                href="#business"
                className="text-gray-700 hover:text-orange-500 transition-colors scroll-smooth"
              >
                {t("nav.business")}
              </a>
              <a
                href="#team"
                className="text-gray-700 hover:text-orange-500 transition-colors scroll-smooth"
              >
                {t("nav.team")}
              </a>
              <a
                href="#contact"
                className="text-gray-700 hover:text-orange-500 transition-colors scroll-smooth"
              >
                {t("nav.contact")}
              </a>
            </nav>

            <div className="hidden lg:flex items-center space-x-4">
              <LanguageSelector />
              <Button
                variant="outline"
                className="border-orange-500 text-orange-500 hover:bg-orange-500 hover:text-white"
                asChild
              >
                <Link to="/contact">{t("nav.getQuote")}</Link>
              </Button>
              <Button className="bg-orange-500 hover:bg-orange-600" asChild>
                <Link to="/products">{t("nav.viewCatalog")}</Link>
              </Button>
            </div>

            {/* Mobile menu button */}
            <button
              className="lg:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="lg:hidden pb-4">
              <nav className="flex flex-col space-y-2">
                <a
                  href="#home"
                  onClick={() => setIsMenuOpen(false)}
                  className="text-left text-gray-700 hover:text-orange-500 py-2 scroll-smooth"
                >
                  {t("nav.home")}
                </a>
                <a
                  href="#company"
                  onClick={() => setIsMenuOpen(false)}
                  className="text-left text-gray-700 hover:text-orange-500 py-2 scroll-smooth"
                >
                  {t("nav.company")}
                </a>
                <a
                  href="#business"
                  onClick={() => setIsMenuOpen(false)}
                  className="text-left text-gray-700 hover:text-orange-500 py-2 scroll-smooth"
                >
                  {t("nav.business")}
                </a>
                <a
                  href="#team"
                  onClick={() => setIsMenuOpen(false)}
                  className="text-left text-gray-700 hover:text-orange-500 py-2 scroll-smooth"
                >
                  {t("nav.team")}
                </a>
                <a
                  href="#contact"
                  onClick={() => setIsMenuOpen(false)}
                  className="text-left text-gray-700 hover:text-orange-500 py-2 scroll-smooth"
                >
                  {t("nav.contact")}
                </a>
              </nav>
              <div className="flex flex-col space-y-2 mt-4">
                <MobileLanguageSelector />
                <Button
                  variant="outline"
                  className="border-orange-500 text-orange-500"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <a href="#contact">{t("nav.getQuote")}</a>
                </Button>
                <Button
                  className="bg-orange-500 hover:bg-orange-600"
                  onClick={() => setIsMenuOpen(false)}
                >
                  <a href="#business">{t("nav.viewCatalog")}</a>
                </Button>
              </div>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main>{children}</main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-8">
            <div className="lg:col-span-2">
              <Link to="/" className="flex items-center mb-4" />
              <p className="text-gray-400 mb-4">{t("footer.tagline")}</p>
              <p className="text-sm text-gray-400">{t("footer.location")}</p>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Business</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li>
                  <a
                    href="#business"
                    className="hover:text-orange-500 transition-colors"
                  >
                    Products
                  </a>
                </li>
                <li>
                  <a
                    href="#business"
                    className="hover:text-orange-500 transition-colors"
                  >
                    Services
                  </a>
                </li>
                <li>
                  <a
                    href="#business"
                    className="hover:text-orange-500 transition-colors"
                  >
                    Global Reach
                  </a>
                </li>
                <li>Petroleum & Byproducts</li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li>
                  <a
                    href="#company"
                    className="hover:text-orange-500 transition-colors"
                  >
                    About Us
                  </a>
                </li>
                <li>
                  <a
                    href="#team"
                    className="hover:text-orange-500 transition-colors"
                  >
                    Team
                  </a>
                </li>
                <li>
                  <a
                    href="#company"
                    className="hover:text-orange-500 transition-colors"
                  >
                    Mission & Vision
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Contact</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li>📞 03238088081</li>
                <li>📞 03214387645</li>
                <li>📧 aisaausinternational@yahoo.com</li>
                <li>
                  <a
                    href="#contact"
                    className="hover:text-orange-500 transition-colors"
                  >
                    Contact Form
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold mb-4">Newsletter</h4>
              <p className="text-gray-400 text-sm mb-4">
                Stay updated with our latest news and trade opportunities
              </p>
              <form onSubmit={handleNewsletterSubmit} className="space-y-3">
                <div className="flex">
                  <Input
                    type="email"
                    placeholder="Your email address"
                    value={newsletterEmail}
                    onChange={(e) => setNewsletterEmail(e.target.value)}
                    className="bg-gray-800 border-gray-700 text-white placeholder-gray-400 rounded-r-none"
                    required
                  />
                  <Button
                    type="submit"
                    className="bg-orange-500 hover:bg-orange-600 rounded-l-none px-3"
                    disabled={isSubscribing}
                  >
                    <Mail className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-xs text-gray-500">
                  We respect your privacy. Unsubscribe at any time.
                </p>
              </form>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8">
            {/* Social Media Links */}
            <div className="flex justify-center space-x-6 mb-6">
              <a
                href="https://www.instagram.com/aisaausinternational1?igsh=OHM2bDJmeXNsMXRz"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-orange-500 transition-colors duration-300"
                aria-label="Follow us on Instagram"
              >
                <Instagram className="h-6 w-6" />
              </a>
              <a
                href="https://x.com/Aisaaus1?t=ca6T-ISJMOWLMIFO5a15NQ&s=09"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-orange-500 transition-colors duration-300"
                aria-label="Follow us on Twitter"
              >
                <Twitter className="h-6 w-6" />
              </a>
              <a
                href="https://www.linkedin.com/in/aisaaus-international-085356315?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-orange-500 transition-colors duration-300"
                aria-label="Connect with us on LinkedIn"
              >
                <Linkedin className="h-6 w-6" />
              </a>
              <a
                href="https://www.facebook.com/share/1C6a1udtCJ/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-orange-500 transition-colors duration-300"
                aria-label="Like us on Facebook"
              >
                <Facebook className="h-6 w-6" />
              </a>
            </div>

            <div className="text-center text-gray-400">
              <p>
                <p>
                  © 1999 AISAAUS International. All rights reserved. "Our
                  customers are our top priority... Your success is our
                  mission."
                </p>{" "}
                Developed by{" "}
                <strong>
                  <em>Usman Amir</em>
                </strong>
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
