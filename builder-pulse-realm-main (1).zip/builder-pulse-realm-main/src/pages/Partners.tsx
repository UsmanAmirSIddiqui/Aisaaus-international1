import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Globe,
  Handshake,
  Building,
  Users,
  TrendingUp,
  Star,
  MapPin,
  CheckCircle,
} from "lucide-react";

const Partners = () => {
  const keyPartners = [
    {
      name: "Gulf Petroleum Ltd",
      type: "Strategic Partner",
      region: "Middle East",
      since: "2010",
      description: "Leading petroleum distributor in the Gulf region",
      image:
        "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=300&h=200&fit=crop",
    },
    {
      name: "European Food Networks",
      type: "Distribution Partner",
      region: "Europe",
      since: "2015",
      description: "Premium food products distributor across Europe",
      image:
        "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=300&h=200&fit=crop",
    },
    {
      name: "Asia Minerals Corp",
      type: "Sourcing Partner",
      region: "Asia Pacific",
      since: "2008",
      description: "Mineral and gemstone sourcing specialist",
      image:
        "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=300&h=200&fit=crop",
    },
    {
      name: "Atlantic Salt Industries",
      type: "Export Partner",
      region: "North America",
      since: "2018",
      description: "Salt products distributor in North American markets",
      image:
        "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=300&h=200&fit=crop",
    },
  ];

  const partnershipBenefits = [
    {
      title: "Global Network",
      description: "Access to our extensive international network",
      icon: <Globe className="h-6 w-6" />,
    },
    {
      title: "Quality Assurance",
      description: "Guaranteed quality standards and compliance",
      icon: <Star className="h-6 w-6" />,
    },
    {
      title: "Reliable Supply",
      description: "Consistent and timely product delivery",
      icon: <CheckCircle className="h-6 w-6" />,
    },
    {
      title: "Competitive Pricing",
      description: "Market-competitive rates and terms",
      icon: <TrendingUp className="h-6 w-6" />,
    },
    {
      title: "24/7 Support",
      description: "Round-the-clock customer service",
      icon: <Users className="h-6 w-6" />,
    },
    {
      title: "Long-term Commitment",
      description: "Building lasting business relationships",
      icon: <Handshake className="h-6 w-6" />,
    },
  ];

  const regions = [
    {
      name: "Middle East",
      partners: 45,
      description: "Strong presence in Gulf countries",
    },
    {
      name: "Europe",
      partners: 38,
      description: "Established networks across EU",
    },
    {
      name: "Asia Pacific",
      partners: 52,
      description: "Growing partnerships in Asia",
    },
    {
      name: "North America",
      partners: 28,
      description: "Expanding North American reach",
    },
    { name: "Africa", partners: 19, description: "Developing African markets" },
    {
      name: "South America",
      partners: 15,
      description: "Emerging partnerships",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <section className="py-20 bg-gradient-to-br from-orange-50 to-orange-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="bg-orange-100 text-orange-800 mb-6">
              🤝 Global Partnerships
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Our Partners
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              AISAAUS International has built strong partnerships with leading
              companies worldwide, creating a robust network for international
              trade.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-16">
            Key Strategic Partners
          </h2>

          <div className="grid md:grid-cols-2 gap-8 mb-16">
            {keyPartners.map((partner, index) => (
              <Card
                key={index}
                className="hover:shadow-lg transition-shadow overflow-hidden"
              >
                <div className="h-48 overflow-hidden">
                  <img
                    src={partner.image}
                    alt={partner.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <Badge className="bg-orange-100 text-orange-800">
                      {partner.type}
                    </Badge>
                    <div className="text-sm text-gray-500">
                      Since {partner.since}
                    </div>
                  </div>
                  <CardTitle className="text-xl">{partner.name}</CardTitle>
                  <div className="flex items-center text-orange-500">
                    <MapPin className="h-4 w-4 mr-1" />
                    <span className="text-sm">{partner.region}</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{partner.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="bg-gray-50 rounded-xl p-8">
            <h3 className="text-2xl font-bold text-center text-gray-900 mb-12">
              Partnership Benefits
            </h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {partnershipBenefits.map((benefit, index) => (
                <Card key={index} className="text-center">
                  <CardContent className="p-6">
                    <div className="bg-orange-100 rounded-full p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center text-orange-500">
                      {benefit.icon}
                    </div>
                    <h4 className="font-semibold text-gray-900 mb-2">
                      {benefit.title}
                    </h4>
                    <p className="text-sm text-gray-600">
                      {benefit.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-16">
            Global Reach
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            {regions.map((region, index) => (
              <Card
                key={index}
                className="text-center hover:shadow-md transition-shadow"
              >
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    {region.name}
                  </h3>
                  <div className="text-3xl font-bold text-orange-500 mb-2">
                    {region.partners}
                  </div>
                  <p className="text-sm text-gray-600 mb-2">Active Partners</p>
                  <p className="text-xs text-gray-500">{region.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Total Network Strength
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
              <div className="text-center">
                <div className="text-4xl font-bold text-orange-500">197</div>
                <div className="text-gray-600">Total Partners</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-orange-500">50+</div>
                <div className="text-gray-600">Countries</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-orange-500">25+</div>
                <div className="text-gray-600">Years Building</div>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-orange-500">98%</div>
                <div className="text-gray-600">Partner Satisfaction</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-orange-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">
            Become Our Partner
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Join our global network of successful partners and grow your
            business with AISAAUS International.
          </p>
          <Card className="max-w-lg mx-auto p-6 bg-white">
            <h3 className="font-semibold text-gray-900 mb-4">
              Partnership Opportunities
            </h3>
            <div className="space-y-2 text-sm text-gray-600 mb-6">
              <div className="flex items-center justify-center">
                <CheckCircle className="h-4 w-4 text-orange-500 mr-2" />
                Distribution partnerships
              </div>
              <div className="flex items-center justify-center">
                <CheckCircle className="h-4 w-4 text-orange-500 mr-2" />
                Sourcing partnerships
              </div>
              <div className="flex items-center justify-center">
                <CheckCircle className="h-4 w-4 text-orange-500 mr-2" />
                Strategic alliances
              </div>
            </div>
            <div className="bg-orange-100 rounded-lg p-4">
              <p className="text-orange-600 font-medium">
                Contact Us for Partnership
              </p>
            </div>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default Partners;
