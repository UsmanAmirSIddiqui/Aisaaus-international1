import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, Quote } from "lucide-react";

const Testimonials = () => {
  const testimonials = [
    {
      name: "Ahmed Al-Rashid",
      role: "CEO, Gulf Enterprises",
      company: "United Arab Emirates",
      content:
        "AISAAUS International has been our trusted partner for petroleum products for over 5 years. Their reliability and quality standards are exceptional.",
      rating: 5,
      image:
        "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
    },
    {
      name: "Sarah Mitchell",
      role: "Import Manager, FoodCorp Ltd",
      company: "United Kingdom",
      content:
        "The quality of food products from AISAAUS is outstanding. Their mangoes and spices have helped us expand our premium product line significantly.",
      rating: 5,
      image:
        "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face",
    },
    {
      name: "Chen Wei",
      role: "Procurement Director, Asia Minerals",
      company: "Singapore",
      content:
        "Their gemstone collection is remarkable. We've built a strong partnership over the years, and their service has always exceeded our expectations.",
      rating: 5,
      image:
        "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",
    },
    {
      name: "Maria Rodriguez",
      role: "Trading Manager, European Salt Co.",
      company: "Spain",
      content:
        "AISAAUS provides the finest Pink Himalayan salt we've ever sourced. Their consistency and packaging are perfect for our European markets.",
      rating: 5,
      image:
        "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face",
    },
    {
      name: "Robert Johnson",
      role: "Supply Chain Manager, Global Foods",
      company: "Canada",
      content:
        "Exceptional service and product quality. AISAAUS has been instrumental in helping us establish reliable supply chains for Pakistani products.",
      rating: 5,
      image:
        "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face",
    },
    {
      name: "Omar Hassan",
      role: "Director, Middle East Trading",
      company: "Saudi Arabia",
      content:
        "Professional, reliable, and always delivering on promises. AISAAUS International is our go-to partner for diverse product sourcing.",
      rating: 5,
      image:
        "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=100&h=100&fit=crop&crop=face",
    },
  ];

  const stats = [
    { number: "500+", label: "Happy Clients" },
    { number: "98%", label: "Customer Satisfaction" },
    { number: "25+", label: "Years of Trust" },
    { number: "50+", label: "Countries Served" },
  ];

  return (
    <div className="min-h-screen bg-white">
      <section className="py-20 bg-gradient-to-br from-orange-50 to-orange-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="bg-orange-100 text-orange-800 mb-6">
              ⭐ Client Success Stories
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              What Our Clients Say
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Don't just take our word for it. Here's what our valued clients
              around the world have to say about working with AISAAUS
              International.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {testimonials.map((testimonial, index) => (
              <Card
                key={index}
                className="hover:shadow-lg transition-shadow relative"
              >
                <CardContent className="p-6">
                  <Quote className="h-8 w-8 text-orange-500 mb-4" />
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star
                        key={i}
                        className="h-5 w-5 text-yellow-400 fill-current"
                      />
                    ))}
                  </div>
                  <p className="text-gray-600 mb-6 italic leading-relaxed">
                    "{testimonial.content}"
                  </p>
                  <div className="flex items-center">
                    <img
                      src={testimonial.image}
                      alt={testimonial.name}
                      className="w-12 h-12 rounded-full object-cover mr-4"
                    />
                    <div>
                      <p className="font-semibold text-gray-900">
                        {testimonial.name}
                      </p>
                      <p className="text-sm text-orange-500">
                        {testimonial.role}
                      </p>
                      <p className="text-xs text-gray-500">
                        {testimonial.company}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="bg-gray-50 rounded-xl p-8">
            <h2 className="text-2xl font-bold text-center text-gray-900 mb-8">
              Our Track Record
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="text-3xl font-bold text-orange-500 mb-2">
                    {stat.number}
                  </div>
                  <div className="text-gray-600">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">
            Join Our Satisfied Clients
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Experience the same level of excellence and reliability that has
            made our clients successful for over 25 years.
          </p>
          <Card className="max-w-md mx-auto p-6 bg-white">
            <h3 className="font-semibold text-gray-900 mb-2">
              Ready to Start?
            </h3>
            <p className="text-gray-600 text-sm mb-4">
              Contact us today and become our next success story
            </p>
            <div className="bg-orange-100 rounded-lg p-4">
              <p className="text-orange-600 font-medium">Get Your Quote Now</p>
            </div>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default Testimonials;
