import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Leaf,
  Recycle,
  Globe,
  Droplets,
  Zap,
  Users,
  Target,
  TreePine,
  CheckCircle,
  TrendingDown,
  Heart,
  Shield,
  Award,
  Factory,
} from "lucide-react";

const Sustainability = () => {
  const sustainabilityPillars = [
    {
      title: "Environmental Protection",
      description:
        "Minimizing our environmental footprint through responsible practices",
      icon: <Globe className="h-8 w-8" />,
      initiatives: [
        "Carbon emission reduction",
        "Waste minimization programs",
        "Water conservation",
        "Renewable energy adoption",
      ],
      color: "bg-green-100 text-green-500",
    },
    {
      title: "Social Responsibility",
      description:
        "Supporting communities and ensuring ethical business practices",
      icon: <Users className="h-8 w-8" />,
      initiatives: [
        "Employee welfare programs",
        "Community development",
        "Fair trade practices",
        "Educational initiatives",
      ],
      color: "bg-blue-100 text-blue-500",
    },
    {
      title: "Economic Sustainability",
      description: "Creating long-term value for all stakeholders",
      icon: <TrendingDown className="h-8 w-8" />,
      initiatives: [
        "Sustainable growth strategies",
        "Local supplier development",
        "Innovation investments",
        "Stakeholder value creation",
      ],
      color: "bg-purple-100 text-purple-500",
    },
    {
      title: "Product Stewardship",
      description: "Ensuring responsible sourcing and production",
      icon: <Shield className="h-8 w-8" />,
      initiatives: [
        "Sustainable sourcing",
        "Quality assurance",
        "Product lifecycle management",
        "Circular economy principles",
      ],
      color: "bg-orange-100 text-orange-500",
    },
  ];

  const environmentalMetrics = [
    {
      metric: "Carbon Footprint Reduction",
      value: "25%",
      baseline: "Since 2020",
      icon: <Leaf className="h-6 w-6" />,
    },
    {
      metric: "Waste Recycling Rate",
      value: "85%",
      baseline: "Company-wide",
      icon: <Recycle className="h-6 w-6" />,
    },
    {
      metric: "Water Conservation",
      value: "30%",
      baseline: "Usage reduction",
      icon: <Droplets className="h-6 w-6" />,
    },
    {
      metric: "Renewable Energy",
      value: "40%",
      baseline: "Of total consumption",
      icon: <Zap className="h-6 w-6" />,
    },
    {
      metric: "Sustainable Packaging",
      value: "90%",
      baseline: "Eco-friendly materials",
      icon: <TreePine className="h-6 w-6" />,
    },
    {
      metric: "Employee Satisfaction",
      value: "95%",
      baseline: "Annual survey",
      icon: <Heart className="h-6 w-6" />,
    },
  ];

  const greenInitiatives = [
    {
      title: "Solar Energy Installation",
      description:
        "Installing solar panels across all facilities to reduce carbon footprint",
      status: "In Progress",
      completion: "75%",
      impact: "Reduces CO2 emissions by 500 tons annually",
      investment: "$2M",
    },
    {
      title: "Zero Waste to Landfill",
      description:
        "Comprehensive waste management program targeting zero waste",
      status: "Active",
      completion: "90%",
      impact: "85% waste recycling rate achieved",
      investment: "$500K",
    },
    {
      title: "Sustainable Packaging Program",
      description:
        "Transition to biodegradable and recyclable packaging materials",
      status: "Active",
      completion: "95%",
      impact: "90% of packaging now eco-friendly",
      investment: "$1.5M",
    },
    {
      title: "Water Treatment Facility",
      description: "On-site water treatment and recycling facility",
      status: "Completed",
      completion: "100%",
      impact: "30% reduction in water consumption",
      investment: "$3M",
    },
  ];

  const socialImpact = [
    {
      program: "Education Scholarship Fund",
      beneficiaries: "200+ students",
      description: "Annual scholarships for underprivileged students",
      investment: "$100K annually",
    },
    {
      program: "Healthcare Access Program",
      beneficiaries: "1000+ employees",
      description:
        "Comprehensive healthcare coverage for all employees and families",
      investment: "$500K annually",
    },
    {
      program: "Community Development",
      beneficiaries: "5 local communities",
      description:
        "Infrastructure and facility development in local communities",
      investment: "$300K annually",
    },
    {
      program: "Women Empowerment Initiative",
      beneficiaries: "150+ women",
      description: "Training and employment opportunities for women",
      investment: "$200K annually",
    },
  ];

  const certifications = [
    {
      name: "ISO 14001:2015",
      type: "Environmental Management",
      validUntil: "2026",
      description:
        "International standard for environmental management systems",
    },
    {
      name: "OHSAS 45001",
      type: "Occupational Health & Safety",
      validUntil: "2025",
      description: "International standard for occupational health and safety",
    },
    {
      name: "Fair Trade Certification",
      type: "Ethical Trading",
      validUntil: "2025",
      description: "Ensures fair wages and working conditions",
    },
    {
      name: "Organic Certification",
      type: "Product Quality",
      validUntil: "2024",
      description: "Certified organic products and processes",
    },
  ];

  const targets2030 = [
    {
      goal: "Carbon Neutral Operations",
      target: "50% reduction in CO2 emissions",
      timeline: "2030",
      progress: "25%",
    },
    {
      goal: "100% Renewable Energy",
      target: "Complete transition to renewable sources",
      timeline: "2028",
      progress: "40%",
    },
    {
      goal: "Zero Waste to Landfill",
      target: "100% waste recycling or reuse",
      timeline: "2026",
      progress: "85%",
    },
    {
      goal: "Sustainable Supply Chain",
      target: "100% certified sustainable suppliers",
      timeline: "2027",
      progress: "60%",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <section className="py-20 bg-gradient-to-br from-green-50 to-green-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="bg-green-100 text-green-800 mb-6">
              🌱 Sustainable Future
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Sustainability
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              AISAAUS International is committed to creating a sustainable
              future through responsible business practices, environmental
              stewardship, and positive social impact.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Sustainability Pillars */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
              Our Sustainability Framework
            </h2>
            <div className="grid md:grid-cols-2 gap-8">
              {sustainabilityPillars.map((pillar, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div
                      className={`rounded-lg p-3 w-fit ${pillar.color} mb-4`}
                    >
                      {pillar.icon}
                    </div>
                    <CardTitle className="text-xl">{pillar.title}</CardTitle>
                    <p className="text-gray-600">{pillar.description}</p>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {pillar.initiatives.map((initiative, i) => (
                        <li
                          key={i}
                          className="flex items-center text-sm text-gray-700"
                        >
                          <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                          {initiative}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Environmental Metrics */}
          <Card className="mb-16">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Leaf className="h-6 w-6 text-green-500 mr-3" />
                Sustainability Metrics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {environmentalMetrics.map((metric, index) => (
                  <div
                    key={index}
                    className="text-center p-4 bg-gray-50 rounded-lg"
                  >
                    <div className="bg-green-100 rounded-full p-3 w-12 h-12 mx-auto mb-3 flex items-center justify-center text-green-500">
                      {metric.icon}
                    </div>
                    <div className="text-3xl font-bold text-green-600 mb-1">
                      {metric.value}
                    </div>
                    <div className="text-gray-700 font-medium mb-1">
                      {metric.metric}
                    </div>
                    <div className="text-sm text-gray-500">
                      {metric.baseline}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Green Initiatives */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-center text-gray-900 mb-12">
              Green Initiatives
            </h3>
            <div className="space-y-6">
              {greenInitiatives.map((initiative, index) => (
                <Card key={index}>
                  <CardContent className="p-6">
                    <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
                      <div className="flex-1 mb-4 lg:mb-0">
                        <div className="flex items-center mb-2">
                          <h3 className="font-semibold text-gray-900 mr-3">
                            {initiative.title}
                          </h3>
                          <Badge
                            className={
                              initiative.status === "Completed"
                                ? "bg-green-100 text-green-800"
                                : initiative.status === "Active"
                                  ? "bg-blue-100 text-blue-800"
                                  : "bg-yellow-100 text-yellow-800"
                            }
                          >
                            {initiative.status}
                          </Badge>
                        </div>
                        <p className="text-gray-600 mb-2">
                          {initiative.description}
                        </p>
                        <p className="text-sm text-green-600 font-medium">
                          {initiative.impact}
                        </p>
                      </div>
                      <div className="lg:ml-6 lg:w-64">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm text-gray-600">
                            Progress
                          </span>
                          <span className="text-sm font-medium">
                            {initiative.completion}
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                          <div
                            className="bg-green-500 h-2 rounded-full"
                            style={{ width: initiative.completion }}
                          ></div>
                        </div>
                        <div className="text-sm text-gray-500">
                          Investment: {initiative.investment}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Social Impact */}
          <Card className="mb-16">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Heart className="h-6 w-6 text-red-500 mr-3" />
                Social Impact Programs
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                {socialImpact.map((program, index) => (
                  <div
                    key={index}
                    className="border rounded-lg p-4 hover:bg-gray-50"
                  >
                    <h3 className="font-semibold text-gray-900 mb-2">
                      {program.program}
                    </h3>
                    <p className="text-gray-600 text-sm mb-3">
                      {program.description}
                    </p>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-blue-600 font-medium">
                        {program.beneficiaries}
                      </span>
                      <span className="text-gray-500">
                        {program.investment}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 2030 Targets */}
          <Card className="mb-16">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="h-6 w-6 text-orange-500 mr-3" />
                2030 Sustainability Targets
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {targets2030.map((target, index) => (
                  <div key={index} className="border-l-4 border-green-500 pl-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-gray-900">
                        {target.goal}
                      </h3>
                      <span className="text-sm text-gray-500">
                        Target: {target.timeline}
                      </span>
                    </div>
                    <p className="text-gray-600 text-sm mb-3">
                      {target.target}
                    </p>
                    <div className="flex items-center">
                      <div className="flex-1 bg-gray-200 rounded-full h-2 mr-3">
                        <div
                          className="bg-green-500 h-2 rounded-full"
                          style={{ width: target.progress }}
                        ></div>
                      </div>
                      <span className="text-sm text-gray-600">
                        {target.progress} Complete
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Certifications */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Award className="h-6 w-6 text-yellow-500 mr-3" />
                Sustainability Certifications
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                {certifications.map((cert, index) => (
                  <div
                    key={index}
                    className="border rounded-lg p-4 hover:bg-gray-50"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="font-semibold text-gray-900">
                          {cert.name}
                        </h3>
                        <p className="text-orange-500 text-sm">{cert.type}</p>
                      </div>
                      <Badge className="bg-green-100 text-green-800">
                        Valid until {cert.validUntil}
                      </Badge>
                    </div>
                    <p className="text-gray-600 text-sm">{cert.description}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="py-16 bg-green-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Join Our Sustainability Journey
            </h2>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Partner with us to create a more sustainable future for
              generations to come. Together, we can make a meaningful
              difference.
            </p>
            <Card className="max-w-md mx-auto p-6 bg-white">
              <h3 className="font-semibold text-gray-900 mb-4">
                Sustainability Partnerships
              </h3>
              <p className="text-gray-600 text-sm mb-4">
                Collaborate with us on sustainability initiatives and green
                business practices
              </p>
              <div className="space-y-2 text-sm mb-4">
                <div className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Environmental impact reduction
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Sustainable supply chain development
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                  Community development programs
                </div>
              </div>
              <div className="bg-green-100 rounded-lg p-4">
                <p className="text-green-600 font-medium">Learn More</p>
              </div>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Sustainability;
