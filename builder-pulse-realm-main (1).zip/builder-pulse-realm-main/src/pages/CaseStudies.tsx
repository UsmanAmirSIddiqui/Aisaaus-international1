import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  TrendingUp,
  Globe,
  Target,
  CheckCircle,
  Calendar,
  Users,
  DollarSign,
  Award,
} from "lucide-react";

const CaseStudies = () => {
  const caseStudies = [
    {
      title: "European Food Chain Expansion",
      client: "EuroFresh Markets",
      category: "Food Products",
      duration: "18 months",
      challenge:
        "A major European supermarket chain needed reliable supply of premium Pakistani mangoes and rice for their expanding organic product line.",
      solution:
        "We established a direct supply chain with quality-certified Pakistani farmers and implemented cold-chain logistics to maintain product freshness.",
      results: [
        "300% increase in order volume",
        "99.2% on-time delivery rate",
        "15% cost reduction through direct sourcing",
        "Expansion to 12 new European markets",
      ],
      image:
        "https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&h=250&fit=crop",
      metrics: {
        revenue: "$2.5M",
        growth: "300%",
        satisfaction: "98%",
      },
    },
    {
      title: "Middle East Petroleum Distribution",
      client: "Gulf Energy Corporation",
      category: "Petroleum Products",
      duration: "2 years",
      challenge:
        "Regional energy company required consistent supply of high-grade petroleum products to meet growing demand in the Gulf region.",
      solution:
        "Developed strategic partnerships with Pakistani refineries and established dedicated shipping routes with quality assurance protocols.",
      results: [
        "Consistent monthly supply of 10,000+ tons",
        "Zero quality-related issues",
        "25% faster delivery times",
        "Long-term exclusive partnership agreement",
      ],
      image:
        "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=250&fit=crop",
      metrics: {
        revenue: "$8.2M",
        growth: "180%",
        satisfaction: "100%",
      },
    },
    {
      title: "Luxury Gemstone Collection",
      client: "Premier Jewelers International",
      category: "Minerals & Gemstones",
      duration: "12 months",
      challenge:
        "High-end jewelry manufacturer needed access to rare Pakistani gemstones including emerald crystal and quartz for their luxury collections.",
      solution:
        "Established relationships with certified gemstone miners and implemented authentication processes for quality verification.",
      results: [
        "Sourced 500+ carats of premium gemstones",
        "100% authenticity certification",
        "Featured in international jewelry exhibitions",
        "Ongoing exclusive supply agreement",
      ],
      image:
        "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=400&h=250&fit=crop",
      metrics: {
        revenue: "$1.8M",
        growth: "420%",
        satisfaction: "96%",
      },
    },
    {
      title: "Pink Salt Global Distribution",
      client: "Health Foods International",
      category: "Salt Products",
      duration: "24 months",
      challenge:
        "Health-focused food distributor wanted to introduce premium Pink Himalayan salt to North American and European wellness markets.",
      solution:
        "Created comprehensive branding and packaging solutions while ensuring sustainable mining practices and quality certifications.",
      results: [
        "Launched in 200+ health food stores",
        "Achieved organic certification",
        "Won 'Best Natural Product' award",
        "Expanded to 8 countries",
      ],
      image:
        "https://images.unsplash.com/photo-1582719471137-c3967ffb1c42?w=400&h=250&fit=crop",
      metrics: {
        revenue: "$950K",
        growth: "250%",
        satisfaction: "94%",
      },
    },
  ];

  const successMetrics = [
    {
      icon: <DollarSign className="h-8 w-8" />,
      value: "$50M+",
      label: "Total Project Value",
    },
    {
      icon: <TrendingUp className="h-8 w-8" />,
      value: "95%",
      label: "Success Rate",
    },
    {
      icon: <Users className="h-8 w-8" />,
      value: "200+",
      label: "Successful Projects",
    },
    {
      icon: <Globe className="h-8 w-8" />,
      value: "40+",
      label: "Countries Served",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <section className="py-20 bg-gradient-to-br from-orange-50 to-orange-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="bg-orange-100 text-orange-800 mb-6">
              📈 Success Stories
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Case Studies
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Discover how AISAAUS International has helped businesses worldwide
              achieve their goals through strategic partnerships and innovative
              solutions.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
            {successMetrics.map((metric, index) => (
              <Card key={index} className="text-center">
                <CardContent className="p-6">
                  <div className="bg-orange-100 rounded-full p-3 w-16 h-16 mx-auto mb-4 flex items-center justify-center text-orange-500">
                    {metric.icon}
                  </div>
                  <div className="text-2xl font-bold text-gray-900 mb-1">
                    {metric.value}
                  </div>
                  <div className="text-sm text-gray-600">{metric.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="space-y-12">
            {caseStudies.map((study, index) => (
              <Card
                key={index}
                className="overflow-hidden hover:shadow-lg transition-shadow"
              >
                <div className="grid lg:grid-cols-2 gap-8">
                  <div className="order-2 lg:order-1">
                    <CardHeader>
                      <div className="flex items-center justify-between mb-4">
                        <Badge className="bg-orange-100 text-orange-800">
                          {study.category}
                        </Badge>
                        <div className="flex items-center text-gray-500 text-sm">
                          <Calendar className="h-4 w-4 mr-1" />
                          {study.duration}
                        </div>
                      </div>
                      <CardTitle className="text-2xl mb-2">
                        {study.title}
                      </CardTitle>
                      <p className="text-orange-500 font-semibold">
                        {study.client}
                      </p>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-6">
                        <div>
                          <h4 className="font-semibold text-gray-900 mb-2 flex items-center">
                            <Target className="h-4 w-4 mr-2 text-orange-500" />
                            Challenge
                          </h4>
                          <p className="text-gray-600 text-sm">
                            {study.challenge}
                          </p>
                        </div>

                        <div>
                          <h4 className="font-semibold text-gray-900 mb-2 flex items-center">
                            <CheckCircle className="h-4 w-4 mr-2 text-orange-500" />
                            Solution
                          </h4>
                          <p className="text-gray-600 text-sm">
                            {study.solution}
                          </p>
                        </div>

                        <div>
                          <h4 className="font-semibold text-gray-900 mb-3 flex items-center">
                            <Award className="h-4 w-4 mr-2 text-orange-500" />
                            Results
                          </h4>
                          <ul className="space-y-1">
                            {study.results.map((result, i) => (
                              <li
                                key={i}
                                className="flex items-start text-sm text-gray-600"
                              >
                                <CheckCircle className="h-4 w-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                                {result}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="bg-gray-50 rounded-lg p-4">
                          <h4 className="font-semibold text-gray-900 mb-3">
                            Key Metrics
                          </h4>
                          <div className="grid grid-cols-3 gap-4 text-center">
                            <div>
                              <div className="text-lg font-bold text-orange-500">
                                {study.metrics.revenue}
                              </div>
                              <div className="text-xs text-gray-600">
                                Revenue Generated
                              </div>
                            </div>
                            <div>
                              <div className="text-lg font-bold text-orange-500">
                                {study.metrics.growth}
                              </div>
                              <div className="text-xs text-gray-600">
                                Growth Achieved
                              </div>
                            </div>
                            <div>
                              <div className="text-lg font-bold text-orange-500">
                                {study.metrics.satisfaction}
                              </div>
                              <div className="text-xs text-gray-600">
                                Client Satisfaction
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </div>

                  <div className="order-1 lg:order-2">
                    <img
                      src={study.image}
                      alt={study.title}
                      className="w-full h-full object-cover min-h-[300px]"
                    />
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">
            Ready to Create Your Success Story?
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Let AISAAUS International help you achieve similar results. Contact
            us to discuss your project requirements.
          </p>
          <Card className="max-w-md mx-auto p-6 bg-white">
            <h3 className="font-semibold text-gray-900 mb-2">
              Start Your Project
            </h3>
            <p className="text-gray-600 text-sm mb-4">
              Schedule a consultation to discuss your specific needs and how we
              can help you succeed.
            </p>
            <div className="bg-orange-100 rounded-lg p-4">
              <p className="text-orange-600 font-medium">Get Started Today</p>
            </div>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default CaseStudies;
