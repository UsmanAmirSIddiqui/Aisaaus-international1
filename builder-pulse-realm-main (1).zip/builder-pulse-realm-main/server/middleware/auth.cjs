const jwt = require("jsonwebtoken");
const { getDb } = require("../database/init.cjs");

const authenticateAdmin = async (req, res, next) => {
  try {
    const token = req.header("Authorization")?.replace("Bearer ", "");

    if (!token) {
      return res.status(401).json({
        success: false,
        error: "Access denied. No token provided.",
      });
    }

    const decoded = jwt.verify(
      token,
      process.env.JWT_SECRET || "your-secret-key",
    );

    // Check if admin still exists and is active
    const db = getDb();
    const admin = await new Promise((resolve, reject) => {
      db.get(
        "SELECT id, username, email, role, is_active FROM admin_users WHERE id = ? AND is_active = 1",
        [decoded.id],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        },
      );
    });

    if (!admin) {
      return res.status(401).json({
        success: false,
        error: "Access denied. Invalid token.",
      });
    }

    req.admin = admin;
    next();
  } catch (error) {
    console.error("Authentication error:", error);
    res.status(401).json({
      success: false,
      error: "Access denied. Invalid token.",
    });
  }
};

const requireSuperAdmin = (req, res, next) => {
  if (req.admin.role !== "super_admin") {
    return res.status(403).json({
      success: false,
      error: "Access denied. Super admin privileges required.",
    });
  }
  next();
};

module.exports = {
  authenticateAdmin,
  requireSuperAdmin,
};
