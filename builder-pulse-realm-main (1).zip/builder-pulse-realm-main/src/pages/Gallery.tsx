import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Building,
  Users,
  Package,
  Truck,
  Award,
  Globe,
  Camera,
  Play,
  Download,
} from "lucide-react";

const Gallery = () => {
  const galleryCategories = [
    { name: "All", count: 48 },
    { name: "Facilities", count: 12 },
    { name: "Team", count: 15 },
    { name: "Products", count: 18 },
    { name: "Events", count: 8 },
    { name: "Awards", count: 5 },
  ];

  const galleryItems = [
    {
      id: 1,
      title: "AISAAUS International Headquarters",
      category: "Facilities",
      type: "image",
      image:
        "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=400&h=300&fit=crop",
      description: "Our modern headquarters in Lahore, Pakistan",
    },
    {
      id: 2,
      title: "Annual Team Conference 2024",
      category: "Team",
      type: "image",
      image:
        "https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=400&h=300&fit=crop",
      description: "Leadership team gathering for strategic planning",
    },
    {
      id: 3,
      title: "Premium Himalayan Pink Salt",
      category: "Products",
      type: "image",
      image:
        "https://images.unsplash.com/photo-1582719471137-c3967ffb1c42?w=400&h=300&fit=crop",
      description: "Our signature pink salt products ready for export",
    },
    {
      id: 4,
      title: "Quality Testing Laboratory",
      category: "Facilities",
      type: "image",
      image:
        "https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=400&h=300&fit=crop",
      description: "State-of-the-art testing facilities",
    },
    {
      id: 5,
      title: "Export Operations Overview",
      category: "Facilities",
      type: "video",
      image:
        "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=300&fit=crop",
      description: "Behind the scenes of our export operations",
    },
    {
      id: 6,
      title: "Gemstone Collection Display",
      category: "Products",
      type: "image",
      image:
        "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?w=400&h=300&fit=crop",
      description: "Rare gemstones from Pakistan mines",
    },
    {
      id: 7,
      title: "CEO Dr. Amir Siddiqui at Trade Expo",
      category: "Events",
      type: "image",
      image:
        "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=300&fit=crop",
      description: "CEO presenting at international trade exhibition",
    },
    {
      id: 8,
      title: "Organic Food Products Range",
      category: "Products",
      type: "image",
      image:
        "https://images.unsplash.com/photo-1542838132-92c53300491e?w=400&h=300&fit=crop",
      description: "Certified organic food products for export",
    },
    {
      id: 9,
      title: "Packaging and Logistics Center",
      category: "Facilities",
      type: "image",
      image:
        "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400&h=300&fit=crop",
      description: "Modern packaging facility ensuring product safety",
    },
    {
      id: 10,
      title: "International Trade Award 2024",
      category: "Awards",
      type: "image",
      image:
        "https://images.unsplash.com/photo-1523050854058-8df90110c9d1?w=400&h=300&fit=crop",
      description: "Recognition for excellence in international trade",
    },
    {
      id: 11,
      title: "Team Building Workshop",
      category: "Team",
      type: "image",
      image:
        "https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=400&h=300&fit=crop",
      description: "Professional development and team building activities",
    },
    {
      id: 12,
      title: "Petroleum Products Storage",
      category: "Products",
      type: "image",
      image:
        "https://images.unsplash.com/photo-1613123428120-8b7c7c0e6f5e?w=400&h=300&fit=crop",
      description: "Secure storage facilities for petroleum products",
    },
  ];

  const [activeCategory, setActiveCategory] = React.useState("All");
  const [selectedItem, setSelectedItem] = React.useState(null);

  const filteredItems =
    activeCategory === "All"
      ? galleryItems
      : galleryItems.filter((item) => item.category === activeCategory);

  return (
    <div className="min-h-screen bg-white">
      <section className="py-20 bg-gradient-to-br from-orange-50 to-orange-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="bg-orange-100 text-orange-800 mb-6">
              📸 Visual Journey
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Photo & Video Gallery
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Explore AISAAUS International through images and videos showcasing
              our facilities, team, products, and achievements over 25 years of
              operation.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-2 mb-12">
            {galleryCategories.map((category, index) => (
              <Button
                key={index}
                variant={
                  activeCategory === category.name ? "default" : "outline"
                }
                className={`${
                  activeCategory === category.name
                    ? "bg-orange-500 hover:bg-orange-600"
                    : "border-orange-500 text-orange-500 hover:bg-orange-500 hover:text-white"
                }`}
                onClick={() => setActiveCategory(category.name)}
              >
                {category.name} ({category.count})
              </Button>
            ))}
          </div>

          {/* Gallery Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredItems.map((item) => (
              <Card
                key={item.id}
                className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer group"
                onClick={() => setSelectedItem(item)}
              >
                <div className="relative">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-300 flex items-center justify-center">
                    {item.type === "video" ? (
                      <Play className="h-12 w-12 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                    ) : (
                      <Camera className="h-12 w-12 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                    )}
                  </div>
                  <Badge
                    className={`absolute top-2 right-2 ${
                      item.category === "Facilities"
                        ? "bg-blue-100 text-blue-800"
                        : item.category === "Team"
                          ? "bg-green-100 text-green-800"
                          : item.category === "Products"
                            ? "bg-purple-100 text-purple-800"
                            : item.category === "Events"
                              ? "bg-orange-100 text-orange-800"
                              : "bg-yellow-100 text-yellow-800"
                    }`}
                  >
                    {item.category}
                  </Badge>
                  {item.type === "video" && (
                    <div className="absolute bottom-2 left-2">
                      <Badge className="bg-black bg-opacity-70 text-white">
                        <Play className="h-3 w-3 mr-1" />
                        Video
                      </Badge>
                    </div>
                  )}
                </div>
                <CardContent className="p-4">
                  <h3 className="font-semibold text-gray-900 mb-1 text-sm">
                    {item.title}
                  </h3>
                  <p className="text-xs text-gray-600">{item.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Company Highlights */}
          <div className="mt-20 bg-gray-50 rounded-xl p-8">
            <h2 className="text-2xl font-bold text-center text-gray-900 mb-8">
              Visual Highlights
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                {
                  icon: <Building className="h-8 w-8" />,
                  title: "Modern Facilities",
                  description: "State-of-the-art infrastructure",
                },
                {
                  icon: <Users className="h-8 w-8" />,
                  title: "Professional Team",
                  description: "1000+ dedicated employees",
                },
                {
                  icon: <Package className="h-8 w-8" />,
                  title: "Quality Products",
                  description: "Premium international standards",
                },
                {
                  icon: <Award className="h-8 w-8" />,
                  title: "Industry Recognition",
                  description: "Multiple awards and certifications",
                },
              ].map((highlight, index) => (
                <Card key={index} className="text-center">
                  <CardContent className="p-6">
                    <div className="bg-orange-100 rounded-full p-3 w-16 h-16 mx-auto mb-4 flex items-center justify-center text-orange-500">
                      {highlight.icon}
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-2">
                      {highlight.title}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {highlight.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">
            Request High-Resolution Images
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Need high-quality images for your publication or presentation?
            Contact us for press kit and media resources.
          </p>
          <Card className="max-w-md mx-auto p-6 bg-gray-50">
            <h3 className="font-semibold text-gray-900 mb-4">
              Media Resources
            </h3>
            <p className="text-gray-600 text-sm mb-4">
              Access our complete media kit including logos, product images, and
              company photos
            </p>
            <Button className="w-full bg-orange-500 hover:bg-orange-600">
              <Download className="h-4 w-4 mr-2" />
              Download Media Kit
            </Button>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default Gallery;
