import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  HelpCircle,
  Globe,
  Package,
  Shield,
  CreditCard,
  Truck,
  Clock,
  Phone,
} from "lucide-react";

const FAQ = () => {
  const faqCategories = [
    {
      title: "General Questions",
      icon: <HelpCircle className="h-6 w-6" />,
      faqs: [
        {
          question: "What is AISAAUS International?",
          answer:
            "AISAAUS International is a leading Pakistani trading company established in 1999, specializing in international trade of petroleum products, minerals, gemstones, food items, and salt products. We serve clients across 50+ countries with over 1000 employees.",
        },
        {
          question: "How long has AISAAUS been in business?",
          answer:
            "We have been operating since 1999, giving us over 25 years of experience in international trade and export-import operations.",
        },
        {
          question: "What countries do you operate in?",
          answer:
            "We operate globally with active partnerships in over 50 countries across Middle East, Europe, Asia Pacific, North America, Africa, and South America.",
        },
        {
          question: "Who leads the company?",
          answer:
            "AISAAUS International is led by our Founder & CEO Dr. Amir Siddiqui, along with division managers Umar Amir Siddiqui (Food Division), Usman Amir Siddiqui (Minerals Division), and Sherjeel Amir Siddiqui (Petroleum Division).",
        },
      ],
    },
    {
      title: "Products & Services",
      icon: <Package className="h-6 w-6" />,
      faqs: [
        {
          question: "What products do you trade?",
          answer:
            "We trade in four main categories: 1) Petroleum products (SN500 Base Oil, Paraffin Wax, Petroleum Jelly, etc.), 2) Minerals & Gemstones (Silica Sand, Dolomite, Emerald, Quartz Crystal, Aluminium Ore, Copper, etc.), 3) Food items (meat, fruits, vegetables, concentrates), and 4) Salt products (Pink Himalayan Salt, White Edible Salt).",
        },
        {
          question: "Do you provide custom packaging?",
          answer:
            "Yes, we offer custom packaging solutions tailored to your market requirements and branding needs, ensuring products meet international standards and regulations.",
        },
        {
          question: "What services do you offer besides trading?",
          answer:
            "We provide comprehensive services including supply chain management, quality assurance, logistics coordination, documentation support, market intelligence, and business consulting.",
        },
        {
          question: "Can you source specific products not in your catalog?",
          answer:
            "Yes, we can source specific products based on your requirements. Our extensive network in Pakistan allows us to locate and supply various products according to your specifications.",
        },
      ],
    },
    {
      title: "Quality & Certifications",
      icon: <Shield className="h-6 w-6" />,
      faqs: [
        {
          question: "What quality certifications do you have?",
          answer:
            "We hold multiple international certifications including ISO 9001:2015 (Quality Management), ISO 14001:2015 (Environmental Management), HACCP Certification (Food Safety), and various export licenses.",
        },
        {
          question: "How do you ensure product quality?",
          answer:
            "We maintain rigorous quality control processes with third-party testing, international standard compliance, state-of-the-art testing laboratories, and continuous improvement programs.",
        },
        {
          question: "Are your food products organic certified?",
          answer:
            "Yes, many of our food products carry organic certifications. We work with certified organic farmers and maintain strict organic standards throughout the supply chain.",
        },
        {
          question: "Do you provide certificates of origin?",
          answer:
            "Yes, we provide all necessary documentation including certificates of origin, quality certificates, test reports, and any other required trade documents.",
        },
      ],
    },
    {
      title: "Ordering & Payments",
      icon: <CreditCard className="h-6 w-6" />,
      faqs: [
        {
          question: "What are your minimum order quantities?",
          answer:
            "Minimum order quantities vary by product category. Generally, petroleum products require larger volumes, while gemstones have lower minimums. Contact us for specific MOQ details.",
        },
        {
          question: "What payment terms do you accept?",
          answer:
            "We accept various payment terms including Letter of Credit (L/C), Telegraphic Transfer (T/T), and other mutually agreed terms based on the relationship and order value.",
        },
        {
          question: "How do I place an order?",
          answer:
            "You can place orders by contacting our sales team through phone, email, or our website contact form. We'll provide detailed quotations and guide you through the ordering process.",
        },
        {
          question: "Do you offer credit terms for regular customers?",
          answer:
            "Yes, we offer flexible credit terms for established customers based on their payment history and order volume. Terms are negotiated on a case-by-case basis.",
        },
      ],
    },
    {
      title: "Shipping & Logistics",
      icon: <Truck className="h-6 w-6" />,
      faqs: [
        {
          question: "What shipping methods do you use?",
          answer:
            "We use various shipping methods including sea freight, air freight, and land transportation depending on the product type, destination, and urgency requirements.",
        },
        {
          question: "What are your typical delivery times?",
          answer:
            "Delivery times vary by destination and shipping method. Typically, sea freight takes 15-30 days, air freight 3-7 days, and land transport varies by distance. We provide specific timelines for each order.",
        },
        {
          question: "Do you handle customs clearance?",
          answer:
            "Yes, we assist with customs clearance and provide all necessary documentation. We work with experienced freight forwarders and customs agents worldwide.",
        },
        {
          question: "Can you arrange door-to-door delivery?",
          answer:
            "Yes, we can arrange complete door-to-door delivery services including pickup from our facilities, shipping, customs clearance, and final delivery to your specified location.",
        },
      ],
    },
    {
      title: "Support & Contact",
      icon: <Phone className="h-6 w-6" />,
      faqs: [
        {
          question: "How can I contact customer support?",
          answer:
            "You can reach our customer support team via phone at 03238088081 or 03214387645, email at aisaausinternational@yahoo.com, or through our website contact form. We provide 24/7 support for urgent matters.",
        },
        {
          question: "Do you provide technical support for products?",
          answer:
            "Yes, our technical team provides comprehensive product support including specifications, application guidance, and troubleshooting assistance.",
        },
        {
          question: "Can I visit your facilities?",
          answer:
            "Yes, we welcome visits to our facilities in Lahore, Pakistan. Please schedule in advance by contacting our office so we can arrange proper reception and facility tours.",
        },
        {
          question: "Do you attend international trade shows?",
          answer:
            "Yes, we regularly participate in international trade exhibitions and conferences. Check our news section for upcoming events where you can meet our team.",
        },
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <section className="py-20 bg-gradient-to-br from-orange-50 to-orange-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="bg-orange-100 text-orange-800 mb-6">
              ❓ Help Center
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Frequently Asked Questions
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Find answers to commonly asked questions about AISAAUS
              International, our products, services, and business processes.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-8">
            {faqCategories.map((category, categoryIndex) => (
              <Card key={categoryIndex}>
                <CardHeader>
                  <CardTitle className="flex items-center text-xl">
                    <div className="bg-orange-100 rounded-lg p-2 mr-3 text-orange-500">
                      {category.icon}
                    </div>
                    {category.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Accordion type="single" collapsible className="w-full">
                    {category.faqs.map((faq, faqIndex) => (
                      <AccordionItem
                        key={faqIndex}
                        value={`item-${categoryIndex}-${faqIndex}`}
                      >
                        <AccordionTrigger className="text-left">
                          {faq.question}
                        </AccordionTrigger>
                        <AccordionContent>
                          <p className="text-gray-600 leading-relaxed">
                            {faq.answer}
                          </p>
                        </AccordionContent>
                      </AccordionItem>
                    ))}
                  </Accordion>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Need More Help?
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              Can't find what you're looking for? Our team is here to help.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <Card className="text-center">
              <CardContent className="p-6">
                <div className="bg-orange-100 rounded-full p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center">
                  <Phone className="h-6 w-6 text-orange-500" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Call Us</h3>
                <p className="text-gray-600 text-sm mb-2">
                  Speak directly with our team
                </p>
                <p className="text-orange-500 font-medium">03238088081</p>
                <p className="text-orange-500 font-medium">03214387645</p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-6">
                <div className="bg-orange-100 rounded-full p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center">
                  <Globe className="h-6 w-6 text-orange-500" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">
                  Email Support
                </h3>
                <p className="text-gray-600 text-sm mb-2">
                  Get detailed assistance via email
                </p>
                <p className="text-orange-500 font-medium text-sm">
                  aisaausinternational@yahoo.com
                </p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-6">
                <div className="bg-orange-100 rounded-full p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center">
                  <Clock className="h-6 w-6 text-orange-500" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">
                  Business Hours
                </h3>
                <p className="text-gray-600 text-sm mb-2">Monday - Friday</p>
                <p className="text-orange-500 font-medium">
                  9:00 AM - 6:00 PM PKT
                </p>
                <p className="text-gray-500 text-xs">24/7 for urgent matters</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
};

export default FAQ;
