const sqlite3 = require("sqlite3").verbose();
const path = require("path");
const fs = require("fs");
const bcrypt = require("bcryptjs");

// Ensure database directory exists
const dbDir = path.join(__dirname, "../data");
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

const dbPath = path.join(dbDir, "aisaaus.db");
let db;

const init = () => {
  return new Promise((resolve, reject) => {
    db = new sqlite3.Database(dbPath, (err) => {
      if (err) {
        console.error("Error opening database:", err.message);
        reject(err);
        return;
      }
      console.log("✅ Connected to SQLite database");

      // Create tables
      createTables()
        .then(() => createDefaultAdmin())
        .then(() => resolve())
        .catch(reject);
    });
  });
};

const createTables = () => {
  return new Promise((resolve, reject) => {
    const tables = [
      // Contact submissions table
      `CREATE TABLE IF NOT EXISTS contacts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT,
        company TEXT,
        message TEXT NOT NULL,
        source TEXT DEFAULT 'contact_form',
        status TEXT DEFAULT 'new',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,

      // Quote requests table
      `CREATE TABLE IF NOT EXISTS quotes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT,
        company TEXT NOT NULL,
        product_category TEXT NOT NULL,
        specific_products TEXT,
        quantity TEXT,
        budget_range TEXT,
        delivery_location TEXT,
        urgency TEXT DEFAULT 'standard',
        message TEXT,
        status TEXT DEFAULT 'pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,

      // Newsletter subscriptions table
      `CREATE TABLE IF NOT EXISTS newsletter_subscribers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        name TEXT,
        status TEXT DEFAULT 'active',
        source TEXT DEFAULT 'website',
        subscribed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        unsubscribed_at DATETIME
      )`,

      // Product inquiries table
      `CREATE TABLE IF NOT EXISTS product_inquiries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT,
        company TEXT,
        product_name TEXT NOT NULL,
        product_category TEXT NOT NULL,
        inquiry_type TEXT NOT NULL,
        quantity TEXT,
        specifications TEXT,
        message TEXT,
        status TEXT DEFAULT 'new',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,

      // Admin users table
      `CREATE TABLE IF NOT EXISTS admin_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT DEFAULT 'admin',
        is_active INTEGER DEFAULT 1,
        last_login DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,

      // Email logs table
      `CREATE TABLE IF NOT EXISTS email_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        to_email TEXT NOT NULL,
        subject TEXT NOT NULL,
        template_name TEXT,
        status TEXT NOT NULL,
        error_message TEXT,
        sent_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
    ];

    let completed = 0;
    tables.forEach((sql, index) => {
      db.run(sql, (err) => {
        if (err) {
          console.error(`Error creating table ${index}:`, err.message);
          reject(err);
          return;
        }
        completed++;
        if (completed === tables.length) {
          console.log("✅ All database tables created successfully");
          resolve();
        }
      });
    });
  });
};

const createDefaultAdmin = () => {
  return new Promise((resolve, reject) => {
    // Check if admin already exists
    db.get(
      "SELECT id FROM admin_users WHERE username = ?",
      ["admin"],
      (err, row) => {
        if (err) {
          reject(err);
          return;
        }

        if (row) {
          console.log("✅ Default admin user already exists");
          resolve();
          return;
        }

        // Create default admin user
        const password = "admin123"; // Change this in production
        bcrypt.hash(password, 10, (err, hash) => {
          if (err) {
            reject(err);
            return;
          }

          db.run(
            `INSERT INTO admin_users (username, email, password_hash, role) 
             VALUES (?, ?, ?, ?)`,
            ["admin", "admin@aisaaus.com", hash, "super_admin"],
            (err) => {
              if (err) {
                reject(err);
                return;
              }
              console.log("✅ Default admin user created");
              console.log(
                "🔑 Login: admin / admin123 (Please change password!)",
              );
              resolve();
            },
          );
        });
      },
    );
  });
};

const getDb = () => db;

const close = () => {
  if (db) {
    db.close((err) => {
      if (err) {
        console.error("Error closing database:", err.message);
      } else {
        console.log("Database connection closed");
      }
    });
  }
};

module.exports = {
  init,
  getDb,
  close,
};
