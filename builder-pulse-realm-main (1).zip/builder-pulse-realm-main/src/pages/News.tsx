import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Calendar,
  User,
  ArrowRight,
  TrendingUp,
  Globe,
  Award,
  Handshake,
} from "lucide-react";

const News = () => {
  const featuredNews = {
    title: "AISAAUS International Expands Operations to South America",
    excerpt:
      "Company announces strategic partnerships in Brazil and Argentina, marking a significant milestone in global expansion efforts.",
    date: "2024-03-15",
    author: "Corporate Communications",
    image:
      "https://images.unsplash.com/photo-1569025690938-a00729c9e1f3?w=600&h=300&fit=crop",
    category: "Expansion",
  };

  const newsArticles = [
    {
      title: "Record-Breaking Export Performance in Q1 2024",
      excerpt:
        "AISAAUS International achieves highest quarterly export figures, surpassing $5M in international trade volume.",
      date: "2024-03-10",
      author: "Finance Department",
      category: "Financial",
      image:
        "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=300&h=200&fit=crop",
    },
    {
      title: "New ISO 45001 Certification for Occupational Health & Safety",
      excerpt:
        "Company receives internationally recognized certification for workplace safety management systems.",
      date: "2024-03-05",
      author: "Quality Assurance",
      category: "Certification",
      image:
        "https://images.unsplash.com/photo-1521737604893-d14cc237f11d?w=300&h=200&fit=crop",
    },
    {
      title: "Partnership with European Organic Food Distributors",
      excerpt:
        "Strategic alliance formed to supply certified organic Pakistani products to European markets.",
      date: "2024-02-28",
      author: "Business Development",
      category: "Partnership",
      image:
        "https://images.unsplash.com/photo-1542838132-92c53300491e?w=300&h=200&fit=crop",
    },
    {
      title: "Sustainability Initiative: Green Packaging Solutions",
      excerpt:
        "Launch of eco-friendly packaging program for all salt and food products, reducing environmental impact by 40%.",
      date: "2024-02-20",
      author: "Environmental Team",
      category: "Sustainability",
      image:
        "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?w=300&h=200&fit=crop",
    },
    {
      title: "Industry Award: Best International Trading Company 2024",
      excerpt:
        "AISAAUS International honored at the Pakistan Export Awards for outstanding contribution to international trade.",
      date: "2024-02-15",
      author: "Corporate Communications",
      category: "Award",
      image:
        "https://images.unsplash.com/photo-1523050854058-8df90110c9d1?w=300&h=200&fit=crop",
    },
    {
      title: "New State-of-the-Art Quality Testing Laboratory",
      excerpt:
        "Investment in advanced testing facility ensures highest quality standards for all product categories.",
      date: "2024-02-10",
      author: "Operations Team",
      category: "Infrastructure",
      image:
        "https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=300&h=200&fit=crop",
    },
  ];

  const categories = [
    { name: "All", count: 15 },
    { name: "Expansion", count: 3 },
    { name: "Financial", count: 4 },
    { name: "Partnership", count: 5 },
    { name: "Award", count: 2 },
    { name: "Sustainability", count: 1 },
  ];

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Expansion":
        return <Globe className="h-4 w-4" />;
      case "Financial":
        return <TrendingUp className="h-4 w-4" />;
      case "Partnership":
        return <Handshake className="h-4 w-4" />;
      case "Award":
        return <Award className="h-4 w-4" />;
      default:
        return <Calendar className="h-4 w-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Expansion":
        return "bg-blue-100 text-blue-800";
      case "Financial":
        return "bg-green-100 text-green-800";
      case "Partnership":
        return "bg-purple-100 text-purple-800";
      case "Award":
        return "bg-yellow-100 text-yellow-800";
      case "Certification":
        return "bg-orange-100 text-orange-800";
      case "Sustainability":
        return "bg-emerald-100 text-emerald-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <section className="py-20 bg-gradient-to-br from-orange-50 to-orange-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="bg-orange-100 text-orange-800 mb-6">
              📰 Latest Updates
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              News & Updates
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Stay informed about AISAAUS International's latest developments,
              achievements, and industry insights.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Featured News */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold text-gray-900 mb-8">
              Featured News
            </h2>
            <Card className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="grid lg:grid-cols-2">
                <div className="order-2 lg:order-1">
                  <CardHeader>
                    <div className="flex items-center gap-4 mb-4">
                      <Badge
                        className={getCategoryColor(featuredNews.category)}
                      >
                        {getCategoryIcon(featuredNews.category)}
                        <span className="ml-1">{featuredNews.category}</span>
                      </Badge>
                      <div className="flex items-center text-gray-500 text-sm">
                        <Calendar className="h-4 w-4 mr-1" />
                        {formatDate(featuredNews.date)}
                      </div>
                    </div>
                    <CardTitle className="text-2xl mb-4">
                      {featuredNews.title}
                    </CardTitle>
                    <p className="text-gray-600 leading-relaxed">
                      {featuredNews.excerpt}
                    </p>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center text-sm text-gray-500">
                        <User className="h-4 w-4 mr-1" />
                        {featuredNews.author}
                      </div>
                      <button className="flex items-center text-orange-500 hover:text-orange-600 font-medium">
                        Read More <ArrowRight className="h-4 w-4 ml-1" />
                      </button>
                    </div>
                  </CardContent>
                </div>
                <div className="order-1 lg:order-2">
                  <img
                    src={featuredNews.image}
                    alt={featuredNews.title}
                    className="w-full h-full object-cover min-h-[300px]"
                  />
                </div>
              </div>
            </Card>
          </div>

          <div className="grid lg:grid-cols-4 gap-8">
            {/* Categories Sidebar */}
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Categories</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {categories.map((category, index) => (
                      <li key={index}>
                        <button className="w-full text-left px-3 py-2 rounded-lg hover:bg-orange-50 flex items-center justify-between">
                          <span className="text-gray-700">{category.name}</span>
                          <Badge variant="secondary" className="text-xs">
                            {category.count}
                          </Badge>
                        </button>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>

            {/* News Articles */}
            <div className="lg:col-span-3">
              <h2 className="text-2xl font-bold text-gray-900 mb-8">
                Recent News
              </h2>
              <div className="grid md:grid-cols-2 gap-6">
                {newsArticles.map((article, index) => (
                  <Card
                    key={index}
                    className="hover:shadow-lg transition-shadow"
                  >
                    <div className="h-48 overflow-hidden">
                      <img
                        src={article.image}
                        alt={article.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <CardHeader>
                      <div className="flex items-center justify-between mb-3">
                        <Badge className={getCategoryColor(article.category)}>
                          {getCategoryIcon(article.category)}
                          <span className="ml-1">{article.category}</span>
                        </Badge>
                        <div className="text-xs text-gray-500">
                          {formatDate(article.date)}
                        </div>
                      </div>
                      <CardTitle className="text-lg leading-tight">
                        {article.title}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 text-sm mb-4 leading-relaxed">
                        {article.excerpt}
                      </p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center text-xs text-gray-500">
                          <User className="h-3 w-3 mr-1" />
                          {article.author}
                        </div>
                        <button className="text-orange-500 hover:text-orange-600 text-sm font-medium flex items-center">
                          Read More <ArrowRight className="h-3 w-3 ml-1" />
                        </button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">
            Stay Updated
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Subscribe to our newsletter to receive the latest news and updates
            about AISAAUS International.
          </p>
          <Card className="max-w-md mx-auto p-6 bg-white">
            <h3 className="font-semibold text-gray-900 mb-4">
              Newsletter Subscription
            </h3>
            <p className="text-gray-600 text-sm mb-4">
              Get weekly updates on company news, industry insights, and
              business opportunities.
            </p>
            <div className="bg-orange-100 rounded-lg p-4">
              <p className="text-orange-600 font-medium">Subscribe Now</p>
            </div>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default News;
