const express = require("express");
const router = express.Router();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { getDb } = require("../database/init.cjs");
const { authenticateAdmin } = require("../middleware/auth.cjs");

// Admin login
router.post("/login", async (req, res) => {
  const { username, password } = req.body;
  const db = getDb();

  try {
    // Find admin user
    const admin = await new Promise((resolve, reject) => {
      db.get(
        "SELECT * FROM admin_users WHERE (username = ? OR email = ?) AND is_active = 1",
        [username, username],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        },
      );
    });

    if (!admin) {
      return res.status(401).json({
        success: false,
        error: "Invalid credentials",
      });
    }

    // Verify password
    const isValidPassword = await bcrypt.compare(password, admin.password_hash);
    if (!isValidPassword) {
      return res.status(401).json({
        success: false,
        error: "Invalid credentials",
      });
    }

    // Update last login
    await new Promise((resolve, reject) => {
      db.run(
        "UPDATE admin_users SET last_login = CURRENT_TIMESTAMP WHERE id = ?",
        [admin.id],
        (err) => {
          if (err) reject(err);
          else resolve();
        },
      );
    });

    // Generate JWT token
    const token = jwt.sign(
      {
        id: admin.id,
        username: admin.username,
        email: admin.email,
        role: admin.role,
      },
      process.env.JWT_SECRET || "your-secret-key",
      { expiresIn: "24h" },
    );

    res.json({
      success: true,
      message: "Login successful",
      token,
      admin: {
        id: admin.id,
        username: admin.username,
        email: admin.email,
        role: admin.role,
        last_login: admin.last_login,
      },
    });
  } catch (error) {
    console.error("Error during admin login:", error);
    res.status(500).json({
      success: false,
      error: "Login failed",
    });
  }
});

// Get dashboard statistics
router.get("/dashboard", authenticateAdmin, async (req, res) => {
  const db = getDb();

  try {
    // Get overview statistics
    const stats = await Promise.all([
      // Contacts
      new Promise((resolve, reject) => {
        db.get(
          `SELECT
            COUNT(*) as total,
            COUNT(CASE WHEN status = 'new' THEN 1 END) as new_contacts,
            COUNT(CASE WHEN DATE(created_at) = DATE('now') THEN 1 END) as today
           FROM contacts`,
          [],
          (err, row) => {
            if (err) reject(err);
            else resolve({ type: "contacts", ...row });
          },
        );
      }),

      // Quotes
      new Promise((resolve, reject) => {
        db.get(
          `SELECT
            COUNT(*) as total,
            COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending,
            COUNT(CASE WHEN DATE(created_at) = DATE('now') THEN 1 END) as today
           FROM quotes`,
          [],
          (err, row) => {
            if (err) reject(err);
            else resolve({ type: "quotes", ...row });
          },
        );
      }),

      // Newsletter
      new Promise((resolve, reject) => {
        db.get(
          `SELECT
            COUNT(*) as total,
            COUNT(CASE WHEN status = 'active' THEN 1 END) as active,
            COUNT(CASE WHEN DATE(subscribed_at) = DATE('now') THEN 1 END) as today
           FROM newsletter_subscribers`,
          [],
          (err, row) => {
            if (err) reject(err);
            else resolve({ type: "newsletter", ...row });
          },
        );
      }),

      // Product Inquiries
      new Promise((resolve, reject) => {
        db.get(
          `SELECT
            COUNT(*) as total,
            COUNT(CASE WHEN status = 'new' THEN 1 END) as new_inquiries,
            COUNT(CASE WHEN DATE(created_at) = DATE('now') THEN 1 END) as today
           FROM product_inquiries`,
          [],
          (err, row) => {
            if (err) reject(err);
            else resolve({ type: "product_inquiries", ...row });
          },
        );
      }),
    ]);

    // Get recent activities
    const recentContacts = await new Promise((resolve, reject) => {
      db.all(
        "SELECT 'contact' as type, name, email, created_at FROM contacts ORDER BY created_at DESC LIMIT 5",
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        },
      );
    });

    const recentQuotes = await new Promise((resolve, reject) => {
      db.all(
        "SELECT 'quote' as type, name, company, product_category, created_at FROM quotes ORDER BY created_at DESC LIMIT 5",
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        },
      );
    });

    // Combine and sort recent activities
    const recentActivities = [...recentContacts, ...recentQuotes]
      .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
      .slice(0, 10);

    res.json({
      success: true,
      data: {
        overview: stats,
        recentActivities,
      },
    });
  } catch (error) {
    console.error("Error fetching dashboard data:", error);
    res.status(500).json({
      success: false,
      error: "Failed to fetch dashboard data",
    });
  }
});

// Change admin password
router.patch("/change-password", authenticateAdmin, async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  const adminId = req.admin.id;
  const db = getDb();

  try {
    // Get current admin
    const admin = await new Promise((resolve, reject) => {
      db.get(
        "SELECT password_hash FROM admin_users WHERE id = ?",
        [adminId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        },
      );
    });

    // Verify current password
    const isValidPassword = await bcrypt.compare(
      currentPassword,
      admin.password_hash,
    );
    if (!isValidPassword) {
      return res.status(400).json({
        success: false,
        error: "Current password is incorrect",
      });
    }

    // Hash new password
    const newPasswordHash = await bcrypt.hash(newPassword, 10);

    // Update password
    await new Promise((resolve, reject) => {
      db.run(
        "UPDATE admin_users SET password_hash = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?",
        [newPasswordHash, adminId],
        (err) => {
          if (err) reject(err);
          else resolve();
        },
      );
    });

    res.json({
      success: true,
      message: "Password changed successfully",
    });
  } catch (error) {
    console.error("Error changing password:", error);
    res.status(500).json({
      success: false,
      error: "Failed to change password",
    });
  }
});

// Get admin profile
router.get("/profile", authenticateAdmin, async (req, res) => {
  const adminId = req.admin.id;
  const db = getDb();

  try {
    const admin = await new Promise((resolve, reject) => {
      db.get(
        "SELECT id, username, email, role, is_active, last_login, created_at FROM admin_users WHERE id = ?",
        [adminId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        },
      );
    });

    res.json({
      success: true,
      data: admin,
    });
  } catch (error) {
    console.error("Error fetching admin profile:", error);
    res.status(500).json({
      success: false,
      error: "Failed to fetch profile",
    });
  }
});

// Get system health
router.get("/system-health", authenticateAdmin, async (req, res) => {
  const db = getDb();

  try {
    // Check database connection
    const dbCheck = await new Promise((resolve) => {
      db.get("SELECT 1", [], (err) => {
        resolve(!err);
      });
    });

    // Get database size
    const dbStats = await new Promise((resolve, reject) => {
      db.all(
        `SELECT
          name,
          (SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=main.name) as table_count
         FROM sqlite_master
         WHERE type='table' AND name NOT LIKE 'sqlite_%'`,
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        },
      );
    });

    // Get record counts
    const recordCounts = await Promise.all([
      new Promise((resolve, reject) => {
        db.get("SELECT COUNT(*) as count FROM contacts", [], (err, row) => {
          if (err) reject(err);
          else resolve({ table: "contacts", count: row.count });
        });
      }),
      new Promise((resolve, reject) => {
        db.get("SELECT COUNT(*) as count FROM quotes", [], (err, row) => {
          if (err) reject(err);
          else resolve({ table: "quotes", count: row.count });
        });
      }),
      new Promise((resolve, reject) => {
        db.get(
          "SELECT COUNT(*) as count FROM newsletter_subscribers",
          [],
          (err, row) => {
            if (err) reject(err);
            else resolve({ table: "newsletter_subscribers", count: row.count });
          },
        );
      }),
      new Promise((resolve, reject) => {
        db.get(
          "SELECT COUNT(*) as count FROM product_inquiries",
          [],
          (err, row) => {
            if (err) reject(err);
            else resolve({ table: "product_inquiries", count: row.count });
          },
        );
      }),
    ]);

    res.json({
      success: true,
      data: {
        database: {
          connected: dbCheck,
          tables: dbStats.length,
          records: recordCounts,
        },
        server: {
          uptime: process.uptime(),
          memory: process.memoryUsage(),
          version: process.version,
        },
        timestamp: new Date().toISOString(),
      },
    });
  } catch (error) {
    console.error("Error checking system health:", error);
    res.status(500).json({
      success: false,
      error: "Failed to check system health",
    });
  }
});

// Verify token (for frontend auth checks)
router.get("/verify", authenticateAdmin, (req, res) => {
  res.json({
    success: true,
    admin: {
      id: req.admin.id,
      username: req.admin.username,
      email: req.admin.email,
      role: req.admin.role,
    },
  });
});

module.exports = router;
