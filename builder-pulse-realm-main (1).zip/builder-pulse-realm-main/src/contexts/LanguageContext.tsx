import React, { createContext, useContext, useState, ReactNode } from "react";

export type Language = "en" | "ar" | "ru";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  isRTL: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(
  undefined,
);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
};

interface LanguageProviderProps {
  children: ReactNode;
}

export const LanguageProvider: React.FC<LanguageProviderProps> = ({
  children,
}) => {
  const [language, setLanguage] = useState<Language>("en");

  const isRTL = language === "ar";

  const t = (key: string): string => {
    return translations[language][key] || translations.en[key] || key;
  };

  const handleLanguageChange = (newLanguage: Language) => {
    setLanguage(newLanguage);
    // Store language preference
    localStorage.setItem("preferred-language", newLanguage);
  };

  return (
    <LanguageContext.Provider
      value={{
        language,
        setLanguage: handleLanguageChange,
        t,
        isRTL,
      }}
    >
      <div
        className={`${isRTL ? "rtl" : "ltr"} transition-all duration-300 ease-in-out`}
        dir={isRTL ? "rtl" : "ltr"}
      >
        {children}
      </div>
    </LanguageContext.Provider>
  );
};

const translations = {
  en: {
    // Navigation
    "nav.home": "Home",
    "nav.company": "Company",
    "nav.business": "Business",
    "nav.team": "Team",
    "nav.contact": "Contact",
    "nav.getQuote": "Get Quote",
    "nav.viewCatalog": "View Catalog",

    // Hero Section
    "hero.badge": "🌐 Established 1999 ��� Global Trade Leader",
    "hero.title": "AISAAUS International",
    "hero.subtitle": "Global Trade: Connecting Worlds, Delivering Growth",
    "hero.mission":
      '"Our customers are our top priority... Your success is our mission."',
    "hero.catalogAccess": "Product Catalog Access",
    "hero.learnAbout": "Learn About Us",

    // Stats
    "stats.years": "Years Experience",
    "stats.employees": "Employees",
    "stats.export": "Export Record",
    "stats.partnerships": "Partnerships",

    // Company Section
    "company.title": "About AISAAUS International",
    "company.subtitle":
      "Established in 1999 in Lahore, Pakistan. Leading international trade company with over 1000 employees.",
    "company.mission.title": "Our Mission",
    "company.mission.text":
      "Deliver top-quality products with exceptional service and build lasting global partnerships that drive mutual success and sustainable growth.",
    "company.established": "Established 1999, Lahore, Pakistan",
    "company.employees": "Over 1000 employees worldwide",
    "company.experience": "25+ years of international trade experience",
    "company.clients": "Clients Served",
    "company.awards": "Awards Won",
    "company.success": "Success Rate",
    "company.revenue": "Revenue Generated",
    "company.vision.title": "Our Vision",
    "company.vision.text":
      "Become a globally recognized, sustainable, innovative trade company that sets industry standards and creates value for all stakeholders.",
    "company.values": "Core Values",
    "company.excellence": "Excellence & Integrity",
    "company.sustainability": "Sustainability",
    "company.global": "Global Reach",
    "company.innovation": "Continuous Innovation",
    "company.customer": "Customer-Centricity",

    // Business Section
    "business.title": "Our Business",
    "business.subtitle":
      "Comprehensive international trading solutions across multiple product categories and global markets.",
    "business.services.title": "Our Services",
    "business.services.import": "Import & Export Services",
    "business.services.import.desc":
      "Comprehensive international trade solutions for all product categories.",
    "business.services.supply": "Supply Chain Management",
    "business.services.supply.desc":
      "End-to-end supply chain optimization and logistics coordination.",
    "business.services.quality": "Quality Assurance",
    "business.services.quality.desc":
      "International quality standards compliance and testing services.",
    "business.services.consulting": "Business Consulting",
    "business.services.consulting.desc":
      "Expert guidance for international trade and market expansion.",
    "business.services.certification": "Certification Support",
    "business.services.certification.desc":
      "Assistance with international certifications and compliance.",
    "business.services.partnership": "Partnership Development",
    "business.services.partnership.desc":
      "Building lasting business relationships worldwide.",
    "business.products": "Product Categories",
    "business.petroleum": "Petroleum Products",
    "business.minerals": "Minerals & Gemstones",
    "business.food": "Food Items",
    "business.salts": "Salt Products",
    "business.meat": "Meat Products",
    "business.fruits": "Fruits & Nuts",
    "business.other": "Other Products",
    "business.reach.title": "Global Reach",
    "business.reach.countries": "50+ Countries",
    "business.reach.countries.desc":
      "Active global presence across six continents",
    "business.reach.partners": "197 Partners",
    "business.reach.partners.desc": "Strategic partnerships worldwide",
    "business.reach.routes": "80+ Routes",
    "business.reach.routes.desc": "Global shipping and logistics network",

    // Team Section
    "team.title": "Our Team",
    "team.subtitle":
      "Meet our experienced leadership team guiding AISAAUS International's global operations.",
    "team.founder": "Founder & CEO",
    "team.food": "Food Division Manager",
    "team.minerals": "Minerals Division Manager",
    "team.petroleum": "Petroleum Division Manager",
    "team.founder.bio":
      "Visionary founder who established AISAAUS International in 1999, building it into a global trading powerhouse.",
    "team.food.bio":
      "Expert in food products and agricultural trade operations.",
    "team.minerals.bio":
      "Specialist in minerals, gemstones, and geological products.",
    "team.petroleum.bio":
      "Petroleum products expert with extensive industry knowledge.",

    // Founder Tribute
    "tribute.badge": "🏆 Visionary Leadership",
    "tribute.title": "A Tribute to Our Founder",
    "tribute.subtitle":
      "The visionary leadership and unwavering dedication that built AISAAUS International into a global trading powerhouse.",
    "tribute.leadership": "Years of Leadership",
    "tribute.team": "Team Members",
    "tribute.markets": "Global Markets",
    "tribute.legacy": "Legacy of Excellence",
    "tribute.description":
      "Dr. Amir Siddiqui's vision extends beyond business success. He has built a company culture rooted in integrity, customer-centricity, and sustainable growth.",

    // Contact Section
    "contact.title": "Get In Touch",
    "contact.subtitle":
      "Ready to transform your business? Let's discuss how we can help you achieve your goals.",
    "contact.info": "Contact Information",
    "contact.phone": "Phone Numbers",
    "contact.email": "Email",
    "contact.website": "Website",
    "contact.headquarters": "Headquarters",
    "contact.message": "Send us a message",
    "contact.response": "We'll respond to your inquiry within 24 hours.",
    "contact.firstName": "First Name",
    "contact.lastName": "Last Name",
    "contact.company": "Company",
    "contact.interest": "Product Interest",
    "contact.interestPlaceholder": "Which products are you interested in?",
    "contact.messagePlaceholder": "Tell us about your trading requirements...",
    "contact.send": "Send Message",

    // Language Selector
    "lang.english": "English",
    "lang.arabic": "العربية",
    "lang.russian": "Русский",

    // Footer
    "footer.tagline":
      "Global Trade: Connecting Worlds, Delivering Growth since 1999",
    "footer.location":
      "Lahore, Pakistan • 1000+ Employees • $200K+ Export Record",
    "footer.copyright":
      '© 2024 AISAAUS International. All rights reserved. "Our customers are our top priority... Your success is our mission."',
  },

  ar: {
    // Navigation
    "nav.home": "الرئيسية",
    "nav.company": "الشركة",
    "nav.business": "الأعمال",
    "nav.team": "الفريق",
    "nav.contact": "اتصل بنا",
    "nav.getQuote": "احصل على عرض سعر",
    "nav.viewCatalog": "عرض الكتالوج",

    // Hero Section
    "hero.badge": "🌐 تأسست 1999 • رائدة التجا��ة العالمية",
    "hero.title": "أيساوس الدولية",
    "hero.subtitle": "التجارة العالمية: ربط العوالم، تحقيق النمو",
    "hero.mission": '"عملاؤنا هم أولويتنا القصوى... نجاحكم هو مهمتنا."',
    "hero.catalogAccess": "الوصول إلى كتالوج المنتجات",
    "hero.learnAbout": "تعرف علينا",

    // Stats
    "stats.years": "سنوات الخبرة",
    "stats.employees": "الموظفين",
    "stats.export": "سجل التصدير",
    "stats.partnerships": "الشراكات",

    // Company Section
    "company.title": "حول أيساوس الدولية",
    "company.subtitle":
      "تأسست في عام 1999 في لاهور، باكستان. شركة تجارة دولية رائدة مع أكثر من 1000 موظف.",
    "company.mission.title": "مهمتنا",
    "company.mission.text":
      "تقديم منتجات عالية الجودة مع خدمة استثنائية وبناء شراكات عالمية دائمة تحقق النجاح المتبادل والنمو المستدام.",
    "company.established": "تأسست 1999، لاهور، باكستان",
    "company.employees": "أكثر من 1000 مو��ف في جميع أنحاء العالم",
    "company.experience": "25+ سنة من الخبرة في التجارة الدولية",
    "company.clients": "العملاء المخدومين",
    "company.awards": "الجوائز المحققة",
    "company.success": "معدل النجاح",
    "company.revenue": "الإيرادات المحققة",
    "company.vision.title": "رؤيتنا",
    "company.vision.text":
      "أن نصبح شركة تجارية معترف بها عالمياً ومستدامة ومبتكرة تضع معايير الصناعة وتخلق قيمة لجميع أصحاب المصلحة.",
    "company.values": "القيم الأساسية",
    "company.excellence": "التميز والنزاهة",
    "company.sustainability": "الاستدامة",
    "company.global": "الوصول العالمي",
    "company.innovation": "الابتكار المستمر",
    "company.customer": "التركيز على العملاء",

    // Business Section
    "business.title": "أعمالنا",
    "business.subtitle":
      "حلول تجارية دولية شاملة عبر فئات منتجات متعددة وأسواق عالمية.",
    "business.services.title": "خدماتنا",
    "business.services.import": "خدمات الاستيراد والتصدير",
    "business.services.import.desc":
      "حلول تجارية دولية شاملة لجميع فئات المنتجات.",
    "business.services.supply": "إدارة سلسلة التوريد",
    "business.services.supply.desc":
      "تحسين سلسلة التوريد من البداية إلى النهاية وتنسيق اللوجستيات.",
    "business.services.quality": "ضمان الجودة",
    "business.services.quality.desc":
      "الامتثال لمعايير الجودة الدولية وخدمات الاختبار.",
    "business.services.consulting": "الاستشارات التجارية",
    "business.services.consulting.desc":
      "إرشادات خبيرة للتجارة ال��ولية وتوسيع السوق.",
    "business.services.certification": "دعم الشهادات",
    "business.services.certification.desc":
      "المساعدة في الشهادات الدولية والامتثال.",
    "business.services.partnership": "تطوير الشراكات",
    "business.services.partnership.desc":
      "بناء علاقات تجارية دائمة في جميع أنحاء العالم.",
    "business.products": "فئات المنتجات",
    "business.petroleum": "المنتجات البترولية",
    "business.minerals": "المعادن والأحجار الكريمة",
    "business.food": "المواد الغذائية",
    "business.salts": "منتجات الملح",
    "business.meat": "منتجات اللحوم",
    "business.fruits": "الفواكه والمكسرات",
    "business.other": "منتجات أخرى",
    "business.reach.title": "الوصول العالمي",
    "business.reach.countries": "50+ دولة",
    "business.reach.countries.desc": "حضور عالمي نشط عبر ست قارات",
    "business.reach.partners": "197 شريك",
    "business.reach.partners.desc": "شراكات استراتيجية في جميع أنحاء العالم",
    "business.reach.routes": "80+ طريق",
    "business.reach.routes.desc": "شبكة الشحن واللوجستيات العالمية",

    // Team Section
    "team.title": "فريقنا",
    "team.subtitle":
      "تعرف على فريق القيادة ذي الخبرة الذي يوجه العمليات العالمية لشركة أيساوس الدولية.",
    "team.founder": "المؤسس والرئيس التنفيذي",
    "team.food": "مدير قسم الأغذية",
    "team.minerals": "مدير قسم المعادن",
    "team.petroleum": "مدير قسم البترول",
    "team.founder.bio":
      "مؤسس بصير أسس أيساوس الدولية ف�� عام 1999، وحولها إلى قوة تجارية عالمية.",
    "team.food.bio": "خبير في المنتجات الغذائية وعمليات التجارة الزراعية.",
    "team.minerals.bio":
      "متخصص في المعادن والأحجار الكريمة والمنتجات الجيولوجية.",
    "team.petroleum.bio": "خبير منتجات البترول مع معرفة واسعة في الصناعة.",

    // Founder Tribute
    "tribute.badge": "🏆 القيادة الرؤيوية",
    "tribute.title": "تحية لمؤسسنا",
    "tribute.subtitle":
      "القيادة الرؤيوية والتفاني الثابت الذي بنى أيساوس الدولية لتصبح قوة تجارية عالمية.",
    "tribute.leadership": "سنوات القيادة",
    "tribute.team": "أعضاء الفريق",
    "tribute.markets": "الأسواق العالمية",
    "tribute.legacy": "إرث التميز",
    "tribute.description":
      "رؤية د. أمير صديقي تتجاوز النجاح التجاري. لقد بنى ثقافة شركة متجذرة في النزاهة والتركيز على العملاء والنمو المستدام.",

    // Contact Section
    "contact.title": "تواصل معنا",
    "contact.subtitle":
      "مستعد لتحويل أعمالك؟ دعنا نناقش كيف يمكننا مساعدتك في تحقيق أهدافك.",
    "contact.info": "معلومات الاتصال",
    "contact.phone": "أرقام الهاتف",
    "contact.email": "البريد الإلكتروني",
    "contact.website": "الموقع الإلكتروني",
    "contact.headquarters": "المقر الرئيسي",
    "contact.message": "أرسل لنا رسالة",
    "contact.response": "سنرد على استفسارك خلال 24 ساعة.",
    "contact.firstName": "الاسم الأول",
    "contact.lastName": "الاسم الأخير",
    "contact.company": "الشركة",
    "contact.interest": "اهتمام المنتج",
    "contact.interestPlaceholder": "ما هي المنتجات التي تهتم بها؟",
    "contact.messagePlaceholder": "أخبرنا عن متطلبات التجارة الخاصة بك...",
    "contact.send": "إرسال الرسالة",

    // Language Selector
    "lang.english": "English",
    "lang.arabic": "العربية",
    "lang.russian": "Русский",

    // Footer
    "footer.tagline": "التجارة العالمية: ربط العوالم، تحقيق النمو منذ 1999",
    "footer.location":
      "لاهور، باكستان • 1000+ موظف • 200 ألف دولار+ سجل التصدير",
    "footer.copyright":
      '© 2024 أيساوس الدولية. جميع الحقوق محفوظة. "عملاؤنا هم أولويتنا القصوى... نجاحكم هو مهمتنا."',
  },

  ru: {
    // Navigation
    "nav.home": "Главная",
    "nav.company": "Компания",
    "nav.business": "Бизнес",
    "nav.team": "Команда",
    "nav.contact": "Контакты",
    "nav.getQuote": "Получить расценки",
    "nav.viewCatalog": "Просмотр каталога",

    // Hero Section
    "hero.badge": "🌐 Основана в 1999 • Лидер мировой торговли",
    "hero.title": "AISAAUS International",
    "hero.subtitle": "Глобальная торговля: Сое��иняя миры, обеспечивая рост",
    "hero.mission":
      '"Наши клиенты - наш главный приоритет... Ваш успех - наша миссия."',
    "hero.catalogAccess": "Доступ к каталогу продукции",
    "hero.learnAbout": "Узнать о нас",

    // Stats
    "stats.years": "Лет опыта",
    "stats.employees": "Сотрудников",
    "stats.export": "Экспортный рекорд",
    "stats.partnerships": "Партнерства",

    // Company Section
    "company.title": "О компании AISAAUS International",
    "company.subtitle":
      "Основана в 1999 году в Лахоре, Пакистан. Ведущая международная торговая компания с более чем 1000 сотрудников.",
    "company.mission.title": "Наша миссия",
    "company.mission.text":
      "Поставлять высококачественную продукцию с исключительным сервисом и строить долговременные глобальные партнерства, которые обеспечивают взаимный успех и устойчивый рост.",
    "company.established": "Основана в 1999, Лахор, Пакистан",
    "company.employees": "Более 1000 сотрудников по всему миру",
    "company.experience": "25+ лет опыта в международной торговле",
    "company.clients": "Обслуженных клиентов",
    "company.awards": "Полученных наград",
    "company.success": "Уровень успеха",
    "company.revenue": "Полученный доход",
    "company.vision.title": "Наше видение",
    "company.vision.text":
      "Стать глобально признанной, устойчивой, инновационной торговой компанией, которая устанавливает отраслевые стандарты и создает ценность для всех заинтересованных сторон.",
    "company.values": "Основные ценности",
    "company.excellence": "Совершенство и честность",
    "company.sustainability": "Устойчивость",
    "company.global": "Глобальный охват",
    "company.innovation": "Непрерывные инновации",
    "company.customer": "Клиентоориентированность",

    // Business Section
    "business.title": "Наш бизнес",
    "business.subtitle":
      "Комплексные решения международной торговли в различных категориях продуктов и на глобальных рынках.",
    "business.services.title": "Наши услуги",
    "business.services.import": "Услуги импорта и экспорта",
    "business.services.import.desc":
      "Комплексные решения международной торговли для всех категорий продуктов.",
    "business.services.supply": "Управление цепочками поставок",
    "business.services.supply.desc":
      "Комплексная оптимизация цепочки поставок и координация логистики.",
    "business.services.quality": "Обеспечение качества",
    "business.services.quality.desc":
      "Соответствие международным стандартам качества и услу��и тестирования.",
    "business.services.consulting": "Бизнес-консалтинг",
    "business.services.consulting.desc":
      "Экспертное руководство по международной торговле и расширению рынка.",
    "business.services.certification": "Поддержка сертификации",
    "business.services.certification.desc":
      "Помощь в получении международных сертифик��тов и соответствии требованиям.",
    "business.services.partnership": "Развитие партнерств",
    "business.services.partnership.desc":
      "Построение долговременных деловых отношений по всему миру.",
    "business.products": "Категории продуктов",
    "business.petroleum": "Нефтепродукты",
    "business.minerals": "Минералы и драгоценные камни",
    "business.food": "Пищевые продукты",
    "business.salts": "Соляные продукты",
    "business.meat": "Мясные продукты",
    "business.fruits": "Фрукты и орехи",
    "business.other": "Другие продукты",
    "business.reach.title": "Глобальный охват",
    "business.reach.countries": "50+ стран",
    "business.reach.countries.desc":
      "Активное глобальное присутствие на шести континентах",
    "business.reach.partners": "197 партнеров",
    "business.reach.partners.desc": "Стратегические партнерства по всему миру",
    "business.reach.routes": "80+ маршрутов",
    "business.reach.routes.desc": "Глобальная сеть доставки и логистики",

    // Team Section
    "team.title": "Наша команда",
    "team.subtitle":
      "Познакомьтесь с нашей опытной командой руководителей, управляющих глобальными операциями AISAAUS International.",
    "team.founder": "Основатель и генеральный директор",
    "team.food": "Менеджер пищевого отдела",
    "team.minerals": "Менеджер отдела минералов",
    "team.petroleum": "Менеджер нефтяного отдела",
    "team.founder.bio":
      "Дальновидный основатель, ��оторый создал AISAAUS International в 1999 году, превратив ее в глобальную торговую империю.",
    "team.food.bio":
      "Эксперт по пищевым продуктам и операциям сельскохозяйственной торговли.",
    "team.minerals.bio":
      "Специалист по минералам, драгоценным камням и гео��огическим продуктам.",
    "team.petroleum.bio":
      "Эксперт по нефтепродуктам с обширными знаниями отрасли.",

    // Founder Tribute
    "tribute.badge": "🏆 Визионерское лидерство",
    "tribute.title": "Дань уважения нашему основателю",
    "tribute.subtitle":
      "Визионерское лидерство и непоколебимая преданность, которые построили AISAAUS International в глобальную торговую империю.",
    "tribute.leadership": "Лет лидерства",
    "tribute.team": "Членов команды",
    "tribute.markets": "Глобальных рынков",
    "tribute.legacy": "Наследие совершенства",
    "tribute.description":
      "Видение д-ра Амира Сиддики выходит за рамки коммерческого успеха. Он построил корпоративную культуру, основанную на честности, клиентоориентированности и устойчивом росте.",

    // Contact Section
    "contact.title": "Свяжитесь с нами",
    "contact.subtitle":
      "Готовы преобразовать свой би��нес? Давайте обсудим, как мы можем помочь вам достичь ваших целей.",
    "contact.info": "Контактная информация",
    "contact.phone": "Номера телефонов",
    "contact.email": "Электронная почта",
    "contact.website": "Веб-сайт",
    "contact.headquarters": "Штаб-квартира",
    "contact.message": "Отправьте нам сообщение",
    "contact.response": "Мы ответим на ваш запрос в течение 24 часов.",
    "contact.firstName": "Имя",
    "contact.lastName": "Фамилия",
    "contact.company": "Компания",
    "contact.interest": "Интерес к продукту",
    "contact.interestPlaceholder": "Какие продукты вас интересуют?",
    "contact.messagePlaceholder":
      "Расскажите нам о ваших торговых требованиях...",
    "contact.send": "Отправить сообщение",

    // Language Selector
    "lang.english": "English",
    "lang.arabic": "العربية",
    "lang.russian": "Русский",

    // Footer
    "footer.tagline":
      "Глобальная торговля: Соединяя миры, обеспечивая рост с 1999 года",
    "footer.location":
      "Лахор, Пакистан • 1000+ сотрудников • $200K+ экспортный рекорд",
    "footer.copyright":
      '© 2024 AISAAUS International. Все права защищены. "Наши клиенты - наш главный приоритет... Ваш успех - наша миссия."',
  },
};
