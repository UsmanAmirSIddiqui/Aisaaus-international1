import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Globe,
  MapPin,
  Truck,
  Ship,
  Plane,
  Building,
  Users,
  TrendingUp,
  CheckCircle,
  Clock,
  Package,
  Target,
} from "lucide-react";

const GlobalReach = () => {
  const regionalPresence = [
    {
      region: "Middle East",
      countries: 12,
      partnerships: 45,
      revenue: "$17.5M",
      growth: "+22%",
      keyMarkets: ["UAE", "Saudi Arabia", "Qatar", "Kuwait"],
      description: "Strong presence in Gulf countries with petroleum focus",
      flag: "🇦🇪",
    },
    {
      region: "Europe",
      countries: 15,
      partnerships: 38,
      revenue: "$12.5M",
      growth: "+28%",
      keyMarkets: ["Germany", "UK", "Netherlands", "France"],
      description: "Growing market for food products and gemstones",
      flag: "🇪🇺",
    },
    {
      region: "Asia Pacific",
      countries: 18,
      partnerships: 52,
      revenue: "$10M",
      growth: "+35%",
      keyMarkets: ["Singapore", "Malaysia", "Thailand", "Japan"],
      description: "Emerging markets with diverse product demand",
      flag: "🌏",
    },
    {
      region: "North America",
      countries: 3,
      partnerships: 28,
      revenue: "$7.5M",
      growth: "+18%",
      keyMarkets: ["USA", "Canada", "Mexico"],
      description: "Premium markets for specialty products",
      flag: "🇺🇸",
    },
    {
      region: "Africa",
      countries: 8,
      partnerships: 19,
      revenue: "$3M",
      growth: "+45%",
      keyMarkets: ["South Africa", "Nigeria", "Egypt", "Kenya"],
      description: "High-growth potential markets",
      flag: "🌍",
    },
    {
      region: "South America",
      countries: 5,
      partnerships: 15,
      revenue: "$2.5M",
      growth: "+60%",
      keyMarkets: ["Brazil", "Argentina", "Chile", "Colombia"],
      description: "Newest expansion with promising growth",
      flag: "🌎",
    },
  ];

  const logisticsNetwork = [
    {
      method: "Sea Freight",
      icon: <Ship className="h-6 w-6" />,
      volume: "70%",
      routes: 25,
      avgTime: "15-30 days",
      suitable: "Bulk commodities, petroleum products",
    },
    {
      method: "Air Freight",
      icon: <Plane className="h-6 w-6" />,
      volume: "20%",
      routes: 40,
      avgTime: "3-7 days",
      suitable: "Gemstones, urgent shipments",
    },
    {
      method: "Land Transport",
      icon: <Truck className="h-6 w-6" />,
      volume: "10%",
      routes: 15,
      avgTime: "1-14 days",
      suitable: "Regional deliveries, overland routes",
    },
  ];

  const globalStats = [
    {
      label: "Countries Served",
      value: "50+",
      icon: <Globe className="h-8 w-8" />,
    },
    {
      label: "Active Partnerships",
      value: "197",
      icon: <Users className="h-8 w-8" />,
    },
    {
      label: "Shipping Routes",
      value: "80+",
      icon: <Truck className="h-8 w-8" />,
    },
    {
      label: "Regional Offices",
      value: "12",
      icon: <Building className="h-8 w-8" />,
    },
  ];

  const expansionPlans = [
    {
      region: "Central Asia",
      timeline: "2024 Q3",
      focus: "Petroleum and salt products",
      status: "Planning",
      countries: ["Kazakhstan", "Uzbekistan", "Kyrgyzstan"],
    },
    {
      region: "Eastern Europe",
      timeline: "2024 Q4",
      focus: "Food products and gemstones",
      status: "Research",
      countries: ["Poland", "Czech Republic", "Hungary"],
    },
    {
      region: "Southeast Asia",
      timeline: "2025 Q1",
      focus: "Comprehensive product range",
      status: "Partner Evaluation",
      countries: ["Vietnam", "Philippines", "Indonesia"],
    },
    {
      region: "West Africa",
      timeline: "2025 Q2",
      focus: "Food and salt products",
      status: "Market Analysis",
      countries: ["Ghana", "Senegal", "Ivory Coast"],
    },
  ];

  const tradingHubs = [
    {
      location: "Lahore, Pakistan",
      type: "Headquarters",
      role: "Global operations center and main production hub",
      established: "1999",
      employees: "800+",
    },
    {
      location: "Karachi, Pakistan",
      type: "Logistics Hub",
      role: "Primary shipping and logistics coordination center",
      established: "2005",
      employees: "150+",
    },
    {
      location: "Dubai, UAE",
      type: "Regional Office",
      role: "Middle East operations and client relations",
      established: "2012",
      employees: "25+",
    },
    {
      location: "Singapore",
      type: "Asia Pacific Hub",
      role: "Regional distribution and partnerships",
      established: "2018",
      employees: "15+",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <section className="py-20 bg-gradient-to-br from-orange-50 to-orange-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="bg-orange-100 text-orange-800 mb-6">
              🌍 Worldwide Presence
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Global Reach
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              AISAAUS International serves clients across six continents with a
              comprehensive network of partnerships, logistics solutions, and
              regional expertise.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
            {globalStats.map((stat, index) => (
              <Card key={index} className="text-center">
                <CardContent className="p-6">
                  <div className="bg-orange-100 rounded-full p-3 w-16 h-16 mx-auto mb-4 flex items-center justify-center text-orange-500">
                    {stat.icon}
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-1">
                    {stat.value}
                  </div>
                  <div className="text-gray-600">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Regional Presence */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
              Regional Presence
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {regionalPresence.map((region, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center">
                        <span className="text-2xl mr-2">{region.flag}</span>
                        <CardTitle className="text-xl">
                          {region.region}
                        </CardTitle>
                      </div>
                      <Badge className="bg-green-100 text-green-800">
                        {region.growth}
                      </Badge>
                    </div>
                    <p className="text-gray-600 text-sm">
                      {region.description}
                    </p>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div className="text-center">
                        <div className="text-lg font-bold text-orange-500">
                          {region.countries}
                        </div>
                        <div className="text-xs text-gray-600">Countries</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-orange-500">
                          {region.partnerships}
                        </div>
                        <div className="text-xs text-gray-600">Partners</div>
                      </div>
                    </div>
                    <div className="text-center mb-4">
                      <div className="text-xl font-bold text-gray-900">
                        {region.revenue}
                      </div>
                      <div className="text-sm text-gray-600">
                        Annual Revenue
                      </div>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-900 mb-2">
                        Key Markets:
                      </h4>
                      <div className="flex flex-wrap gap-1">
                        {region.keyMarkets.map((market, i) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {market}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Logistics Network */}
          <Card className="mb-16">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Truck className="h-6 w-6 text-orange-500 mr-3" />
                Global Logistics Network
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-6">
                {logisticsNetwork.map((method, index) => (
                  <div
                    key={index}
                    className="text-center p-4 border rounded-lg"
                  >
                    <div className="bg-orange-100 rounded-full p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center text-orange-500">
                      {method.icon}
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-2">
                      {method.method}
                    </h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Volume:</span>
                        <span className="font-medium">{method.volume}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Routes:</span>
                        <span className="font-medium">{method.routes}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Avg Time:</span>
                        <span className="font-medium">{method.avgTime}</span>
                      </div>
                    </div>
                    <p className="text-xs text-gray-500 mt-3">
                      {method.suitable}
                    </p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Trading Hubs */}
          <Card className="mb-16">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Building className="h-6 w-6 text-orange-500 mr-3" />
                Global Trading Hubs
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                {tradingHubs.map((hub, index) => (
                  <div
                    key={index}
                    className="border rounded-lg p-4 hover:bg-gray-50"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h3 className="font-semibold text-gray-900">
                          {hub.location}
                        </h3>
                        <Badge className="bg-orange-100 text-orange-800">
                          {hub.type}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-500">
                        Est. {hub.established}
                      </div>
                    </div>
                    <p className="text-gray-600 text-sm mb-2">{hub.role}</p>
                    <div className="flex items-center text-sm text-gray-500">
                      <Users className="h-4 w-4 mr-1" />
                      {hub.employees} employees
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Expansion Plans */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="h-6 w-6 text-orange-500 mr-3" />
                Future Expansion Plans
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {expansionPlans.map((plan, index) => (
                  <div
                    key={index}
                    className="border-l-4 border-orange-500 pl-4"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-gray-900">
                        {plan.region}
                      </h3>
                      <div className="flex items-center gap-2">
                        <Badge
                          className={
                            plan.status === "Planning"
                              ? "bg-blue-100 text-blue-800"
                              : plan.status === "Research"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-green-100 text-green-800"
                          }
                        >
                          {plan.status}
                        </Badge>
                        <span className="text-sm text-gray-500">
                          {plan.timeline}
                        </span>
                      </div>
                    </div>
                    <p className="text-gray-600 text-sm mb-2">{plan.focus}</p>
                    <div className="flex flex-wrap gap-1">
                      {plan.countries.map((country, i) => (
                        <Badge key={i} variant="outline" className="text-xs">
                          {country}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Expand With Us
            </h2>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Interested in becoming a regional partner or exploring market
              opportunities in your region? Let's discuss how we can grow
              together.
            </p>
            <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
              <Card className="p-6 bg-white">
                <h3 className="font-semibold text-gray-900 mb-4">
                  Regional Partnership
                </h3>
                <p className="text-gray-600 text-sm mb-4">
                  Become an exclusive regional distributor for AISAAUS products
                  in your market
                </p>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    Exclusive territory rights
                  </div>
                  <div className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    Marketing support
                  </div>
                  <div className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    Training and development
                  </div>
                </div>
              </Card>
              <Card className="p-6 bg-white">
                <h3 className="font-semibold text-gray-900 mb-4">
                  Market Entry Support
                </h3>
                <p className="text-gray-600 text-sm mb-4">
                  Get assistance entering new markets with our expertise and
                  network
                </p>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    Market research and analysis
                  </div>
                  <div className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    Regulatory compliance support
                  </div>
                  <div className="flex items-center">
                    <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                    Local partnership facilitation
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default GlobalReach;
