import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Users,
  MapPin,
  Calendar,
  DollarSign,
  Briefcase,
  GraduationCap,
  Clock,
  Heart,
  TrendingUp,
  Globe,
  Award,
  Coffee,
} from "lucide-react";

const Careers = () => {
  const openPositions = [
    {
      title: "International Trade Manager",
      department: "Business Development",
      location: "Lahore, Pakistan",
      type: "Full-time",
      experience: "5+ years",
      salary: "Competitive",
      description:
        "Lead international trade operations and develop strategic partnerships with global clients.",
      requirements: [
        "Bachelor's degree in Business or International Trade",
        "5+ years of experience in international trade",
        "Strong communication and negotiation skills",
        "Knowledge of export/import regulations",
      ],
    },
    {
      title: "Quality Assurance Specialist",
      department: "Quality Control",
      location: "Lahore, Pakistan",
      type: "Full-time",
      experience: "3+ years",
      salary: "PKR 80,000 - 120,000",
      description:
        "Ensure product quality standards and compliance with international certifications.",
      requirements: [
        "Bachelor's degree in Chemistry or related field",
        "Experience with quality testing procedures",
        "Knowledge of ISO standards",
        "Attention to detail and analytical skills",
      ],
    },
    {
      title: "Regional Sales Representative",
      department: "Sales",
      location: "Multiple Locations",
      type: "Full-time",
      experience: "2+ years",
      salary: "Base + Commission",
      description:
        "Develop and maintain relationships with regional clients and expand market presence.",
      requirements: [
        "Bachelor's degree in Sales or Marketing",
        "Proven sales track record",
        "Willingness to travel",
        "Excellent interpersonal skills",
      ],
    },
    {
      title: "Logistics Coordinator",
      department: "Operations",
      location: "Karachi, Pakistan",
      type: "Full-time",
      experience: "2+ years",
      salary: "PKR 60,000 - 90,000",
      description:
        "Coordinate shipping and logistics operations for international trade activities.",
      requirements: [
        "Bachelor's degree in Logistics or Supply Chain",
        "Experience with freight forwarding",
        "Knowledge of shipping documentation",
        "Problem-solving abilities",
      ],
    },
    {
      title: "Digital Marketing Specialist",
      department: "Marketing",
      location: "Lahore, Pakistan",
      type: "Full-time",
      experience: "3+ years",
      salary: "PKR 70,000 - 100,000",
      description:
        "Develop and execute digital marketing strategies to enhance brand visibility.",
      requirements: [
        "Bachelor's degree in Marketing or Digital Media",
        "Experience with SEO, SEM, and social media",
        "Creative thinking and analytical skills",
        "Knowledge of marketing tools and platforms",
      ],
    },
    {
      title: "Finance Analyst",
      department: "Finance",
      location: "Lahore, Pakistan",
      type: "Full-time",
      experience: "2+ years",
      salary: "PKR 65,000 - 95,000",
      description:
        "Analyze financial data and support decision-making for international operations.",
      requirements: [
        "Bachelor's degree in Finance or Accounting",
        "Strong analytical and Excel skills",
        "Knowledge of financial modeling",
        "Attention to detail",
      ],
    },
  ];

  const benefits = [
    {
      icon: <Heart className="h-6 w-6" />,
      title: "Health Insurance",
      description: "Comprehensive medical coverage for you and your family",
    },
    {
      icon: <GraduationCap className="h-6 w-6" />,
      title: "Learning & Development",
      description: "Continuous learning opportunities and training programs",
    },
    {
      icon: <Globe className="h-6 w-6" />,
      title: "International Exposure",
      description: "Work with global clients and international markets",
    },
    {
      icon: <TrendingUp className="h-6 w-6" />,
      title: "Career Growth",
      description: "Clear career progression paths and promotion opportunities",
    },
    {
      icon: <Coffee className="h-6 w-6" />,
      title: "Work-Life Balance",
      description: "Flexible working hours and supportive work environment",
    },
    {
      icon: <Award className="h-6 w-6" />,
      title: "Performance Rewards",
      description: "Recognition programs and performance-based incentives",
    },
  ];

  const companyStats = [
    { number: "1000+", label: "Employees" },
    { number: "25+", label: "Years in Business" },
    { number: "50+", label: "Countries Served" },
    { number: "95%", label: "Employee Satisfaction" },
  ];

  return (
    <div className="min-h-screen bg-white">
      <section className="py-20 bg-gradient-to-br from-orange-50 to-orange-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="bg-orange-100 text-orange-800 mb-6">
              💼 Join Our Team
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Careers at AISAAUS
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Build your career with a leading international trading company.
              Join our team of passionate professionals and grow with us in the
              global marketplace.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
            {companyStats.map((stat, index) => (
              <Card key={index} className="text-center">
                <CardContent className="p-6">
                  <div className="text-3xl font-bold text-orange-500 mb-2">
                    {stat.number}
                  </div>
                  <div className="text-gray-600">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="mb-16">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
              Why Work With Us?
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {benefits.map((benefit, index) => (
                <Card
                  key={index}
                  className="text-center hover:shadow-md transition-shadow"
                >
                  <CardContent className="p-6">
                    <div className="bg-orange-100 rounded-full p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center text-orange-500">
                      {benefit.icon}
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-2">
                      {benefit.title}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {benefit.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div>
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
              Open Positions
            </h2>
            <div className="grid gap-6">
              {openPositions.map((position, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                      <div>
                        <CardTitle className="text-xl mb-2">
                          {position.title}
                        </CardTitle>
                        <div className="flex flex-wrap gap-2">
                          <Badge className="bg-orange-100 text-orange-800">
                            <Briefcase className="h-3 w-3 mr-1" />
                            {position.department}
                          </Badge>
                          <Badge variant="outline">
                            <MapPin className="h-3 w-3 mr-1" />
                            {position.location}
                          </Badge>
                          <Badge variant="outline">
                            <Clock className="h-3 w-3 mr-1" />
                            {position.type}
                          </Badge>
                        </div>
                      </div>
                      <div className="mt-4 md:mt-0 text-right">
                        <div className="flex items-center text-gray-600 mb-1">
                          <GraduationCap className="h-4 w-4 mr-1" />
                          <span className="text-sm">{position.experience}</span>
                        </div>
                        <div className="flex items-center text-gray-600">
                          <DollarSign className="h-4 w-4 mr-1" />
                          <span className="text-sm">{position.salary}</span>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-600 mb-4">{position.description}</p>
                    <div>
                      <h4 className="font-semibold text-gray-900 mb-2">
                        Requirements:
                      </h4>
                      <ul className="list-disc list-inside text-sm text-gray-600 space-y-1 mb-4">
                        {position.requirements.map((req, i) => (
                          <li key={i}>{req}</li>
                        ))}
                      </ul>
                    </div>
                    <div className="flex flex-col sm:flex-row gap-3">
                      <Button className="bg-orange-500 hover:bg-orange-600">
                        Apply Now
                      </Button>
                      <Button variant="outline">Learn More</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Don't See Your Role?
            </h2>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              We're always looking for talented individuals to join our team.
              Send us your resume and we'll consider you for future
              opportunities.
            </p>
            <Card className="max-w-md mx-auto p-6 bg-white">
              <h3 className="font-semibold text-gray-900 mb-4">
                General Application
              </h3>
              <p className="text-gray-600 text-sm mb-4">
                Submit your CV and cover letter for future consideration
              </p>
              <Button className="w-full bg-orange-500 hover:bg-orange-600">
                Submit Application
              </Button>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Careers;
