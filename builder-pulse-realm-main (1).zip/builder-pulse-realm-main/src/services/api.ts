// Detect if we're in development or production and set appropriate API URL
const API_BASE_URL = (() => {
  if (typeof window !== "undefined") {
    // If running on localhost or local development
    if (
      window.location.hostname === "localhost" ||
      window.location.hostname === "127.0.0.1"
    ) {
      return "http://localhost:5000/api";
    }
    // For remote/production environments, use relative URLs or a deployed backend
    // For now, we'll create a mock API response since backend needs to be deployed
    return "/api";
  }
  return "http://localhost:5000/api";
})();

// Types
export interface ContactSubmission {
  name: string;
  email: string;
  phone?: string;
  company?: string;
  message: string;
}

export interface QuoteRequest {
  name: string;
  email: string;
  phone?: string;
  company: string;
  productCategory: string;
  specificProducts?: string;
  quantity?: string;
  budgetRange?: string;
  deliveryLocation?: string;
  urgency?: string;
  message?: string;
}

export interface ProductInquiry {
  name: string;
  email: string;
  phone?: string;
  company?: string;
  productName: string;
  productCategory: string;
  inquiryType: string;
  quantity?: string;
  specifications?: string;
  message?: string;
}

export interface NewsletterSubscription {
  email: string;
  name?: string;
}

export interface ApiResponse<T = any> {
  success: boolean;
  message?: string;
  data?: T;
  error?: string;
}

// Check if backend is available
const isBackendAvailable = async (): Promise<boolean> => {
  try {
    const response = await fetch(`${API_BASE_URL}/health`, {
      method: "GET",
      signal: AbortSignal.timeout(3000), // 3 second timeout
    });
    return response.ok;
  } catch {
    return false;
  }
};

// Mock API responses for when backend is not available
const mockApiResponse = <T>(data?: T): Promise<ApiResponse<T>> => {
  return Promise.resolve({
    success: true,
    message: "Demo mode - Form submitted successfully! (Backend not connected)",
    data,
  });
};

// Helper function to make API calls
const apiCall = async <T>(
  endpoint: string,
  options: RequestInit = {},
): Promise<ApiResponse<T>> => {
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      headers: {
        "Content-Type": "application/json",
        ...options.headers,
      },
      ...options,
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || `HTTP error! status: ${response.status}`);
    }

    return data;
  } catch (error) {
    console.error(`API call failed for ${endpoint}:`, error);

    // If we're not on localhost and the backend is not available, use mock responses
    if (
      typeof window !== "undefined" &&
      window.location.hostname !== "localhost" &&
      window.location.hostname !== "127.0.0.1"
    ) {
      console.log("Backend not available, using demo mode for:", endpoint);
      return mockApiResponse();
    }

    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error occurred",
    };
  }
};

// Contact API
export const contactApi = {
  submit: async (data: ContactSubmission): Promise<ApiResponse> => {
    return apiCall("/contact/submit", {
      method: "POST",
      body: JSON.stringify(data),
    });
  },

  getStats: async (): Promise<ApiResponse> => {
    return apiCall("/contact/stats");
  },
};

// Quote API
export const quoteApi = {
  request: async (data: QuoteRequest): Promise<ApiResponse> => {
    return apiCall("/quote/request", {
      method: "POST",
      body: JSON.stringify(data),
    });
  },

  getStats: async (): Promise<ApiResponse> => {
    return apiCall("/quote/stats");
  },
};

// Newsletter API
export const newsletterApi = {
  subscribe: async (data: NewsletterSubscription): Promise<ApiResponse> => {
    return apiCall("/newsletter/subscribe", {
      method: "POST",
      body: JSON.stringify(data),
    });
  },

  unsubscribe: async (email: string): Promise<ApiResponse> => {
    return apiCall("/newsletter/unsubscribe", {
      method: "POST",
      body: JSON.stringify({ email }),
    });
  },

  getStats: async (): Promise<ApiResponse> => {
    return apiCall("/newsletter/stats");
  },
};

// Product Inquiry API
export const productInquiryApi = {
  submit: async (data: ProductInquiry): Promise<ApiResponse> => {
    return apiCall("/product-inquiry/submit", {
      method: "POST",
      body: JSON.stringify(data),
    });
  },

  getStats: async (): Promise<ApiResponse> => {
    return apiCall("/product-inquiry/stats");
  },
};

// Admin API
export const adminApi = {
  login: async (username: string, password: string): Promise<ApiResponse> => {
    return apiCall("/admin/login", {
      method: "POST",
      body: JSON.stringify({ username, password }),
    });
  },

  getDashboard: async (token: string): Promise<ApiResponse> => {
    return apiCall("/admin/dashboard", {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
  },

  verify: async (token: string): Promise<ApiResponse> => {
    return apiCall("/admin/verify", {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
  },

  changePassword: async (
    token: string,
    currentPassword: string,
    newPassword: string,
  ): Promise<ApiResponse> => {
    return apiCall("/admin/change-password", {
      method: "PATCH",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ currentPassword, newPassword }),
    });
  },

  getSystemHealth: async (token: string): Promise<ApiResponse> => {
    return apiCall("/admin/system-health", {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
  },
};

// Health check
export const healthCheck = async (): Promise<ApiResponse> => {
  return apiCall("/health");
};

// Export all APIs
export const api = {
  contact: contactApi,
  quote: quoteApi,
  newsletter: newsletterApi,
  productInquiry: productInquiryApi,
  admin: adminApi,
  healthCheck,
};

export default api;
