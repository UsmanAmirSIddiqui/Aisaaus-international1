import React from "react";
import { Button } from "@/components/ui/button";
import { Languages, ChevronDown, Check } from "lucide-react";
import { useLanguage, Language } from "@/contexts/LanguageContext";

export const LanguageSelector: React.FC = () => {
  const { language, setLanguage, isRTL } = useLanguage();
  const [isOpen, setIsOpen] = React.useState(false);

  const languages = [
    {
      code: "en" as Language,
      name: "English",
      flag: "🇺🇸",
      nativeName: "English",
    },
    {
      code: "ar" as Language,
      name: "Arabic",
      flag: "🇸🇦",
      nativeName: "العربية",
    },
    {
      code: "ru" as Language,
      name: "Russian",
      flag: "🇷🇺",
      nativeName: "Русский",
    },
  ];

  const currentLanguage =
    languages.find((lang) => lang.code === language) || languages[0];

  const handleLanguageChange = (langCode: Language) => {
    setLanguage(langCode);
    setIsOpen(false);
    // Store language preference in localStorage
    localStorage.setItem("preferred-language", langCode);
  };

  // Close dropdown when clicking outside
  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (!target.closest(".language-selector")) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
      return () =>
        document.removeEventListener("mousedown", handleClickOutside);
    }
  }, [isOpen]);

  // Load saved language preference on mount
  React.useEffect(() => {
    const savedLanguage = localStorage.getItem(
      "preferred-language",
    ) as Language;
    if (
      savedLanguage &&
      languages.some((lang) => lang.code === savedLanguage)
    ) {
      setLanguage(savedLanguage);
    }
  }, [setLanguage]);

  return (
    <div className="relative language-selector">
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setIsOpen(!isOpen)}
        className={`flex items-center space-x-2 text-gray-700 hover:text-orange-500 border border-gray-200 hover:border-orange-300 px-3 py-2 transition-all duration-300 hover:shadow-md hover:scale-105 ${
          isRTL ? "flex-row-reverse space-x-reverse" : ""
        }`}
      >
        <Languages className="h-4 w-4 transition-all duration-300" />
        <span className="text-sm transition-all duration-300">
          {currentLanguage.flag}
        </span>
        <span className="text-sm font-medium transition-all duration-300">
          {currentLanguage.code.toUpperCase()}
        </span>
        <ChevronDown
          className={`h-4 w-4 transition-all duration-300 ${
            isOpen ? "rotate-180" : ""
          }`}
        />
      </Button>

      {isOpen && (
        <div
          className={`absolute ${
            isRTL ? "left-0" : "right-0"
          } top-full mt-2 w-56 bg-white border border-gray-200 rounded-lg shadow-2xl z-[999] animate-in fade-in-0 zoom-in-95 slide-in-from-top-2 duration-300 backdrop-blur-sm`}
        >
          {languages.map((lang, index) => (
            <button
              key={lang.code}
              onClick={() => handleLanguageChange(lang.code)}
              className={`flex items-center w-full px-4 py-3 text-left transition-all duration-300 hover:bg-gradient-to-r hover:from-orange-50 hover:to-orange-100 hover:scale-[1.02] hover:shadow-sm first:rounded-t-lg last:rounded-b-lg group ${
                lang.code === language
                  ? "bg-gradient-to-r from-orange-50 to-orange-100 text-orange-600 shadow-sm"
                  : "text-gray-700 hover:text-orange-600"
              } ${isRTL ? "text-right flex-row-reverse" : ""}`}
              style={{
                animationDelay: `${index * 50}ms`,
                animation: `slideInScale 0.3s ease-out forwards`,
              }}
            >
              <span className="text-lg mr-3 transition-transform duration-300 group-hover:scale-110">
                {lang.flag}
              </span>
              <div className="flex-1">
                <div className="font-medium transition-all duration-300">
                  {lang.nativeName}
                </div>
                <div className="text-xs text-gray-500 transition-all duration-300">
                  {lang.name}
                </div>
              </div>
              {lang.code === language && (
                <Check className="h-4 w-4 text-orange-500 animate-in zoom-in-50 duration-200" />
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

// Mobile Language Selector
export const MobileLanguageSelector: React.FC = () => {
  const { language, setLanguage, isRTL } = useLanguage();

  const languages = [
    { code: "en" as Language, name: "EN", flag: "🇺🇸", nativeName: "English" },
    { code: "ar" as Language, name: "AR", flag: "🇸🇦", nativeName: "العربية" },
    { code: "ru" as Language, name: "RU", flag: "🇷🇺", nativeName: "Русский" },
  ];

  const handleLanguageChange = (langCode: Language) => {
    setLanguage(langCode);
    localStorage.setItem("preferred-language", langCode);
  };

  return (
    <div className="mb-4">
      <h4
        className={`text-sm font-medium text-gray-700 mb-2 ${isRTL ? "text-right" : ""}`}
      >
        Language / اللغة / Язык
      </h4>
      <div className="grid grid-cols-3 gap-2">
        {languages.map((lang) => (
          <button
            key={lang.code}
            onClick={() => handleLanguageChange(lang.code)}
            className={`flex items-center justify-center space-x-1 px-3 py-2 rounded-md text-xs transition-colors ${
              language === lang.code
                ? "bg-orange-100 text-orange-600 border border-orange-300 font-medium"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            } ${isRTL ? "flex-row-reverse space-x-reverse" : ""}`}
          >
            <span>{lang.flag}</span>
            <span className="font-medium">{lang.name}</span>
          </button>
        ))}
      </div>
    </div>
  );
};
