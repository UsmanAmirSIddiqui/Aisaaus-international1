import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Target,
  Eye,
  Award,
  Globe,
  Truck,
  TrendingUp,
  Heart,
} from "lucide-react";

const Mission = () => {
  const coreValues = [
    { title: "Excellence & Integrity", icon: <Award className="h-6 w-6" /> },
    { title: "Sustainability", icon: <Globe className="h-6 w-6" /> },
    { title: "Global Reach", icon: <Truck className="h-6 w-6" /> },
    {
      title: "Continuous Innovation",
      icon: <TrendingUp className="h-6 w-6" />,
    },
    { title: "Customer-Centricity", icon: <Heart className="h-6 w-6" /> },
  ];

  return (
    <div className="min-h-screen bg-white">
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              Mission & Vision
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our guiding principles and future aspirations
            </p>
          </div>

          {/* Mission & Vision */}
          <div className="grid lg:grid-cols-2 gap-12 mb-16">
            <Card className="p-8">
              <CardHeader className="text-center">
                <div className="bg-orange-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <Target className="h-8 w-8 text-orange-500" />
                </div>
                <CardTitle className="text-2xl">Our Mission</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center leading-relaxed">
                  Deliver top-quality products with exceptional service and
                  build lasting global partnerships that drive mutual success
                  and sustainable growth.
                </p>
              </CardContent>
            </Card>

            <Card className="p-8">
              <CardHeader className="text-center">
                <div className="bg-orange-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <Eye className="h-8 w-8 text-orange-500" />
                </div>
                <CardTitle className="text-2xl">Our Vision</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center leading-relaxed">
                  Become a globally recognized, sustainable, innovative trade
                  company that sets industry standards and creates value for all
                  stakeholders.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Core Values */}
          <div className="bg-gray-50 rounded-xl p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">
              Core Values
            </h2>
            <div className="grid md:grid-cols-3 lg:grid-cols-5 gap-6">
              {coreValues.map((value, index) => (
                <div key={index} className="text-center">
                  <div className="bg-orange-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center text-orange-500">
                    {value.icon}
                  </div>
                  <h4 className="font-semibold text-gray-900 text-sm">
                    {value.title}
                  </h4>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Mission;
