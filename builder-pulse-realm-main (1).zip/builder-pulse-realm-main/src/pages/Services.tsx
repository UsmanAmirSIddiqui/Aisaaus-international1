import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Truck,
  Globe,
  Shield,
  Users,
  CheckCircle,
  ArrowRight,
  FileText,
  Clock,
  TrendingUp,
  Handshake,
  Package,
  Headphones,
} from "lucide-react";

const Services = () => {
  const mainServices = [
    {
      title: "Import & Export Services",
      description: "Comprehensive international trade solutions",
      icon: <Globe className="h-8 w-8" />,
      features: [
        "Petroleum products import/export",
        "Mineral and gemstone trading",
        "Food products international trade",
        "Salt products global distribution",
      ],
    },
    {
      title: "Supply Chain Management",
      description: "End-to-end supply chain optimization",
      icon: <Truck className="h-8 w-8" />,
      features: [
        "Logistics coordination",
        "Inventory management",
        "Warehousing solutions",
        "Distribution networks",
      ],
    },
    {
      title: "Quality Assurance",
      description: "International quality standards compliance",
      icon: <Shield className="h-8 w-8" />,
      features: [
        "Product quality testing",
        "Certification assistance",
        "Standards compliance",
        "Quality documentation",
      ],
    },
    {
      title: "Business Consulting",
      description: "Expert guidance for international trade",
      icon: <Users className="h-8 w-8" />,
      features: [
        "Market analysis",
        "Trade strategy development",
        "Risk assessment",
        "Partnership facilitation",
      ],
    },
  ];

  const additionalServices = [
    {
      title: "Documentation Services",
      icon: <FileText className="h-6 w-6" />,
      description: "Complete trade documentation support",
    },
    {
      title: "24/7 Customer Support",
      icon: <Headphones className="h-6 w-6" />,
      description: "Round-the-clock assistance and support",
    },
    {
      title: "Market Intelligence",
      icon: <TrendingUp className="h-6 w-6" />,
      description: "Real-time market insights and analysis",
    },
    {
      title: "Partnership Development",
      icon: <Handshake className="h-6 w-6" />,
      description: "Building lasting business relationships",
    },
    {
      title: "Custom Packaging",
      icon: <Package className="h-6 w-6" />,
      description: "Tailored packaging solutions",
    },
    {
      title: "Timely Delivery",
      icon: <Clock className="h-6 w-6" />,
      description: "Guaranteed on-time delivery services",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <section className="py-20 bg-gradient-to-br from-orange-50 to-orange-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="bg-orange-100 text-orange-800 mb-6">
              🚀 Comprehensive Trading Solutions
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Our Services
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              AISAAUS International offers end-to-end trading solutions designed
              to help your business succeed in the global marketplace.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-16">
            Core Services
          </h2>

          <div className="grid md:grid-cols-2 gap-8 mb-16">
            {mainServices.map((service, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="bg-orange-100 rounded-lg p-3 w-fit text-orange-500 mb-4">
                    {service.icon}
                  </div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                  <p className="text-gray-600">{service.description}</p>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {service.features.map((feature, i) => (
                      <li
                        key={i}
                        className="flex items-center text-sm text-gray-700"
                      >
                        <CheckCircle className="h-4 w-4 text-orange-500 mr-2" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>

          <h3 className="text-2xl font-bold text-center text-gray-900 mb-12">
            Additional Services
          </h3>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {additionalServices.map((service, index) => (
              <Card
                key={index}
                className="text-center hover:shadow-md transition-shadow"
              >
                <CardContent className="p-6">
                  <div className="bg-orange-100 rounded-full p-3 w-12 h-12 mx-auto mb-4 flex items-center justify-center text-orange-500">
                    {service.icon}
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-2">
                    {service.title}
                  </h4>
                  <p className="text-sm text-gray-600">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Contact us today to discuss how our services can help your business
            grow in the international market.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Card className="p-6 bg-white">
              <h3 className="font-semibold text-gray-900 mb-2">Get a Quote</h3>
              <p className="text-gray-600 text-sm mb-4">
                Request a customized quote for your trading needs
              </p>
              <ArrowRight className="h-5 w-5 text-orange-500 mx-auto" />
            </Card>
            <Card className="p-6 bg-white">
              <h3 className="font-semibold text-gray-900 mb-2">
                Schedule Consultation
              </h3>
              <p className="text-gray-600 text-sm mb-4">
                Book a free consultation with our experts
              </p>
              <ArrowRight className="h-5 w-5 text-orange-500 mx-auto" />
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;
