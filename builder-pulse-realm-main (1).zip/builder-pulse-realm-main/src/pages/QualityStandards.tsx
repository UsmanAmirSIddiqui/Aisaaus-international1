import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Shield,
  CheckCircle,
  Award,
  Microscope,
  FileText,
  Users,
  Truck,
  Leaf,
  Globe,
  Target,
  AlertTriangle,
  BarChart3,
} from "lucide-react";

const QualityStandards = () => {
  const qualityPillars = [
    {
      title: "International Standards Compliance",
      description: "Adherence to global quality and safety standards",
      icon: <Globe className="h-8 w-8" />,
      standards: ["ISO 9001:2015", "ISO 14001:2015", "HACCP", "GMP"],
    },
    {
      title: "Advanced Testing Facilities",
      description: "State-of-the-art laboratories for comprehensive testing",
      icon: <Microscope className="h-8 w-8" />,
      standards: [
        "Chemical Analysis",
        "Physical Testing",
        "Microbiological Testing",
        "Contamination Screening",
      ],
    },
    {
      title: "Supply Chain Quality",
      description: "End-to-end quality control throughout supply chain",
      icon: <Truck className="h-8 w-8" />,
      standards: [
        "Supplier Audits",
        "Raw Material Testing",
        "In-Process Monitoring",
        "Final Inspection",
      ],
    },
    {
      title: "Environmental Responsibility",
      description: "Sustainable practices and environmental protection",
      icon: <Leaf className="h-8 w-8" />,
      standards: [
        "Environmental Management",
        "Waste Reduction",
        "Energy Efficiency",
        "Carbon Footprint",
      ],
    },
  ];

  const testingProcedures = [
    {
      category: "Petroleum Products",
      tests: [
        "Viscosity Index Testing",
        "Flash Point Analysis",
        "Pour Point Determination",
        "Specific Gravity Measurement",
        "Color Stability Test",
        "Contamination Analysis",
      ],
    },
    {
      category: "Food Products",
      tests: [
        "Microbiological Testing",
        "Pesticide Residue Analysis",
        "Heavy Metal Detection",
        "Nutritional Content Analysis",
        "Shelf Life Studies",
        "Organoleptic Evaluation",
      ],
    },
    {
      category: "Minerals & Gemstones",
      tests: [
        "Gemological Identification",
        "Chemical Composition Analysis",
        "Authenticity Verification",
        "Quality Grading",
        "Treatment Detection",
        "Certification Documentation",
      ],
    },
    {
      category: "Salt Products",
      tests: [
        "Purity Analysis",
        "Moisture Content Testing",
        "Particle Size Distribution",
        "Heavy Metal Screening",
        "Mineral Content Analysis",
        "Microbiological Testing",
      ],
    },
  ];

  const qualityMetrics = [
    { metric: "Product Quality Rate", value: "99.8%", trend: "+0.2%" },
    { metric: "Customer Satisfaction", value: "98.5%", trend: "+1.5%" },
    { metric: "On-Time Delivery", value: "99.2%", trend: "+0.8%" },
    { metric: "Zero Defect Shipments", value: "97.8%", trend: "+2.1%" },
    { metric: "Certification Compliance", value: "100%", trend: "0%" },
    { metric: "Supplier Quality Score", value: "96.3%", trend: "+1.2%" },
  ];

  const certifications = [
    {
      name: "ISO 9001:2015",
      description: "Quality Management Systems",
      validUntil: "2026",
      scope: "All business operations",
    },
    {
      name: "ISO 14001:2015",
      description: "Environmental Management Systems",
      validUntil: "2026",
      scope: "Manufacturing and logistics",
    },
    {
      name: "HACCP",
      description: "Food Safety Management",
      validUntil: "2025",
      scope: "Food products division",
    },
    {
      name: "GMP",
      description: "Good Manufacturing Practices",
      validUntil: "2025",
      scope: "All production facilities",
    },
  ];

  const improvementInitiatives = [
    {
      title: "Digital Quality Management",
      description: "Implementation of digital QMS for real-time monitoring",
      status: "In Progress",
      completion: "75%",
    },
    {
      title: "Supplier Development Program",
      description: "Enhanced supplier training and certification program",
      status: "Active",
      completion: "90%",
    },
    {
      title: "Laboratory Automation",
      description: "Automated testing systems for faster, accurate results",
      status: "Planning",
      completion: "25%",
    },
    {
      title: "Sustainability Standards",
      description:
        "Integration of environmental standards in quality processes",
      status: "In Progress",
      completion: "60%",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <section className="py-20 bg-gradient-to-br from-orange-50 to-orange-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="bg-orange-100 text-orange-800 mb-6">
              🛡️ Excellence in Quality
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Quality Standards
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              AISAAUS International maintains the highest quality standards
              through comprehensive testing, international certifications, and
              continuous improvement processes.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-16">
            Our Quality Framework
          </h2>

          <div className="grid md:grid-cols-2 gap-8 mb-16">
            {qualityPillars.map((pillar, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="bg-orange-100 rounded-lg p-3 w-fit text-orange-500 mb-4">
                    {pillar.icon}
                  </div>
                  <CardTitle className="text-xl">{pillar.title}</CardTitle>
                  <p className="text-gray-600">{pillar.description}</p>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2">
                    {pillar.standards.map((standard, i) => (
                      <div
                        key={i}
                        className="flex items-center text-sm text-gray-700"
                      >
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        {standard}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Quality Metrics */}
          <Card className="mb-16">
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart3 className="h-6 w-6 text-orange-500 mr-3" />
                Quality Performance Metrics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {qualityMetrics.map((metric, index) => (
                  <div
                    key={index}
                    className="text-center p-4 bg-gray-50 rounded-lg"
                  >
                    <div className="text-3xl font-bold text-orange-500 mb-1">
                      {metric.value}
                    </div>
                    <div className="text-gray-700 font-medium mb-2">
                      {metric.metric}
                    </div>
                    <Badge
                      className={
                        metric.trend.startsWith("+")
                          ? "bg-green-100 text-green-800"
                          : "bg-gray-100 text-gray-800"
                      }
                    >
                      {metric.trend} YoY
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Testing Procedures */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-center text-gray-900 mb-12">
              Product Testing Procedures
            </h3>
            <div className="grid md:grid-cols-2 gap-8">
              {testingProcedures.map((procedure, index) => (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Microscope className="h-6 w-6 text-orange-500 mr-3" />
                      {procedure.category}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {procedure.tests.map((test, i) => (
                        <li
                          key={i}
                          className="flex items-center text-sm text-gray-700"
                        >
                          <CheckCircle className="h-4 w-4 text-orange-500 mr-2" />
                          {test}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Certifications */}
          <Card className="mb-16">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Award className="h-6 w-6 text-orange-500 mr-3" />
                Current Certifications
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                {certifications.map((cert, index) => (
                  <div
                    key={index}
                    className="border rounded-lg p-4 hover:bg-gray-50"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="font-semibold text-gray-900">
                          {cert.name}
                        </h3>
                        <p className="text-gray-600 text-sm">
                          {cert.description}
                        </p>
                      </div>
                      <Badge className="bg-green-100 text-green-800">
                        Valid
                      </Badge>
                    </div>
                    <div className="text-sm text-gray-500">
                      <div>Valid until: {cert.validUntil}</div>
                      <div>Scope: {cert.scope}</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Continuous Improvement */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="h-6 w-6 text-orange-500 mr-3" />
                Continuous Improvement Initiatives
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {improvementInitiatives.map((initiative, index) => (
                  <div
                    key={index}
                    className="border-l-4 border-orange-500 pl-4"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-gray-900">
                        {initiative.title}
                      </h3>
                      <Badge
                        className={
                          initiative.status === "Active"
                            ? "bg-green-100 text-green-800"
                            : initiative.status === "In Progress"
                              ? "bg-blue-100 text-blue-800"
                              : "bg-yellow-100 text-yellow-800"
                        }
                      >
                        {initiative.status}
                      </Badge>
                    </div>
                    <p className="text-gray-600 text-sm mb-3">
                      {initiative.description}
                    </p>
                    <div className="flex items-center">
                      <div className="flex-1 bg-gray-200 rounded-full h-2 mr-3">
                        <div
                          className="bg-orange-500 h-2 rounded-full"
                          style={{ width: initiative.completion }}
                        ></div>
                      </div>
                      <span className="text-sm text-gray-600">
                        {initiative.completion} Complete
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Quality Assurance Contact
            </h2>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              Have questions about our quality standards or need specific
              testing information? Contact our Quality Assurance team.
            </p>
            <Card className="max-w-md mx-auto p-6 bg-white">
              <h3 className="font-semibold text-gray-900 mb-4">
                Quality Assurance Department
              </h3>
              <div className="space-y-3 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Email:</span>
                  <span className="text-orange-500">
                    quality@aisaausinternational.com
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Direct Line:</span>
                  <span className="text-orange-500">+92 32 14387645</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Lab Hours:</span>
                  <span className="text-gray-700">24/7 Testing Available</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
};

export default QualityStandards;
