const express = require("express");
const router = express.Router();
const { getDb } = require("../database/init.cjs");
const { sendEmail } = require("../services/emailService.cjs");
const { validateEmail } = require("../middleware/validation.cjs");
const rateLimit = require("express-rate-limit");

// Rate limiting for newsletter signup
const newsletterLimiter = rateLimit({
  windowMs: 5 * 60 * 1000, // 5 minutes
  max: 3, // limit each IP to 3 newsletter signups per 5 minutes
  message: {
    error: "Too many newsletter signup attempts. Please wait 5 minutes.",
  },
});

// Subscribe to newsletter
router.post(
  "/subscribe",
  newsletterLimiter,
  validateEmail,
  async (req, res) => {
    const { email, name } = req.body;
    const db = getDb();

    try {
      // Check if email already exists
      const existing = await new Promise((resolve, reject) => {
        db.get(
          "SELECT id, status FROM newsletter_subscribers WHERE email = ?",
          [email],
          (err, row) => {
            if (err) reject(err);
            else resolve(row);
          },
        );
      });

      if (existing) {
        if (existing.status === "active") {
          return res.status(400).json({
            success: false,
            error: "Email is already subscribed to our newsletter",
          });
        } else {
          // Reactivate subscription
          await new Promise((resolve, reject) => {
            db.run(
              `UPDATE newsletter_subscribers
             SET status = 'active', subscribed_at = CURRENT_TIMESTAMP, unsubscribed_at = NULL
             WHERE email = ?`,
              [email],
              (err) => {
                if (err) reject(err);
                else resolve();
              },
            );
          });
        }
      } else {
        // New subscription
        await new Promise((resolve, reject) => {
          db.run(
            `INSERT INTO newsletter_subscribers (email, name, source)
           VALUES (?, ?, ?)`,
            [email, name || null, "website"],
            function (err) {
              if (err) reject(err);
              else resolve({ id: this.lastID });
            },
          );
        });
      }

      // Send welcome email
      try {
        await sendEmail({
          to: email,
          subject: "Welcome to AISAAUS International Newsletter",
          template: "newsletter_welcome",
          data: {
            name: name || "Valued Subscriber",
          },
        });
      } catch (emailError) {
        console.error("Failed to send welcome email:", emailError);
      }

      res.status(201).json({
        success: true,
        message: "Successfully subscribed to newsletter",
      });
    } catch (error) {
      console.error("Error subscribing to newsletter:", error);
      res.status(500).json({
        success: false,
        error: "Failed to subscribe to newsletter",
      });
    }
  },
);

// Unsubscribe from newsletter
router.post("/unsubscribe", async (req, res) => {
  const { email } = req.body;
  const db = getDb();

  try {
    const result = await new Promise((resolve, reject) => {
      db.run(
        `UPDATE newsletter_subscribers
         SET status = 'unsubscribed', unsubscribed_at = CURRENT_TIMESTAMP
         WHERE email = ? AND status = 'active'`,
        [email],
        function (err) {
          if (err) reject(err);
          else resolve({ changes: this.changes });
        },
      );
    });

    if (result.changes === 0) {
      return res.status(404).json({
        success: false,
        error: "Email not found in active subscriptions",
      });
    }

    res.json({
      success: true,
      message: "Successfully unsubscribed from newsletter",
    });
  } catch (error) {
    console.error("Error unsubscribing from newsletter:", error);
    res.status(500).json({
      success: false,
      error: "Failed to unsubscribe from newsletter",
    });
  }
});

// Get all subscribers (admin only)
router.get("/subscribers", async (req, res) => {
  const db = getDb();
  const { status = "active" } = req.query;

  try {
    const subscribers = await new Promise((resolve, reject) => {
      db.all(
        `SELECT * FROM newsletter_subscribers
         WHERE status = ?
         ORDER BY subscribed_at DESC`,
        [status],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        },
      );
    });

    res.json({
      success: true,
      data: subscribers,
      total: subscribers.length,
    });
  } catch (error) {
    console.error("Error fetching subscribers:", error);
    res.status(500).json({
      success: false,
      error: "Failed to fetch subscribers",
    });
  }
});

// Get newsletter statistics
router.get("/stats", async (req, res) => {
  const db = getDb();

  try {
    const stats = await new Promise((resolve, reject) => {
      db.all(
        `SELECT
          COUNT(*) as total,
          COUNT(CASE WHEN status = 'active' THEN 1 END) as active,
          COUNT(CASE WHEN status = 'unsubscribed' THEN 1 END) as unsubscribed,
          COUNT(CASE WHEN DATE(subscribed_at) = DATE('now') THEN 1 END) as today,
          COUNT(CASE WHEN DATE(subscribed_at) >= DATE('now', '-7 days') THEN 1 END) as this_week,
          COUNT(CASE WHEN DATE(subscribed_at) >= DATE('now', '-30 days') THEN 1 END) as this_month
         FROM newsletter_subscribers`,
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows[0]);
        },
      );
    });

    // Get subscription trends
    const trends = await new Promise((resolve, reject) => {
      db.all(
        `SELECT
          DATE(subscribed_at) as date,
          COUNT(*) as count
         FROM newsletter_subscribers
         WHERE DATE(subscribed_at) >= DATE('now', '-30 days')
         GROUP BY DATE(subscribed_at)
         ORDER BY date ASC`,
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        },
      );
    });

    res.json({
      success: true,
      data: {
        ...stats,
        trends,
      },
    });
  } catch (error) {
    console.error("Error fetching newsletter stats:", error);
    res.status(500).json({
      success: false,
      error: "Failed to fetch statistics",
    });
  }
});

// Send newsletter to all active subscribers (admin only)
router.post("/send", async (req, res) => {
  const { subject, content, template } = req.body;
  const db = getDb();

  try {
    // Get all active subscribers
    const subscribers = await new Promise((resolve, reject) => {
      db.all(
        "SELECT email, name FROM newsletter_subscribers WHERE status = 'active'",
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        },
      );
    });

    if (subscribers.length === 0) {
      return res.status(400).json({
        success: false,
        error: "No active subscribers found",
      });
    }

    // Send emails in batches to avoid overwhelming the email service
    const batchSize = 50;
    let sent = 0;
    let failed = 0;

    for (let i = 0; i < subscribers.length; i += batchSize) {
      const batch = subscribers.slice(i, i + batchSize);

      const promises = batch.map(async (subscriber) => {
        try {
          await sendEmail({
            to: subscriber.email,
            subject,
            template: template || "newsletter_custom",
            data: {
              name: subscriber.name || "Valued Subscriber",
              content,
            },
          });
          sent++;
        } catch (error) {
          console.error(`Failed to send to ${subscriber.email}:`, error);
          failed++;
        }
      });

      await Promise.allSettled(promises);

      // Small delay between batches
      if (i + batchSize < subscribers.length) {
        await new Promise((resolve) => setTimeout(resolve, 1000));
      }
    }

    res.json({
      success: true,
      message: `Newsletter sent successfully`,
      stats: {
        total: subscribers.length,
        sent,
        failed,
      },
    });
  } catch (error) {
    console.error("Error sending newsletter:", error);
    res.status(500).json({
      success: false,
      error: "Failed to send newsletter",
    });
  }
});

module.exports = router;
