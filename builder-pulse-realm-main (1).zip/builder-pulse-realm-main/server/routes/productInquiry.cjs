const express = require("express");
const router = express.Router();
const { getDb } = require("../database/init.cjs");
const { sendEmail } = require("../services/emailService.cjs");
const { validateProductInquiry } = require("../middleware/validation.cjs");
const rateLimit = require("express-rate-limit");

// Rate limiting for product inquiries
const inquiryLimiter = rateLimit({
  windowMs: 5 * 60 * 1000, // 5 minutes
  max: 5, // limit each IP to 5 product inquiries per 5 minutes
  message: {
    error: "Too many product inquiries. Please wait 5 minutes.",
  },
});

// Submit product inquiry
router.post(
  "/submit",
  inquiryLimiter,
  validateProductInquiry,
  async (req, res) => {
    const {
      name,
      email,
      phone,
      company,
      productName,
      productCategory,
      inquiryType,
      quantity,
      specifications,
      message,
    } = req.body;

    const db = getDb();

    try {
      // Save to database
      const result = await new Promise((resolve, reject) => {
        db.run(
          `INSERT INTO product_inquiries (
          name, email, phone, company, product_name, product_category,
          inquiry_type, quantity, specifications, message
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            name,
            email,
            phone || null,
            company || null,
            productName,
            productCategory,
            inquiryType,
            quantity || null,
            specifications || null,
            message || null,
          ],
          function (err) {
            if (err) reject(err);
            else resolve({ id: this.lastID });
          },
        );
      });

      // Send email notification to admin
      try {
        await sendEmail({
          to: process.env.ADMIN_EMAIL || "admin@aisaaus.com",
          subject: `New Product Inquiry - ${productName} (${inquiryType})`,
          template: "product_inquiry_notification",
          data: {
            name,
            email,
            phone,
            company,
            productName,
            productCategory,
            inquiryType,
            quantity,
            specifications,
            message,
            inquiryId: result.id,
          },
        });
      } catch (emailError) {
        console.error(
          "Failed to send product inquiry notification email:",
          emailError,
        );
      }

      // Send confirmation email to user
      try {
        await sendEmail({
          to: email,
          subject: `Product Inquiry Received - ${productName}`,
          template: "product_inquiry_confirmation",
          data: {
            name,
            productName,
            inquiryType,
            inquiryId: result.id,
          },
        });
      } catch (emailError) {
        console.error(
          "Failed to send product inquiry confirmation email:",
          emailError,
        );
      }

      res.status(201).json({
        success: true,
        message: "Product inquiry submitted successfully",
        inquiryId: result.id,
      });
    } catch (error) {
      console.error("Error submitting product inquiry:", error);
      res.status(500).json({
        success: false,
        error: "Failed to submit product inquiry",
      });
    }
  },
);

// Get all product inquiries (admin only)
router.get("/all", async (req, res) => {
  const db = getDb();
  const { category, status, type } = req.query;

  let query = `SELECT * FROM product_inquiries WHERE 1=1`;
  const params = [];

  if (category) {
    query += ` AND product_category = ?`;
    params.push(category);
  }

  if (status) {
    query += ` AND status = ?`;
    params.push(status);
  }

  if (type) {
    query += ` AND inquiry_type = ?`;
    params.push(type);
  }

  query += ` ORDER BY created_at DESC`;

  try {
    const inquiries = await new Promise((resolve, reject) => {
      db.all(query, params, (err, rows) => {
        if (err) reject(err);
        else resolve(rows);
      });
    });

    res.json({
      success: true,
      data: inquiries,
      total: inquiries.length,
    });
  } catch (error) {
    console.error("Error fetching product inquiries:", error);
    res.status(500).json({
      success: false,
      error: "Failed to fetch product inquiries",
    });
  }
});

// Update inquiry status
router.patch("/:id/status", async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const db = getDb();

  try {
    await new Promise((resolve, reject) => {
      db.run(
        `UPDATE product_inquiries SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
        [status, id],
        function (err) {
          if (err) reject(err);
          else resolve();
        },
      );
    });

    res.json({
      success: true,
      message: "Inquiry status updated successfully",
    });
  } catch (error) {
    console.error("Error updating inquiry status:", error);
    res.status(500).json({
      success: false,
      error: "Failed to update inquiry status",
    });
  }
});

// Get product inquiry statistics
router.get("/stats", async (req, res) => {
  const db = getDb();

  try {
    const stats = await new Promise((resolve, reject) => {
      db.all(
        `SELECT
          COUNT(*) as total,
          COUNT(CASE WHEN status = 'new' THEN 1 END) as new_inquiries,
          COUNT(CASE WHEN status = 'processing' THEN 1 END) as processing,
          COUNT(CASE WHEN status = 'responded' THEN 1 END) as responded,
          COUNT(CASE WHEN status = 'closed' THEN 1 END) as closed,
          COUNT(CASE WHEN DATE(created_at) = DATE('now') THEN 1 END) as today
         FROM product_inquiries`,
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows[0]);
        },
      );
    });

    // Get popular products
    const popularProducts = await new Promise((resolve, reject) => {
      db.all(
        `SELECT product_name, product_category, COUNT(*) as count
         FROM product_inquiries
         GROUP BY product_name, product_category
         ORDER BY count DESC
         LIMIT 10`,
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        },
      );
    });

    // Get inquiry types breakdown
    const inquiryTypes = await new Promise((resolve, reject) => {
      db.all(
        `SELECT inquiry_type, COUNT(*) as count
         FROM product_inquiries
         GROUP BY inquiry_type
         ORDER BY count DESC`,
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        },
      );
    });

    // Get category breakdown
    const categories = await new Promise((resolve, reject) => {
      db.all(
        `SELECT product_category, COUNT(*) as count
         FROM product_inquiries
         GROUP BY product_category
         ORDER BY count DESC`,
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        },
      );
    });

    res.json({
      success: true,
      data: {
        ...stats,
        popularProducts,
        inquiryTypes,
        categories,
      },
    });
  } catch (error) {
    console.error("Error fetching product inquiry stats:", error);
    res.status(500).json({
      success: false,
      error: "Failed to fetch statistics",
    });
  }
});

// Get specific inquiry details
router.get("/:id", async (req, res) => {
  const { id } = req.params;
  const db = getDb();

  try {
    const inquiry = await new Promise((resolve, reject) => {
      db.get(
        `SELECT * FROM product_inquiries WHERE id = ?`,
        [id],
        (err, row) => {
          if (err) reject(err);
          else resolve(row);
        },
      );
    });

    if (!inquiry) {
      return res.status(404).json({
        success: false,
        error: "Inquiry not found",
      });
    }

    res.json({
      success: true,
      data: inquiry,
    });
  } catch (error) {
    console.error("Error fetching inquiry details:", error);
    res.status(500).json({
      success: false,
      error: "Failed to fetch inquiry details",
    });
  }
});

module.exports = router;
