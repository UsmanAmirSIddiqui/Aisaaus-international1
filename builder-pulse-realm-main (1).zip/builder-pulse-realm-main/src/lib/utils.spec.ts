import { describe, it, expect } from "vitest";
import { cn } from "./utils";

describe("cn utility function", () => {
  it("should merge class names correctly", () => {
    expect(cn("btn", "btn-primary")).toBe("btn btn-primary");
  });

  it("should handle conditional classes", () => {
    expect(cn("btn", true && "btn-primary", false && "btn-secondary")).toBe(
      "btn btn-primary",
    );
  });

  it("should merge conflicting Tailwind classes", () => {
    expect(cn("px-2 py-1", "px-3")).toBe("py-1 px-3");
  });

  it("should handle undefined and null values", () => {
    expect(cn("btn", undefined, null, "btn-primary")).toBe("btn btn-primary");
  });

  it("should work with arrays", () => {
    expect(cn(["btn", "btn-primary"], "text-white")).toBe(
      "btn btn-primary text-white",
    );
  });
});
