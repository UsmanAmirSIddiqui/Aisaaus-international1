import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  TrendingUp,
  DollarSign,
  Users,
  Globe,
  BarChart3,
  FileText,
  Calendar,
  Download,
  PieChart,
  Target,
  Building,
  Award,
} from "lucide-react";

const InvestorRelations = () => {
  const financialHighlights = [
    {
      title: "Annual Revenue",
      value: "$50M+",
      growth: "+25%",
      icon: <DollarSign className="h-8 w-8" />,
    },
    {
      title: "Export Volume",
      value: "$25M+",
      growth: "+30%",
      icon: <Globe className="h-8 w-8" />,
    },
    {
      title: "Market Presence",
      value: "50+ Countries",
      growth: "+12%",
      icon: <Building className="h-8 w-8" />,
    },
    {
      title: "Employee Growth",
      value: "1000+",
      growth: "+15%",
      icon: <Users className="h-8 w-8" />,
    },
  ];

  const businessSegments = [
    {
      segment: "Petroleum Products",
      revenue: "$20M",
      percentage: "40%",
      growth: "+22%",
    },
    {
      segment: "Food Products",
      revenue: "$15M",
      percentage: "30%",
      growth: "+35%",
    },
    {
      segment: "Minerals & Gemstones",
      revenue: "$10M",
      percentage: "20%",
      growth: "+18%",
    },
    {
      segment: "Salt Products",
      revenue: "$5M",
      percentage: "10%",
      growth: "+45%",
    },
  ];

  const geographicRevenue = [
    { region: "Middle East", percentage: "35%", revenue: "$17.5M" },
    { region: "Europe", percentage: "25%", revenue: "$12.5M" },
    { region: "Asia Pacific", percentage: "20%", revenue: "$10M" },
    { region: "North America", percentage: "15%", revenue: "$7.5M" },
    { region: "Others", percentage: "5%", revenue: "$2.5M" },
  ];

  const keyMetrics = [
    { metric: "Gross Profit Margin", value: "35%" },
    { metric: "EBITDA Margin", value: "22%" },
    { metric: "Return on Assets", value: "18%" },
    { metric: "Working Capital Ratio", value: "2.1" },
    { metric: "Debt to Equity", value: "0.3" },
    { metric: "Current Ratio", value: "1.8" },
  ];

  const reports = [
    {
      title: "Annual Report 2023",
      date: "March 2024",
      type: "Annual Report",
      size: "2.5 MB",
    },
    {
      title: "Q4 2023 Financial Results",
      date: "February 2024",
      type: "Quarterly Report",
      size: "1.2 MB",
    },
    {
      title: "Sustainability Report 2023",
      date: "April 2024",
      type: "ESG Report",
      size: "3.1 MB",
    },
    {
      title: "Corporate Governance Report",
      date: "March 2024",
      type: "Governance",
      size: "1.8 MB",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <section className="py-20 bg-gradient-to-br from-orange-50 to-orange-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="bg-orange-100 text-orange-800 mb-6">
              📊 Financial Information
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Investor Relations
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive financial information and strategic insights for
              stakeholders, investors, and business partners of AISAAUS
              International.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-16">
            Financial Highlights
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {financialHighlights.map((highlight, index) => (
              <Card key={index} className="text-center">
                <CardContent className="p-6">
                  <div className="bg-orange-100 rounded-full p-3 w-16 h-16 mx-auto mb-4 flex items-center justify-center text-orange-500">
                    {highlight.icon}
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-1">
                    {highlight.value}
                  </div>
                  <div className="text-gray-600 mb-2">{highlight.title}</div>
                  <Badge className="bg-green-100 text-green-800">
                    {highlight.growth} YoY
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-12 mb-16">
            {/* Business Segments */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <PieChart className="h-6 w-6 text-orange-500 mr-3" />
                  Revenue by Business Segment
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {businessSegments.map((segment, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between"
                    >
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium text-gray-900">
                            {segment.segment}
                          </span>
                          <span className="text-gray-600">
                            {segment.revenue}
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-orange-500 h-2 rounded-full"
                            style={{ width: segment.percentage }}
                          ></div>
                        </div>
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-sm text-gray-500">
                            {segment.percentage}
                          </span>
                          <Badge className="bg-green-100 text-green-800 text-xs">
                            {segment.growth}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Geographic Revenue */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Globe className="h-6 w-6 text-orange-500 mr-3" />
                  Revenue by Geography
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {geographicRevenue.map((region, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between"
                    >
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium text-gray-900">
                            {region.region}
                          </span>
                          <span className="text-gray-600">
                            {region.revenue}
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-orange-500 h-2 rounded-full"
                            style={{ width: region.percentage }}
                          ></div>
                        </div>
                        <div className="text-sm text-gray-500 mt-1">
                          {region.percentage} of total revenue
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Key Financial Metrics */}
          <Card className="mb-16">
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart3 className="h-6 w-6 text-orange-500 mr-3" />
                Key Financial Metrics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {keyMetrics.map((metric, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                  >
                    <span className="font-medium text-gray-900">
                      {metric.metric}
                    </span>
                    <span className="text-xl font-bold text-orange-500">
                      {metric.value}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Strategic Initiatives */}
          <Card className="mb-16">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="h-6 w-6 text-orange-500 mr-3" />
                Strategic Initiatives
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-8">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-4">
                    Growth Strategy
                  </h3>
                  <ul className="space-y-2 text-gray-600">
                    <li>• Expansion into South American markets</li>
                    <li>• Digital transformation initiatives</li>
                    <li>• Sustainable product line development</li>
                    <li>• Supply chain optimization</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-4">
                    Investment Priorities
                  </h3>
                  <ul className="space-y-2 text-gray-600">
                    <li>• Technology infrastructure upgrade</li>
                    <li>��� Quality testing facility expansion</li>
                    <li>• Human capital development</li>
                    <li>• Sustainability initiatives</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Reports and Documents */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="h-6 w-6 text-orange-500 mr-3" />
                Financial Reports & Documents
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                {reports.map((report, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
                  >
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900">
                        {report.title}
                      </h3>
                      <div className="flex items-center text-sm text-gray-500 mt-1">
                        <Calendar className="h-4 w-4 mr-1" />
                        {report.date}
                        <span className="mx-2">•</span>
                        {report.size}
                      </div>
                      <Badge className="mt-2" variant="outline">
                        {report.type}
                      </Badge>
                    </div>
                    <Button variant="ghost" size="sm">
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">
              Investor Contact
            </h2>
            <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
              For investor inquiries, financial information requests, or
              partnership opportunities, please contact our investor relations
              team.
            </p>
            <Card className="max-w-md mx-auto p-6 bg-white">
              <h3 className="font-semibold text-gray-900 mb-4">
                Investor Relations Team
              </h3>
              <div className="space-y-3 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Email:</span>
                  <span className="text-orange-500">
                    investors@aisaausinternational.com
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Phone:</span>
                  <span className="text-orange-500">+92 32 38088081</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Office Hours:</span>
                  <span className="text-gray-700">9 AM - 6 PM PKT</span>
                </div>
              </div>
              <Button className="w-full mt-4 bg-orange-500 hover:bg-orange-600">
                Schedule Meeting
              </Button>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
};

export default InvestorRelations;
