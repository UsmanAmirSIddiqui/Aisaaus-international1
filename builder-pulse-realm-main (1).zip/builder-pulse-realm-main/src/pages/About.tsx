import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  CheckCircle,
  Users,
  Award,
  Target,
  TrendingUp,
  Calendar,
  Shield,
  Droplets,
  Gem,
  Apple,
  Mountain,
} from "lucide-react";

const About = () => {
  return (
    <div className="min-h-screen bg-white">
      {/* About Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              About AISAAUS International
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Established in 1999 in Lahore, Pakistan. Leading international
              trade company with over 1000 employees.
            </p>
          </div>

          {/* Company Introduction */}
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">
                Company Introduction
              </h2>
              <p className="text-gray-600 mb-6 leading-relaxed">
                AISAAUS International was established in 1999 in Lahore,
                Pakistan. Over the past 25 years, we have grown from a small
                trading company to a global enterprise with over 1000 dedicated
                employees.
              </p>
              <div className="space-y-4">
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-orange-500 mr-3" />
                  <span className="text-gray-700">
                    Established 1999, Lahore, Pakistan
                  </span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-orange-500 mr-3" />
                  <span className="text-gray-700">
                    Over 1000 employees worldwide
                  </span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-orange-500 mr-3" />
                  <span className="text-gray-700">
                    25+ years of international trade experience
                  </span>
                </div>
              </div>
            </div>

            {/* Leadership */}
            <Card className="p-8">
              <h3 className="text-xl font-bold text-gray-900 mb-6">
                Leadership
              </h3>
              <div className="flex items-center space-x-4">
                <img
                  src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face"
                  alt="Dr. Amir Siddiqui"
                  className="w-16 h-16 rounded-full object-cover"
                />
                <div>
                  <h4 className="font-semibold text-gray-900">
                    Dr. Amir Siddiqui
                  </h4>
                  <p className="text-orange-500 font-medium">Founder & CEO</p>
                  <p className="text-sm text-gray-600">
                    Visionary leader driving global trade excellence
                  </p>
                </div>
              </div>
            </Card>
          </div>

          {/* Key Offerings */}
          <div className="mb-16">
            <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">
              Key Offerings
            </h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[
                {
                  title: "Petroleum & Byproducts",
                  icon: <Droplets className="h-8 w-8" />,
                  color: "bg-blue-100 text-blue-500",
                },
                {
                  title: "Minerals & Gemstones",
                  icon: <Gem className="h-8 w-8" />,
                  color: "bg-purple-100 text-purple-500",
                },
                {
                  title: "Food Items",
                  icon: <Apple className="h-8 w-8" />,
                  color: "bg-green-100 text-green-500",
                },
                {
                  title: "Pink Himalayan & White Salt",
                  icon: <Mountain className="h-8 w-8" />,
                  color: "bg-gray-100 text-gray-500",
                },
              ].map((item, index) => (
                <Card
                  key={index}
                  className="text-center hover:shadow-lg transition-shadow"
                >
                  <CardContent className="p-6">
                    <div
                      className={`rounded-lg p-3 w-fit mx-auto mb-4 ${item.color}`}
                    >
                      {item.icon}
                    </div>
                    <h4 className="font-semibold text-gray-900">
                      {item.title}
                    </h4>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Why Choose Us */}
          <div className="bg-gray-50 rounded-xl p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">
              Why Choose Us
            </h3>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="bg-orange-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <Calendar className="h-8 w-8 text-orange-500" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">
                  20+ Years Experience
                </h4>
                <p className="text-gray-600 text-sm">
                  Proven track record in international trade
                </p>
              </div>
              <div className="text-center">
                <div className="bg-orange-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <Shield className="h-8 w-8 text-orange-500" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">
                  High-Quality Goods
                </h4>
                <p className="text-gray-600 text-sm">
                  Premium products meeting international standards
                </p>
              </div>
              <div className="text-center">
                <div className="bg-orange-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <TrendingUp className="h-8 w-8 text-orange-500" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">
                  Robust CRM & Export Record
                </h4>
                <p className="text-gray-600 text-sm">
                  $200,000+ export value with excellent client relationships
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
