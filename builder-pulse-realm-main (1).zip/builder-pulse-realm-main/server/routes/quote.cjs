const express = require("express");
const router = express.Router();
const { getDb } = require("../database/init.cjs");
const { sendEmail } = require("../services/emailService.cjs");
const { validateQuote } = require("../middleware/validation.cjs");
const rateLimit = require("express-rate-limit");

// Rate limiting for quote requests
const quoteLimiter = rateLimit({
  windowMs: 10 * 60 * 1000, // 10 minutes
  max: 2, // limit each IP to 2 quote requests per 10 minutes
  message: {
    error: "Too many quote requests. Please wait 10 minutes.",
  },
});

// Submit quote request
router.post("/request", quoteLimiter, validateQuote, async (req, res) => {
  const {
    name,
    email,
    phone,
    company,
    productCategory,
    specificProducts,
    quantity,
    budgetRange,
    deliveryLocation,
    urgency,
    message,
  } = req.body;

  const db = getDb();

  try {
    // Save to database
    const result = await new Promise((resolve, reject) => {
      db.run(
        `INSERT INTO quotes (
          name, email, phone, company, product_category, specific_products,
          quantity, budget_range, delivery_location, urgency, message
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          name,
          email,
          phone || null,
          company,
          productCategory,
          specificProducts || null,
          quantity || null,
          budgetRange || null,
          deliveryLocation || null,
          urgency || "standard",
          message || null,
        ],
        function (err) {
          if (err) reject(err);
          else resolve({ id: this.lastID });
        },
      );
    });

    // Send email notification to admin
    try {
      await sendEmail({
        to: process.env.ADMIN_EMAIL || "admin@aisaaus.com",
        subject: `New Quote Request - ${company} (${productCategory})`,
        template: "quote_notification",
        data: {
          name,
          email,
          phone,
          company,
          productCategory,
          specificProducts,
          quantity,
          budgetRange,
          deliveryLocation,
          urgency,
          message,
          quoteId: result.id,
        },
      });
    } catch (emailError) {
      console.error("Failed to send quote notification email:", emailError);
    }

    // Send confirmation email to user
    try {
      await sendEmail({
        to: email,
        subject: "Quote Request Received - AISAAUS International",
        template: "quote_confirmation",
        data: {
          name,
          company,
          productCategory,
          quoteId: result.id,
        },
      });
    } catch (emailError) {
      console.error("Failed to send quote confirmation email:", emailError);
    }

    res.status(201).json({
      success: true,
      message: "Quote request submitted successfully",
      quoteId: result.id,
    });
  } catch (error) {
    console.error("Error submitting quote request:", error);
    res.status(500).json({
      success: false,
      error: "Failed to submit quote request",
    });
  }
});

// Get all quote requests (admin only)
router.get("/all", async (req, res) => {
  const db = getDb();

  try {
    const quotes = await new Promise((resolve, reject) => {
      db.all(
        `SELECT * FROM quotes ORDER BY created_at DESC`,
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        },
      );
    });

    res.json({
      success: true,
      data: quotes,
      total: quotes.length,
    });
  } catch (error) {
    console.error("Error fetching quotes:", error);
    res.status(500).json({
      success: false,
      error: "Failed to fetch quotes",
    });
  }
});

// Update quote status
router.patch("/:id/status", async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const db = getDb();

  try {
    await new Promise((resolve, reject) => {
      db.run(
        `UPDATE quotes SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
        [status, id],
        function (err) {
          if (err) reject(err);
          else resolve();
        },
      );
    });

    res.json({
      success: true,
      message: "Quote status updated successfully",
    });
  } catch (error) {
    console.error("Error updating quote status:", error);
    res.status(500).json({
      success: false,
      error: "Failed to update quote status",
    });
  }
});

// Get quote statistics
router.get("/stats", async (req, res) => {
  const db = getDb();

  try {
    const stats = await new Promise((resolve, reject) => {
      db.all(
        `SELECT
          COUNT(*) as total,
          COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending,
          COUNT(CASE WHEN status = 'processing' THEN 1 END) as processing,
          COUNT(CASE WHEN status = 'quoted' THEN 1 END) as quoted,
          COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed,
          COUNT(CASE WHEN urgency = 'urgent' THEN 1 END) as urgent,
          COUNT(CASE WHEN DATE(created_at) = DATE('now') THEN 1 END) as today
         FROM quotes`,
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows[0]);
        },
      );
    });

    // Get popular categories
    const categories = await new Promise((resolve, reject) => {
      db.all(
        `SELECT product_category, COUNT(*) as count
         FROM quotes
         GROUP BY product_category
         ORDER BY count DESC
         LIMIT 5`,
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        },
      );
    });

    res.json({
      success: true,
      data: {
        ...stats,
        popularCategories: categories,
      },
    });
  } catch (error) {
    console.error("Error fetching quote stats:", error);
    res.status(500).json({
      success: false,
      error: "Failed to fetch statistics",
    });
  }
});

module.exports = router;
