const express = require("express");
const router = express.Router();
const { getDb } = require("../database/init.cjs");
const { sendEmail } = require("../services/emailService.cjs");
const { validateContact } = require("../middleware/validation.cjs");
const rateLimit = require("express-rate-limit");

// Rate limiting for contact form
const contactLimiter = rateLimit({
  windowMs: 5 * 60 * 1000, // 5 minutes
  max: 3, // limit each IP to 3 contact form submissions per 5 minutes
  message: {
    error: "Too many contact form submissions. Please wait 5 minutes.",
  },
});

// Submit contact form
router.post("/submit", contactLimiter, validateContact, async (req, res) => {
  const { name, email, phone, company, message } = req.body;
  const db = getDb();

  try {
    // Save to database
    const result = await new Promise((resolve, reject) => {
      db.run(
        `INSERT INTO contacts (name, email, phone, company, message, source)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [name, email, phone || null, company || null, message, "contact_form"],
        function (err) {
          if (err) reject(err);
          else resolve({ id: this.lastID });
        },
      );
    });

    // Send email notification to admin
    try {
      await sendEmail({
        to: process.env.ADMIN_EMAIL || "admin@aisaaus.com",
        subject: `New Contact Form Submission - ${name}`,
        template: "contact_notification",
        data: {
          name,
          email,
          phone,
          company,
          message,
          submissionId: result.id,
        },
      });
    } catch (emailError) {
      console.error("Failed to send notification email:", emailError);
      // Don't fail the request if email fails
    }

    // Send confirmation email to user
    try {
      await sendEmail({
        to: email,
        subject: "Thank you for contacting AISAAUS International",
        template: "contact_confirmation",
        data: {
          name,
          submissionId: result.id,
        },
      });
    } catch (emailError) {
      console.error("Failed to send confirmation email:", emailError);
    }

    res.status(201).json({
      success: true,
      message: "Contact form submitted successfully",
      submissionId: result.id,
    });
  } catch (error) {
    console.error("Error submitting contact form:", error);
    res.status(500).json({
      success: false,
      error: "Failed to submit contact form",
    });
  }
});

// Get all contacts (admin only)
router.get("/all", async (req, res) => {
  const db = getDb();

  try {
    const contacts = await new Promise((resolve, reject) => {
      db.all(
        `SELECT * FROM contacts ORDER BY created_at DESC`,
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        },
      );
    });

    res.json({
      success: true,
      data: contacts,
      total: contacts.length,
    });
  } catch (error) {
    console.error("Error fetching contacts:", error);
    res.status(500).json({
      success: false,
      error: "Failed to fetch contacts",
    });
  }
});

// Update contact status (admin only)
router.patch("/:id/status", async (req, res) => {
  const { id } = req.params;
  const { status } = req.body;
  const db = getDb();

  try {
    await new Promise((resolve, reject) => {
      db.run(
        `UPDATE contacts SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?`,
        [status, id],
        function (err) {
          if (err) reject(err);
          else resolve();
        },
      );
    });

    res.json({
      success: true,
      message: "Contact status updated successfully",
    });
  } catch (error) {
    console.error("Error updating contact status:", error);
    res.status(500).json({
      success: false,
      error: "Failed to update contact status",
    });
  }
});

// Get contact statistics
router.get("/stats", async (req, res) => {
  const db = getDb();

  try {
    const stats = await new Promise((resolve, reject) => {
      db.all(
        `SELECT
          COUNT(*) as total,
          COUNT(CASE WHEN status = 'new' THEN 1 END) as new_contacts,
          COUNT(CASE WHEN status = 'contacted' THEN 1 END) as contacted,
          COUNT(CASE WHEN status = 'resolved' THEN 1 END) as resolved,
          COUNT(CASE WHEN DATE(created_at) = DATE('now') THEN 1 END) as today
         FROM contacts`,
        [],
        (err, rows) => {
          if (err) reject(err);
          else resolve(rows[0]);
        },
      );
    });

    res.json({
      success: true,
      data: stats,
    });
  } catch (error) {
    console.error("Error fetching contact stats:", error);
    res.status(500).json({
      success: false,
      error: "Failed to fetch statistics",
    });
  }
});

module.exports = router;
