const validateContact = (req, res, next) => {
  const { name, email, message } = req.body;

  // Basic validation
  if (!name || !email || !message) {
    return res.status(400).json({
      success: false,
      error: "Name, email, and message are required",
    });
  }

  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({
      success: false,
      error: "Please provide a valid email address",
    });
  }

  // Name validation
  if (name.length < 2 || name.length > 100) {
    return res.status(400).json({
      success: false,
      error: "Name must be between 2 and 100 characters",
    });
  }

  // Message validation
  if (message.length < 10 || message.length > 2000) {
    return res.status(400).json({
      success: false,
      error: "Message must be between 10 and 2000 characters",
    });
  }

  // Phone validation (optional)
  if (req.body.phone) {
    const phoneRegex = /^[\+]?[\d\s\-\(\)]{10,20}$/;
    if (!phoneRegex.test(req.body.phone)) {
      return res.status(400).json({
        success: false,
        error: "Please provide a valid phone number",
      });
    }
  }

  next();
};

const validateQuote = (req, res, next) => {
  const { name, email, company, productCategory } = req.body;

  // Basic validation
  if (!name || !email || !company || !productCategory) {
    return res.status(400).json({
      success: false,
      error: "Name, email, company, and product category are required",
    });
  }

  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({
      success: false,
      error: "Please provide a valid email address",
    });
  }

  // Name validation
  if (name.length < 2 || name.length > 100) {
    return res.status(400).json({
      success: false,
      error: "Name must be between 2 and 100 characters",
    });
  }

  // Company validation
  if (company.length < 2 || company.length > 200) {
    return res.status(400).json({
      success: false,
      error: "Company name must be between 2 and 200 characters",
    });
  }

  // Product category validation
  const validCategories = [
    "Petroleum & Byproducts",
    "Minerals & Gemstones",
    "Food Products",
    "Other Products",
    "Custom Requirements",
  ];

  if (!validCategories.includes(productCategory)) {
    return res.status(400).json({
      success: false,
      error: "Please select a valid product category",
    });
  }

  // Phone validation (optional)
  if (req.body.phone) {
    const phoneRegex = /^[\+]?[\d\s\-\(\)]{10,20}$/;
    if (!phoneRegex.test(req.body.phone)) {
      return res.status(400).json({
        success: false,
        error: "Please provide a valid phone number",
      });
    }
  }

  // Budget range validation (optional)
  if (req.body.budgetRange) {
    const validBudgets = [
      "Under $10,000",
      "$10,000 - $50,000",
      "$50,000 - $100,000",
      "$100,000 - $500,000",
      "$500,000 - $1,000,000",
      "Over $1,000,000",
      "Discuss with sales team",
    ];

    if (!validBudgets.includes(req.body.budgetRange)) {
      return res.status(400).json({
        success: false,
        error: "Please select a valid budget range",
      });
    }
  }

  // Urgency validation (optional)
  if (req.body.urgency) {
    const validUrgencies = ["standard", "urgent", "asap"];
    if (!validUrgencies.includes(req.body.urgency)) {
      return res.status(400).json({
        success: false,
        error: "Please select a valid urgency level",
      });
    }
  }

  next();
};

const validateEmail = (req, res, next) => {
  const { email } = req.body;

  // Email validation
  if (!email) {
    return res.status(400).json({
      success: false,
      error: "Email address is required",
    });
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({
      success: false,
      error: "Please provide a valid email address",
    });
  }

  // Name validation (optional)
  if (req.body.name && req.body.name.length > 100) {
    return res.status(400).json({
      success: false,
      error: "Name must be less than 100 characters",
    });
  }

  next();
};

const validateProductInquiry = (req, res, next) => {
  const { name, email, productName, productCategory, inquiryType } = req.body;

  // Basic validation
  if (!name || !email || !productName || !productCategory || !inquiryType) {
    return res.status(400).json({
      success: false,
      error:
        "Name, email, product name, category, and inquiry type are required",
    });
  }

  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({
      success: false,
      error: "Please provide a valid email address",
    });
  }

  // Name validation
  if (name.length < 2 || name.length > 100) {
    return res.status(400).json({
      success: false,
      error: "Name must be between 2 and 100 characters",
    });
  }

  // Product name validation
  if (productName.length < 2 || productName.length > 200) {
    return res.status(400).json({
      success: false,
      error: "Product name must be between 2 and 200 characters",
    });
  }

  // Product category validation
  const validCategories = [
    "Petroleum & Byproducts",
    "Minerals & Gemstones",
    "Food Products",
    "Other Products",
  ];

  if (!validCategories.includes(productCategory)) {
    return res.status(400).json({
      success: false,
      error: "Please select a valid product category",
    });
  }

  // Inquiry type validation
  const validInquiryTypes = [
    "General Information",
    "Price Inquiry",
    "Sample Request",
    "Bulk Order",
    "Technical Specifications",
    "Partnership Opportunity",
  ];

  if (!validInquiryTypes.includes(inquiryType)) {
    return res.status(400).json({
      success: false,
      error: "Please select a valid inquiry type",
    });
  }

  // Phone validation (optional)
  if (req.body.phone) {
    const phoneRegex = /^[\+]?[\d\s\-\(\)]{10,20}$/;
    if (!phoneRegex.test(req.body.phone)) {
      return res.status(400).json({
        success: false,
        error: "Please provide a valid phone number",
      });
    }
  }

  next();
};

const validateAdmin = (req, res, next) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({
      success: false,
      error: "Username and password are required",
    });
  }

  if (username.length < 3 || username.length > 50) {
    return res.status(400).json({
      success: false,
      error: "Username must be between 3 and 50 characters",
    });
  }

  if (password.length < 6) {
    return res.status(400).json({
      success: false,
      error: "Password must be at least 6 characters long",
    });
  }

  next();
};

module.exports = {
  validateContact,
  validateQuote,
  validateEmail,
  validateProductInquiry,
  validateAdmin,
};
