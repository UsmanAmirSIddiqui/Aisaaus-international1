import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Shield,
  Award,
  CheckCircle,
  FileText,
  Globe,
  Truck,
  Leaf,
  Users,
} from "lucide-react";

const Certifications = () => {
  const certifications = [
    {
      title: "ISO 9001:2015",
      category: "Quality Management",
      description: "International standard for quality management systems",
      icon: <Award className="h-8 w-8" />,
      status: "Certified",
      year: "2020",
    },
    {
      title: "ISO 14001:2015",
      category: "Environmental Management",
      description: "Environmental management systems certification",
      icon: <Leaf className="h-8 w-8" />,
      status: "Certified",
      year: "2021",
    },
    {
      title: "HACCP Certification",
      category: "Food Safety",
      description: "Hazard Analysis Critical Control Points for food products",
      icon: <Shield className="h-8 w-8" />,
      status: "Certified",
      year: "2019",
    },
    {
      title: "Export License",
      category: "Trade Authorization",
      description: "Government approved export license for international trade",
      icon: <Globe className="h-8 w-8" />,
      status: "Active",
      year: "1999",
    },
    {
      title: "Petroleum Products License",
      category: "Industry Specific",
      description: "Specialized license for petroleum products trading",
      icon: <FileText className="h-8 w-8" />,
      status: "Active",
      year: "2000",
    },
    {
      title: "Freight Forwarder License",
      category: "Logistics",
      description: "Authorized freight forwarding and logistics services",
      icon: <Truck className="h-8 w-8" />,
      status: "Active",
      year: "2005",
    },
  ];

  const standards = [
    {
      title: "Quality Assurance",
      points: [
        "Rigorous quality control processes",
        "Third-party testing and verification",
        "International quality standards compliance",
        "Continuous improvement programs",
      ],
    },
    {
      title: "Safety Standards",
      points: [
        "Workplace safety protocols",
        "Product safety certifications",
        "Transportation safety measures",
        "Emergency response procedures",
      ],
    },
    {
      title: "Environmental Compliance",
      points: [
        "Sustainable business practices",
        "Environmental impact assessments",
        "Waste management protocols",
        "Carbon footprint reduction",
      ],
    },
    {
      title: "Ethical Standards",
      points: [
        "Fair trade practices",
        "Ethical sourcing policies",
        "Anti-corruption measures",
        "Transparent business operations",
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <section className="py-20 bg-gradient-to-br from-orange-50 to-orange-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="bg-orange-100 text-orange-800 mb-6">
              🏆 Quality & Compliance
            </Badge>
            <h1 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Certifications & Standards
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              AISAAUS International maintains the highest standards of quality,
              safety, and compliance through internationally recognized
              certifications.
            </p>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-16">
            Our Certifications
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {certifications.map((cert, index) => (
              <Card key={index} className="hover:shadow-lg transition-shadow">
                <CardHeader className="text-center">
                  <div className="bg-orange-100 rounded-lg p-3 w-fit mx-auto mb-4 text-orange-500">
                    {cert.icon}
                  </div>
                  <Badge className="bg-green-100 text-green-800 mb-2 w-fit mx-auto">
                    {cert.status}
                  </Badge>
                  <CardTitle className="text-lg">{cert.title}</CardTitle>
                  <p className="text-sm text-orange-500 font-medium">
                    {cert.category}
                  </p>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-gray-600 mb-4">{cert.description}</p>
                  <p className="text-sm text-gray-500">
                    Certified since {cert.year}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="bg-gray-50 rounded-xl p-8">
            <h3 className="text-2xl font-bold text-center text-gray-900 mb-12">
              Our Standards Framework
            </h3>
            <div className="grid md:grid-cols-2 gap-8">
              {standards.map((standard, index) => (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Users className="h-6 w-6 text-orange-500 mr-3" />
                      {standard.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {standard.points.map((point, i) => (
                        <li key={i} className="flex items-start">
                          <CheckCircle className="h-4 w-4 text-orange-500 mr-2 mt-0.5 flex-shrink-0" />
                          <span className="text-gray-700 text-sm">{point}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-orange-50 rounded-xl p-8 text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Commitment to Excellence
            </h2>
            <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
              Our certifications are not just documents - they represent our
              unwavering commitment to delivering the highest quality products
              and services to our clients worldwide.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              <div className="text-center">
                <div className="bg-orange-500 rounded-full p-3 w-12 h-12 mx-auto mb-3">
                  <Shield className="h-6 w-6 text-white" />
                </div>
                <h3 className="font-semibold text-gray-900">Quality Assured</h3>
                <p className="text-sm text-gray-600">
                  Every product meets international standards
                </p>
              </div>
              <div className="text-center">
                <div className="bg-orange-500 rounded-full p-3 w-12 h-12 mx-auto mb-3">
                  <Globe className="h-6 w-6 text-white" />
                </div>
                <h3 className="font-semibold text-gray-900">
                  Globally Recognized
                </h3>
                <p className="text-sm text-gray-600">
                  Internationally accepted certifications
                </p>
              </div>
              <div className="text-center">
                <div className="bg-orange-500 rounded-full p-3 w-12 h-12 mx-auto mb-3">
                  <Award className="h-6 w-6 text-white" />
                </div>
                <h3 className="font-semibold text-gray-900">
                  Continuously Improving
                </h3>
                <p className="text-sm text-gray-600">
                  Regular audits and updates
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Certifications;
