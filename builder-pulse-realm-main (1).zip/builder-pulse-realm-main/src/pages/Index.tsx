import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/LanguageContext";
import { api } from "@/services/api";
import { toast } from "sonner";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  ArrowRight,
  CheckCircle,
  Star,
  Users,
  Target,
  TrendingUp,
  Award,
  Mail,
  Phone,
  MapPin,
  Globe,
  Droplets,
  Gem,
  Apple,
  Mountain,
  Calendar,
  Shield,
  Eye,
  Heart,
  Truck,
  Factory,
  Building,
  DollarSign,
  Handshake,
  Coffee,
  BarChart3,
  Leaf,
  Recycle,
  Zap,
  TreePine,
} from "lucide-react";

const Index = () => {
  const { t } = useLanguage();

  // Contact form state
  const [contactForm, setContactForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    company: "",
    phone: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Handle contact form submission
  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await api.contact.submit({
        name: `${contactForm.firstName} ${contactForm.lastName}`.trim(),
        email: contactForm.email,
        phone: contactForm.phone || undefined,
        company: contactForm.company || undefined,
        message: contactForm.message,
      });

      if (response.success) {
        toast.success(
          "Message sent successfully! We'll get back to you soon. 🚀",
        );
        setContactForm({
          firstName: "",
          lastName: "",
          email: "",
          company: "",
          phone: "",
          message: "",
        });
      } else {
        toast.error(
          response.error || "Failed to send message. Please try again.",
        );
      }
    } catch (error) {
      toast.error("Failed to send message. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle form input changes
  const handleInputChange = (field: string, value: string) => {
    setContactForm((prev) => ({ ...prev, [field]: value }));
  };
  const teamMembers = [
    {
      name: "Dr. Amir Siddiqui",
      role: "Founder & CEO",
      image:
        "https://cdn.builder.io/api/v1/assets/6972a23af08b4c8da669c410b76f80e9/img-20250320-wa0012-939455?format=webp&width=800",
      bio: "Visionary founder who established AISAAUS International in 1999, building it into a global trading powerhouse.",
    },
    {
      name: "Umar Amir Siddiqui",
      role: "Food Division Manager",
      image:
        "https://cdn.builder.io/api/v1/assets/6972a23af08b4c8da669c410b76f80e9/whatsapp-image-2025-06-25-at-00.07.28_ff9a8ead-741e98?format=webp&width=800",
      bio: "Expert in food products and agricultural trade operations.",
    },
    {
      name: "Sharjeel Amir Siddiqui",
      role: "Petroleum Division Manager",
      image:
        "https://cdn.builder.io/api/v1/assets/6972a23af08b4c8da669c410b76f80e9/whatsapp-image-2025-06-15-at-15.53.01_54469737-6cb711?format=webp&width=800",
      bio: "Petroleum products expert with extensive industry knowledge.",
    },
    {
      name: "Usman Amir Siddiqui",
      role: "Minerals Division Manager",
      image:
        "https://cdn.builder.io/api/v1/assets/6972a23af08b4c8da669c410b76f80e9/whatsapp-image-2025-06-15-at-15.53.01_0dc2d250-1fe901?format=webp&width=800",
      bio: "Specialist in minerals, gemstones, and geological products.",
    },
  ];

  const services = [
    {
      icon: <Globe className="h-8 w-8" />,
      title: "Import & Export Services",
      description:
        "Comprehensive international trade solutions for all product categories.",
    },
    {
      icon: <Truck className="h-8 w-8" />,
      title: "Supply Chain Management",
      description:
        "End-to-end supply chain optimization and logistics coordination.",
    },
    {
      icon: <Shield className="h-8 w-8" />,
      title: "Quality Assurance",
      description:
        "International quality standards compliance and testing services.",
    },
    {
      icon: <Users className="h-8 w-8" />,
      title: "Business Consulting",
      description:
        "Expert guidance for international trade and market expansion.",
    },
    {
      icon: <Award className="h-8 w-8" />,
      title: "Certification Support",
      description:
        "Assistance with international certifications and compliance.",
    },
    {
      icon: <Handshake className="h-8 w-8" />,
      title: "Partnership Development",
      description: "Building lasting business relationships worldwide.",
    },
  ];

  const products = {
    petroleum: [
      "SN500 Base Oil",
      "Paraffin Wax",
      "Petroleum Jelly",
      "Rubber Process Oil",
      "Carbon Black",
      "Phthalic Anhydride",
    ],
    minerals: [
      "Silica Sand",
      "Dolomite",
      "Emerald",
      "Quartz Crystal",
      "Aluminium Ore",
      "Copper",
    ],
    food: {
      meat: ["Beef", "Mutton", "Chicken", "Fish"],
      fruits: [
        "Mangoes (Langra, Chaunsa, Sindhri)",
        "Oranges/Kinnow",
        "Pine Nuts",
      ],
      other: [
        "Dry Chili",
        "Mango Pulp",
        "Dried Mango",
        "Orange Concentrate",
        "Apple Concentrate",
      ],
    },
    salts: ["Pink Himalayan Salt", "White Edible Salt"],
  };

  const testimonials = [
    {
      name: "Ahmed Al-Rashid",
      role: "CEO, Gulf Enterprises",
      company: "United Arab Emirates",
      content:
        "AISAAUS International has been our trusted partner for petroleum products for over 5 years. Their reliability and quality standards are exceptional.",
      rating: 5,
      image:
        "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
    },
    {
      name: "Sarah Mitchell",
      role: "Import Manager, FoodCorp Ltd",
      company: "United Kingdom",
      content:
        "The quality of food products from AISAAUS is outstanding. Their mangoes and spices have helped us expand our premium product line significantly.",
      rating: 5,
      image:
        "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face",
    },
    {
      name: "Chen Wei",
      role: "Procurement Director, Asia Minerals",
      company: "Singapore",
      content:
        "Their gemstone collection is remarkable. We've built a strong partnership over the years, and their service has always exceeded our expectations.",
      rating: 5,
      image:
        "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",
    },
  ];

  const coreValues = [
    { title: "Excellence & Integrity", icon: <Award className="h-6 w-6" /> },
    { title: "Sustainability", icon: <Leaf className="h-6 w-6" /> },
    { title: "Global Reach", icon: <Globe className="h-6 w-6" /> },
    {
      title: "Continuous Innovation",
      icon: <TrendingUp className="h-6 w-6" />,
    },
    { title: "Customer-Centricity", icon: <Heart className="h-6 w-6" /> },
  ];

  return (
    <>
      {/* Hero Section */}
      <section
        id="home"
        className="relative bg-gradient-to-br from-orange-50 to-orange-100 py-20 lg:py-32 text-transition"
        style={{
          backgroundImage: `url('https://images.pexels.com/photos/7634436/pexels-photo-7634436.jpeg')`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      >
        {/* World map overlay with gradient blend */}
        <div className="absolute inset-0 bg-gradient-to-br from-orange-50/90 to-orange-100/90"></div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center language-transition">
            <Badge className="bg-orange-100 text-orange-800 hover:bg-orange-200 mb-6 modern-card">
              <p>🌐 Established 1999 Global Trade Leader</p>
            </Badge>
            <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 mb-6 text-transition">
              <p>AISAAUS INTERNATIONAL</p>
            </h1>
            <p className="text-2xl lg:text-3xl text-orange-600 font-semibold mb-8 text-transition">
              {t("hero.subtitle")}
            </p>
            <p className="text-xl text-gray-600 mb-8 max-w-4xl mx-auto leading-relaxed text-transition">
              {t("hero.mission")}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button
                size="lg"
                className="bg-orange-500 hover:bg-orange-600 transition-all duration-300"
                onClick={() => {
                  document.getElementById("business")?.scrollIntoView({
                    behavior: "smooth",
                  });
                }}
              >
                {t("hero.catalogAccess")}
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-orange-500 text-orange-500 hover:bg-orange-500 hover:text-white transition-all duration-300"
                onClick={() => {
                  document.getElementById("company")?.scrollIntoView({
                    behavior: "smooth",
                  });
                }}
              >
                {t("hero.learnAbout")}
              </Button>
            </div>

            {/* Company Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
              <div className="text-center p-4 rounded-lg bg-white/50 backdrop-blur-sm hover:shadow-lg transition-all duration-300">
                <div className="text-3xl font-bold text-orange-600">25+</div>
                <div className="text-sm text-gray-600">{t("stats.years")}</div>
              </div>
              <div className="text-center p-4 rounded-lg bg-white/50 backdrop-blur-sm hover:shadow-lg transition-all duration-300">
                <div className="text-3xl font-bold text-orange-600">1000+</div>
                <div className="text-sm text-gray-600">
                  {t("stats.employees")}
                </div>
              </div>
              <div className="text-center p-4 rounded-lg bg-white/50 backdrop-blur-sm hover:shadow-lg transition-all duration-300">
                <div className="text-3xl font-bold text-orange-600">
                  <p>$200M+</p>
                </div>
                <div className="text-sm text-gray-600">{t("stats.export")}</div>
              </div>
              <div className="text-center p-4 rounded-lg bg-white/50 backdrop-blur-sm hover:shadow-lg transition-all duration-300">
                <div className="text-3xl font-bold text-orange-600">Global</div>
                <div className="text-sm text-gray-600">
                  {t("stats.partnerships")}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Company Section */}
      <section id="company" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              <p>About AISAAUS INTERNATIONAL</p>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              {t("company.subtitle")}
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">
                {t("company.mission.title")}
              </h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                {t("company.mission.text")}
              </p>
              <div className="space-y-4">
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-orange-500 mr-3" />
                  <span className="text-gray-700">
                    {t("company.established")}
                  </span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-orange-500 mr-3" />
                  <span className="text-gray-700">
                    {t("company.employees")}
                  </span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-orange-500 mr-3" />
                  <span className="text-gray-700">
                    {t("company.experience")}
                  </span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardContent className="p-6 text-center">
                  <Users className="h-8 w-8 text-orange-500 mx-auto mb-4" />
                  <div className="text-2xl font-bold text-gray-900">500+</div>
                  <div className="text-sm text-gray-600">
                    {t("company.clients")}
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6 text-center">
                  <Award className="h-8 w-8 text-orange-500 mx-auto mb-4" />
                  <div className="text-2xl font-bold text-gray-900">50+</div>
                  <div className="text-sm text-gray-600">
                    {t("company.awards")}
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6 text-center">
                  <Target className="h-8 w-8 text-orange-500 mx-auto mb-4" />
                  <div className="text-2xl font-bold text-gray-900">98%</div>
                  <div className="text-sm text-gray-600">
                    {t("company.success")}
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6 text-center">
                  <TrendingUp className="h-8 w-8 text-orange-500 mx-auto mb-4" />
                  <div className="text-2xl font-bold text-gray-900">$2B+</div>
                  <div className="text-sm text-gray-600">
                    {t("company.revenue")}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Mission & Vision */}
          <div className="grid lg:grid-cols-2 gap-12 mb-16">
            <Card className="p-8">
              <CardHeader className="text-center">
                <div className="bg-orange-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <Target className="h-8 w-8 text-orange-500" />
                </div>
                <CardTitle className="text-2xl">
                  {t("company.mission.title")}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center leading-relaxed">
                  {t("company.mission.text")}
                </p>
              </CardContent>
            </Card>

            <Card className="p-8">
              <CardHeader className="text-center">
                <div className="bg-orange-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <Eye className="h-8 w-8 text-orange-500" />
                </div>
                <CardTitle className="text-2xl">
                  {t("company.vision.title")}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 text-center leading-relaxed">
                  {t("company.vision.text")}
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Core Values */}
          <div className="bg-gray-50 rounded-xl p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">
              {t("company.values")}
            </h3>
            <div className="grid md:grid-cols-3 lg:grid-cols-5 gap-6">
              <div className="text-center">
                <div className="bg-orange-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center text-orange-500">
                  <Award className="h-6 w-6" />
                </div>
                <h4 className="font-semibold text-gray-900 text-sm">
                  {t("company.excellence")}
                </h4>
              </div>
              <div className="text-center">
                <div className="bg-orange-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center text-orange-500">
                  <Leaf className="h-6 w-6" />
                </div>
                <h4 className="font-semibold text-gray-900 text-sm">
                  {t("company.sustainability")}
                </h4>
              </div>
              <div className="text-center">
                <div className="bg-orange-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center text-orange-500">
                  <Globe className="h-6 w-6" />
                </div>
                <h4 className="font-semibold text-gray-900 text-sm">
                  {t("company.global")}
                </h4>
              </div>
              <div className="text-center">
                <div className="bg-orange-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center text-orange-500">
                  <TrendingUp className="h-6 w-6" />
                </div>
                <h4 className="font-semibold text-gray-900 text-sm">
                  {t("company.innovation")}
                </h4>
              </div>
              <div className="text-center">
                <div className="bg-orange-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center text-orange-500">
                  <Heart className="h-6 w-6" />
                </div>
                <h4 className="font-semibold text-gray-900 text-sm">
                  {t("company.customer")}
                </h4>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Business Section */}
      <section id="business" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              {t("business.title")}
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              {t("business.subtitle")}
            </p>
          </div>

          {/* Services */}
          <div className="mb-20">
            <h3 className="text-2xl font-bold text-center text-gray-900 mb-12">
              {t("business.services.title")}
            </h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="bg-orange-100 rounded-lg p-3 w-fit text-orange-500">
                    <Globe className="h-8 w-8" />
                  </div>
                  <CardTitle className="text-xl">
                    {t("business.services.import")}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    {t("business.services.import.desc")}
                  </p>
                  <Button
                    variant="ghost"
                    className="mt-4 text-orange-500 hover:text-orange-600 p-0"
                  >
                    Learn More <ArrowRight className="ml-1 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="bg-orange-100 rounded-lg p-3 w-fit text-orange-500">
                    <Truck className="h-8 w-8" />
                  </div>
                  <CardTitle className="text-xl">
                    {t("business.services.supply")}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    {t("business.services.supply.desc")}
                  </p>
                  <Button
                    variant="ghost"
                    className="mt-4 text-orange-500 hover:text-orange-600 p-0"
                  >
                    Learn More <ArrowRight className="ml-1 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="bg-orange-100 rounded-lg p-3 w-fit text-orange-500">
                    <Shield className="h-8 w-8" />
                  </div>
                  <CardTitle className="text-xl">
                    {t("business.services.quality")}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    {t("business.services.quality.desc")}
                  </p>
                  <Button
                    variant="ghost"
                    className="mt-4 text-orange-500 hover:text-orange-600 p-0"
                  >
                    Learn More <ArrowRight className="ml-1 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="bg-orange-100 rounded-lg p-3 w-fit text-orange-500">
                    <Users className="h-8 w-8" />
                  </div>
                  <CardTitle className="text-xl">
                    {t("business.services.consulting")}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    {t("business.services.consulting.desc")}
                  </p>
                  <Button
                    variant="ghost"
                    className="mt-4 text-orange-500 hover:text-orange-600 p-0"
                  >
                    Learn More <ArrowRight className="ml-1 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="bg-orange-100 rounded-lg p-3 w-fit text-orange-500">
                    <Award className="h-8 w-8" />
                  </div>
                  <CardTitle className="text-xl">
                    {t("business.services.certification")}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    {t("business.services.certification.desc")}
                  </p>
                  <Button
                    variant="ghost"
                    className="mt-4 text-orange-500 hover:text-orange-600 p-0"
                  >
                    Learn More <ArrowRight className="ml-1 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="bg-orange-100 rounded-lg p-3 w-fit text-orange-500">
                    <Handshake className="h-8 w-8" />
                  </div>
                  <CardTitle className="text-xl">
                    {t("business.services.partnership")}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">
                    {t("business.services.partnership.desc")}
                  </p>
                  <Button
                    variant="ghost"
                    className="mt-4 text-orange-500 hover:text-orange-600 p-0"
                  >
                    Learn More <ArrowRight className="ml-1 h-4 w-4" />
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Products */}
          <div className="mb-20">
            <h3 className="text-2xl font-bold text-center text-gray-900 mb-12">
              {t("business.products")}
            </h3>
            <div className="space-y-16">
              {/* Petroleum Products */}
              <div>
                <div className="flex items-center mb-8">
                  <div className="bg-blue-100 rounded-lg p-3 mr-4">
                    <Droplets className="h-8 w-8 text-blue-500" />
                  </div>
                  <h4 className="text-2xl font-bold text-gray-900">
                    {t("business.petroleum")}
                  </h4>
                </div>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {products.petroleum.map((product, index) => (
                    <Card
                      key={index}
                      className="hover:shadow-md transition-shadow"
                    >
                      <CardContent className="p-4">
                        <h5 className="font-semibold text-gray-900">
                          {product}
                        </h5>
                        <p className="text-sm text-gray-600 mt-1">
                          High-quality petroleum derivative
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Minerals & Gemstones */}
              <div>
                <div className="flex items-center mb-8">
                  <div className="bg-purple-100 rounded-lg p-3 mr-4">
                    <Gem className="h-8 w-8 text-purple-500" />
                  </div>
                  <h4 className="text-2xl font-bold text-gray-900">
                    Minerals & Gemstones
                  </h4>
                </div>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {products.minerals.map((mineral, index) => (
                    <Card
                      key={index}
                      className="hover:shadow-md transition-shadow"
                    >
                      <CardContent className="p-4">
                        <h5 className="font-semibold text-gray-900">
                          {mineral}
                        </h5>
                        <p className="text-sm text-gray-600 mt-1">
                          Premium quality mineral/gemstone
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Food Items */}
              <div>
                <div className="flex items-center mb-8">
                  <div className="bg-green-100 rounded-lg p-3 mr-4">
                    <Apple className="h-8 w-8 text-green-500" />
                  </div>
                  <h4 className="text-2xl font-bold text-gray-900">
                    Food Items
                  </h4>
                </div>
                <div className="grid lg:grid-cols-3 gap-8">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Meat Products</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {products.food.meat.map((item, index) => (
                          <li
                            key={index}
                            className="text-sm text-gray-600 flex items-center"
                          >
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Fruits & Nuts</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {products.food.fruits.map((item, index) => (
                          <li
                            key={index}
                            className="text-sm text-gray-600 flex items-center"
                          >
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Other Products</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {products.food.other.map((item, index) => (
                          <li
                            key={index}
                            className="text-sm text-gray-600 flex items-center"
                          >
                            <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                            {item}
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </div>
              </div>

              {/* Salts */}
              <div>
                <div className="flex items-center mb-8">
                  <div className="bg-gray-100 rounded-lg p-3 mr-4">
                    <Mountain className="h-8 w-8 text-gray-500" />
                  </div>
                  <h4 className="text-2xl font-bold text-gray-900">
                    Salt Products
                  </h4>
                </div>
                <div className="grid md:grid-cols-2 gap-4">
                  {products.salts.map((salt, index) => (
                    <Card
                      key={index}
                      className="hover:shadow-md transition-shadow"
                    >
                      <CardContent className="p-6">
                        <h5 className="font-semibold text-gray-900 text-lg">
                          {salt}
                        </h5>
                        <p className="text-gray-600 mt-2">
                          {salt.includes("Pink")
                            ? "Natural Himalayan salt with minerals"
                            : "Pure white edible salt"}
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Global Reach */}
          <div className="bg-white rounded-xl p-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">
              {t("business.reach.title")}
            </h3>
            <div className="grid md:grid-cols-3 gap-8 text-center">
              <div>
                <div className="bg-orange-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <Globe className="h-8 w-8 text-orange-500" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">
                  {t("business.reach.countries")}
                </h4>
                <p className="text-gray-600 text-sm">
                  {t("business.reach.countries.desc")}
                </p>
              </div>
              <div>
                <div className="bg-orange-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <Users className="h-8 w-8 text-orange-500" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">
                  {t("business.reach.partners")}
                </h4>
                <p className="text-gray-600 text-sm">
                  {t("business.reach.partners.desc")}
                </p>
              </div>
              <div>
                <div className="bg-orange-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                  <Truck className="h-8 w-8 text-orange-500" />
                </div>
                <h4 className="font-semibold text-gray-900 mb-2">
                  {t("business.reach.routes")}
                </h4>
                <p className="text-gray-600 text-sm">
                  {t("business.reach.routes.desc")}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section id="team" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              {t("team.title")}
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              <p>
                Meet our experienced leadership team guiding AISAAUS
                INTERNATIONAL global operations.
              </p>
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamMembers.map((member, index) => (
              <Card
                key={index}
                className="text-center hover:shadow-lg transition-shadow"
              >
                <CardContent className="p-6">
                  <img
                    src={member.image}
                    alt={member.name}
                    className={`w-24 h-24 rounded-full mx-auto mb-4 ${member.name === "Usman Amir Siddiqui" || member.name === "Sharjeel Amir Siddiqui" || member.name === "Umar Amir Siddiqui" ? "object-contain bg-gray-100" : "object-cover"}`}
                  />
                  <h3 className="text-lg font-semibold text-gray-900 mb-1">
                    {member.name}
                  </h3>
                  <p className="text-orange-500 font-medium mb-3">
                    {member.name === "Dr. Amir Siddiqui"
                      ? t("team.founder")
                      : member.name === "Umar Amir Siddiqui"
                        ? t("team.food")
                        : member.name === "Sharjeel Amir Siddiqui"
                          ? t("team.petroleum")
                          : t("team.minerals")}
                  </p>
                  <p className="text-sm text-gray-600">
                    {member.name === "Dr. Amir Siddiqui" ? (
                      <p>
                        Visionary founder who established AISAAUS INTERNATIONAL
                        in 1999, building it into a global trading powerhouse.
                      </p>
                    ) : member.name === "Umar Amir Siddiqui" ? (
                      t("team.food.bio")
                    ) : member.name === "Sharjeel Amir Siddiqui" ? (
                      t("team.petroleum.bio")
                    ) : (
                      t("team.minerals.bio")
                    )}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Founder Tribute Section */}
      <section className="py-20 bg-gradient-to-br from-orange-50 to-orange-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="bg-orange-100 text-orange-800 mb-6">
              {t("tribute.badge")}
            </Badge>
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              {t("tribute.title")}
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              <p>
                The visionary leadership and unwavering dedication that built
                AISAAUS INTERNATIONALinto a global trading powerhouse.
              </p>
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1">
              <div className="bg-white rounded-xl p-8 shadow-lg">
                <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
                  Dr. Amir Siddiqui
                </h3>
                <p className="text-xl text-orange-600 font-semibold text-center mb-6">
                  Founder & Chief Executive Officer
                </p>

                <div className="space-y-4 text-gray-700 leading-relaxed">
                  <p>
                    <strong>Dr. Amir Siddiqui</strong> founded AISAAUS
                    International in 1999 with a vision to transform Pakistan's
                    position in global trade. His entrepreneurial spirit and
                    deep understanding of international markets laid the
                    foundation for what would become a leading trading
                    enterprise.
                  </p>

                  <p>
                    Under his leadership, AISAAUS International has grown from a
                    small trading company to a global enterprise with over 1000
                    employees, serving clients across 50+ countries with an
                    impressive export record exceeding $200,000.
                  </p>

                  <p>
                    Dr. Siddiqui's commitment to excellence, ethical business
                    practices, and sustainable growth has earned AISAAUS
                    International recognition as a trusted partner in
                    international trade, particularly in petroleum products,
                    minerals, gemstones, food items, and specialty salts.
                  </p>
                </div>

                <div className="mt-8 grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-500">
                      25+
                    </div>
                    <div className="text-sm text-gray-600">
                      Years of Leadership
                    </div>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-500">
                      1000+
                    </div>
                    <div className="text-sm text-gray-600">Team Members</div>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-500">
                      50+
                    </div>
                    <div className="text-sm text-gray-600">Global Markets</div>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-500">
                      $200K+
                    </div>
                    <div className="text-sm text-gray-600">Export Record</div>
                  </div>
                </div>

                <div className="mt-6 text-center">
                  <blockquote className="text-lg italic text-gray-600 border-l-4 border-orange-500 pl-4">
                    "Our customers are our top priority... Your success is our
                    mission."
                    <cite className="block text-sm font-medium text-orange-600 mt-2">
                      - Dr. Amir Siddiqui
                    </cite>
                  </blockquote>
                </div>
              </div>
            </div>

            <div className="order-1 lg:order-2">
              <div className="relative">
                <div className="bg-white rounded-xl p-6 shadow-2xl">
                  <img
                    src="https://cdn.builder.io/api/v1/assets/6972a23af08b4c8da669c410b76f80e9/img-20250320-wa0012-939455?format=webp&width=800"
                    alt="Dr. Amir Siddiqui - Founder & CEO"
                    className="w-full h-96 object-cover rounded-lg"
                  />
                  <div className="absolute -top-4 -right-4 bg-orange-500 rounded-full p-4">
                    <Award className="h-8 w-8 text-white" />
                  </div>
                </div>

                <div className="mt-6 space-y-3">
                  <div className="flex items-center bg-white rounded-lg p-3 shadow-md">
                    <CheckCircle className="h-5 w-5 text-orange-500 mr-3" />
                    <span className="text-gray-700 text-sm">
                      Established Pakistan's leading trading company
                    </span>
                  </div>
                  <div className="flex items-center bg-white rounded-lg p-3 shadow-md">
                    <CheckCircle className="h-5 w-5 text-orange-500 mr-3" />
                    <span className="text-gray-700 text-sm">
                      Champion of international trade excellence
                    </span>
                  </div>
                  <div className="flex items-center bg-white rounded-lg p-3 shadow-md">
                    <CheckCircle className="h-5 w-5 text-orange-500 mr-3" />
                    <span className="text-gray-700 text-sm">
                      Advocate for ethical business practices
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="mt-16 text-center">
            <h4 className="text-xl font-bold text-gray-900 mb-4">
              Legacy of Excellence
            </h4>
            <p className="text-gray-600 max-w-4xl mx-auto leading-relaxed">
              <p>
                Dr. Amir Siddiqui's vision extends beyond business success. He
                has built a company culture rooted in integrity,
                customer-centricity, and sustainable growth. His leadership
                philosophy of putting customers first has made AISAAUS
                INTERNATIONAL a trusted name in global trade, while his
                commitment to innovation continues to drive the company toward
                new horizons in international commerce.
              </p>
            </p>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
              {t("contact.title")}
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              {t("contact.subtitle")}
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-8">
                {t("contact.info")}
              </h3>
              <div className="space-y-6">
                <div className="flex items-center">
                  <div className="bg-orange-100 rounded-lg p-3 mr-4">
                    <Phone className="h-6 w-6 text-orange-500" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">
                      {t("contact.phone")}
                    </p>
                    <p className="text-gray-600">03238088081</p>
                    <p className="text-gray-600">03214387645</p>
                  </div>
                </div>

                <div className="flex items-center">
                  <div className="bg-orange-100 rounded-lg p-3 mr-4">
                    <Mail className="h-6 w-6 text-orange-500" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">
                      {t("contact.email")}
                    </p>
                    <p className="text-gray-600">
                      aisaausinternational@yahoo.com
                    </p>
                  </div>
                </div>

                <div className="flex items-center">
                  <div className="bg-orange-100 rounded-lg p-3 mr-4">
                    <Globe className="h-6 w-6 text-orange-500" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">
                      {t("contact.website")}
                    </p>
                    <p className="text-gray-600">
                      www.aisaausinternational.com
                    </p>
                  </div>
                </div>

                <div className="flex items-center">
                  <div className="bg-orange-100 rounded-lg p-3 mr-4">
                    <MapPin className="h-6 w-6 text-orange-500" />
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">
                      {t("contact.headquarters")}
                    </p>
                    <p className="text-gray-600">Lahore, Pakistan</p>
                    <p className="text-gray-600 text-sm">Established 1999</p>
                  </div>
                </div>
              </div>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>{t("contact.message")}</CardTitle>
                <CardDescription>{t("contact.response")}</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleContactSubmit} className="space-y-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t("contact.firstName")}
                      </label>
                      <Input
                        placeholder="Your first name"
                        value={contactForm.firstName}
                        onChange={(e) =>
                          handleInputChange("firstName", e.target.value)
                        }
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {t("contact.lastName")}
                      </label>
                      <Input
                        placeholder="Your last name"
                        value={contactForm.lastName}
                        onChange={(e) =>
                          handleInputChange("lastName", e.target.value)
                        }
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t("contact.email")}
                    </label>
                    <Input
                      type="email"
                      placeholder="your@email.com"
                      value={contactForm.email}
                      onChange={(e) =>
                        handleInputChange("email", e.target.value)
                      }
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      {t("contact.company")}
                    </label>
                    <Input
                      placeholder="Your Company Name"
                      value={contactForm.company}
                      onChange={(e) =>
                        handleInputChange("company", e.target.value)
                      }
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Phone (Optional)
                    </label>
                    <Input
                      type="tel"
                      placeholder="+92 300 1234567"
                      value={contactForm.phone}
                      onChange={(e) =>
                        handleInputChange("phone", e.target.value)
                      }
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Message
                    </label>
                    <Textarea
                      placeholder={t("contact.messagePlaceholder")}
                      rows={4}
                      value={contactForm.message}
                      onChange={(e) =>
                        handleInputChange("message", e.target.value)
                      }
                      required
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-orange-500 hover:bg-orange-600"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? "Sending..." : t("contact.send")}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </>
  );
};

export default Index;
